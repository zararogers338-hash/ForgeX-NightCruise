from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent


def win_no_window() -> int:
    if os.name != "nt":
        return 0
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)


def result(name: str, ok: bool, message: str = "", details: Any = None) -> dict[str, Any]:
    return {"name": name, "ok": bool(ok), "message": message, "details": details}


def run_py(py: str, code: str, timeout: int = 20) -> tuple[bool, str]:
    try:
        out = subprocess.check_output(
            [py, "-c", code],
            cwd=str(ROOT),
            env=base_env(),
            text=True,
            encoding="utf-8",
            errors="replace",
            stderr=subprocess.STDOUT,
            timeout=timeout,
            creationflags=win_no_window(),
        )
        return True, out.strip()
    except subprocess.CalledProcessError as exc:
        return False, (exc.output or str(exc)).strip()
    except Exception as exc:
        return False, str(exc)


def base_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    env = os.environ.copy()
    env.setdefault("PYTHONUTF8", "1")
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PIP_DISABLE_PIP_VERSION_CHECK", "1")
    env.setdefault("PIP_NO_COLOR", "1")
    env.setdefault("NO_COLOR", "1")
    if extra:
        env.update({k: str(v) for k, v in extra.items()})
    return env


def default_python(project: Path) -> str:
    venv = project / ".venv"
    cand = venv / "Scripts" / "python.exe" if os.name == "nt" else venv / "bin" / "python"
    if cand.exists():
        return str(cand)
    return sys.executable


def can_bind(host: str, port: int) -> tuple[bool, str]:
    bind_host = "" if host in {"0.0.0.0", "::"} else host
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((bind_host, port))
        return True, "端口可监听"
    except OSError as exc:
        return False, f"端口被占用或不可监听: {exc}"


def find_free_port(host: str, start: int) -> int:
    for port in range(start, start + 100):
        ok, _ = can_bind(host, port)
        if ok:
            return port
    raise RuntimeError(f"从 {start} 开始没有找到空闲端口。")


def pids_on_port(port: int) -> list[str]:
    if os.name != "nt":
        return []
    try:
        out = subprocess.check_output(
            ["netstat", "-ano"],
            text=True,
            encoding="utf-8",
            errors="replace",
            stderr=subprocess.DEVNULL,
            timeout=8,
            creationflags=win_no_window(),
        )
    except Exception:
        return []
    pids: set[str] = set()
    needle = f":{port}"
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 5 and needle in parts[1]:
            pids.add(parts[-1])
    return sorted(pids)


def http_ok(url: str, timeout: int = 3) -> tuple[bool, str]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            body = response.read(200000).decode("utf-8", "ignore")
            status = getattr(response, "status", 200)
            if 200 <= status < 500:
                return True, f"HTTP {status}, body {len(body)} bytes"
            return False, f"HTTP {status}"
    except Exception as exc:
        return False, str(exc)


def start_main_check(project: Path, py: str, host: str, start_port: int, timeout: int) -> dict[str, Any]:
    port = find_free_port(host, start_port)
    url = f"http://{host}:{port}/"
    env = base_env({
        "POLARIS_OS_SERVER_HOST": host,
        "POLARIS_OS_SERVER_PORT": str(port),
        "FORGEX_SERVER_HOST": host,
        "FORGEX_SERVER_PORT": str(port),
        "FORGEX_SHARE": "false",
        "POLARIS_OS_OPEN_BROWSER": "0",
    })
    logs: list[str] = []
    proc = subprocess.Popen(
        [py, str(project / "main.py")],
        cwd=str(project),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        creationflags=win_no_window(),
    )

    def reader() -> None:
        if proc.stdout is None:
            return
        for line in proc.stdout:
            logs.append(line.rstrip("\n"))
            if len(logs) > 300:
                del logs[:100]

    thread = threading.Thread(target=reader, daemon=True)
    thread.start()
    deadline = time.time() + timeout
    ok = False
    msg = ""
    try:
        while time.time() < deadline:
            if proc.poll() is not None:
                msg = f"main.py 提前退出，退出码 {proc.returncode}"
                break
            ok, msg = http_ok(url, timeout=2)
            if ok:
                break
            time.sleep(1)
        if not ok and not msg:
            msg = f"{timeout} 秒内服务未响应"
        return {
            "ok": ok,
            "message": msg,
            "url": url,
            "port": port,
            "logs_tail": logs[-80:],
        }
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()


def perform_checks(args: argparse.Namespace) -> dict[str, Any]:
    project = Path(args.project_dir).resolve()
    py = args.python_exe or default_python(project)
    host = args.host
    port = int(args.port)
    checks: list[dict[str, Any]] = []

    ok, out = run_py(py, "import sys; print(sys.version)")
    checks.append(result("Python 可用", ok, out))
    checks.append(result("Python 版本 3.11", ok and out.startswith("3.11"), out))

    venv_py = project / ".venv" / "Scripts" / "python.exe" if os.name == "nt" else project / ".venv" / "bin" / "python"
    checks.append(result("venv 可用", venv_py.exists(), str(venv_py)))

    ok, out = run_py(py, "import pip; print(pip.__version__)")
    checks.append(result("pip 可用", ok, out))

    ok, out = run_py(py, "import torch; print(torch.__version__); print('cuda=' + str(torch.cuda.is_available()))", timeout=35)
    checks.append(result("torch 可 import", ok, out))
    cuda_ok = ok and "cuda=True" in out
    checks.append(result("CUDA 状态", True, "可用" if cuda_ok else "不可用或 CPU fallback"))

    ok, out = run_py(py, "import gradio as gr; print(gr.__version__)", timeout=25)
    checks.append(result("gradio 可 import", ok, out))

    main_path = project / "main.py"
    checks.append(result("main.py 存在", main_path.exists(), str(main_path)))
    ok, out = run_py(py, f"import py_compile; py_compile.compile({str(main_path)!r}, doraise=True); print('compile ok')", timeout=35)
    checks.append(result("main.py 可编译", ok, out))

    bind_ok, bind_msg = can_bind(host, port)
    details = {"pids": pids_on_port(port)} if not bind_ok else None
    checks.append(result("端口可监听", bind_ok, bind_msg, details))

    service = None
    if args.service_url:
        ok, msg = http_ok(args.service_url)
        service = {"url": args.service_url, "ok": ok, "message": msg}
        checks.append(result("本地服务响应", ok, msg, {"url": args.service_url}))

    start_info = None
    if args.start_main:
        start_info = start_main_check(project, py, host, port, int(args.timeout))
        checks.append(result("main.py 可启动并响应", bool(start_info["ok"]), start_info["message"], start_info))

    critical_names = {"Python 可用", "Python 版本 3.11", "venv 可用", "pip 可用", "torch 可 import", "gradio 可 import", "main.py 存在", "main.py 可编译"}
    if args.start_main:
        critical_names.add("main.py 可启动并响应")
    if args.require_free_port:
        critical_names.add("端口可监听")
    passed = all(c["ok"] for c in checks if c["name"] in critical_names)
    return {
        "ok": passed,
        "project_dir": str(project),
        "python": py,
        "checks": checks,
        "service": service,
        "start": start_info,
    }


def print_human(report: dict[str, Any]) -> None:
    for item in report["checks"]:
        mark = "OK" if item["ok"] else "FAIL"
        print(f"[{mark}] {item['name']}: {item['message']}")
        if item.get("details") and item["name"] == "端口可监听":
            print("       占用 PID: " + ", ".join(item["details"].get("pids") or []))
    print("[OK] 自检通过" if report["ok"] else "[FAIL] 自检未通过")


def main() -> int:
    parser = argparse.ArgumentParser(description="POLARIS OS healthcheck")
    parser.add_argument("--project-dir", default=str(ROOT))
    parser.add_argument("--python-exe", default="")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--service-url", default="")
    parser.add_argument("--start-main", action="store_true")
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--require-free-port", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    report = perform_checks(args)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print_human(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
