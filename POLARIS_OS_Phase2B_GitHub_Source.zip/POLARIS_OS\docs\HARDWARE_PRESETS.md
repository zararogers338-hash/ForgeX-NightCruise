# Hardware Presets

POLARIS OS defaults are tuned for local consumer GPUs. Start conservatively, then raise sequence length, rank, or batch size after a stable test run.

## RTX 5080 Laptop / 16GB

```text
batch_size = 1
gradient_accumulation_steps = 8
max_seq_len = 2048
rank = 64
label_smoothing = 0
eval_ratio = 0
```

For a 1.5B model, LoRA full-precision training is usually workable. For larger models, prefer QLoRA.

## 8GB GPUs

```text
batch_size = 1
gradient_accumulation_steps = 8-16
max_seq_len = 1024
rank = 16-32
use_qlora = true for models above 3B
```

## 24GB+ GPUs

```text
batch_size = 1-2
gradient_accumulation_steps = 4-8
max_seq_len = 2048-4096
rank = 64-128
```

Do not use 4096+ sequence length on 16GB cards unless the model, dataset, and training method have already passed a short stability test.
