from pathlib import Path

def run(path, content, encoding='utf-8', append=False):
    p = Path(path).expanduser().resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    mode = 'a' if append else 'w'
    with p.open(mode, encoding=encoding) as f:
        f.write(content)
    return {'ok': True, 'path': str(p), 'bytes': len(content.encode(encoding, errors='ignore'))}
