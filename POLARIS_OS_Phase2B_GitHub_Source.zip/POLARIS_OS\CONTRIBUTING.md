# Contributing

POLARIS OS is a local AI training studio. Contributions should preserve the existing training/export behavior and avoid scattering UI styles or runtime state across the repository.

## Engineering Rules

- Keep training core changes small and testable.
- Do not commit `.venv`, model weights, datasets, LoRA outputs, GGUF files, caches, or logs.
- Prefer central UI style entry points such as `APP_CSS`, `APP_THEME`, and shared helpers.
- When changing training defaults, test low-VRAM behavior first.
- Keep legacy compatibility names only where needed for old metadata, scripts, or import paths.

## Smoke Check

```powershell
python -m py_compile main.py core\trainer.py core\utils.py core\smart_params.py
python smoke_test.py
```

For GPU changes, run a tiny LoRA job before touching larger models.
