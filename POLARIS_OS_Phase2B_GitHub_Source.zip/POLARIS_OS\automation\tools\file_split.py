from pathlib import Path

def _split_text(text, chunk_chars=2500, overlap_chars=200):
    text = str(text or '')
    chunk_chars = max(200, int(chunk_chars or 2500))
    overlap_chars = max(0, min(int(overlap_chars or 200), chunk_chars // 2))
    chunks=[]
    i=0
    n=len(text)
    while i<n:
        j=min(n, i+chunk_chars)
        if j<n:
            cut=text.rfind('\n\n', i, j)
            if cut>i+chunk_chars//3:
                j=cut
        chunks.append(text[i:j])
        if j>=n:
            break
        i=max(j-overlap_chars, i+1)
    return chunks

def run(path='', text='', encoding='utf-8', chunk_chars=2500, overlap_chars=200, emit_files=False, output_dir=''):
    if path:
        p = Path(path).expanduser().resolve()
        text = p.read_text(encoding=encoding, errors='ignore')
        base_name = p.stem
    else:
        p = None
        text = str(text or '')
        base_name = 'split'
    chunks = _split_text(text, chunk_chars=chunk_chars, overlap_chars=overlap_chars)
    written=[]
    if emit_files:
        root = Path(output_dir).expanduser().resolve() if output_dir else (Path.cwd()/f'{base_name}_parts')
        root.mkdir(parents=True, exist_ok=True)
        for idx, chunk in enumerate(chunks):
            target = root / f'{base_name}_{idx:03d}.txt'
            target.write_text(chunk, encoding='utf-8')
            written.append(str(target))
    return {'ok': True, 'path': str(p) if p else '', 'chunks': [{'idx': i, 'chars': len(c), 'preview': c[:200]} for i,c in enumerate(chunks)], 'written_files': written}
