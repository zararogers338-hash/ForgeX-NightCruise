# CUDA Troubleshooting

## CUDA out of memory during evaluation

Common cause: validation/eval creates large logits tensors, especially with label smoothing.

Fix:

```text
label_smoothing = 0
eval_ratio = 0
per_device_eval_batch_size = 1
prediction_loss_only = true
```

If OOM already happened, stop the current service and restart POLARIS OS before submitting another job. CUDA memory can remain fragmented after a hard failure.

## CUDA device-side assert

Common causes:

- tokenizer/model mismatch
- token id out of vocabulary
- sequence length exceeds model context
- corrupted CUDA context after a previous crash

Fix:

1. Restart POLARIS OS.
2. Confirm the base model and tokenizer belong together.
3. Lower `max_seq_len`.
4. Run a tiny dataset first.

## RTX 50 Series Notes

Some third-party acceleration libraries may not support Blackwell GPUs yet. POLARIS OS disables unsupported flash attention / xformers paths when needed and falls back to SDPA.
