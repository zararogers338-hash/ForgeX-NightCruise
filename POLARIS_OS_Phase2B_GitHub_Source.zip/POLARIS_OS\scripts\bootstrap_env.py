from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
STATE_FILE = DATA_DIR / "install_state.json"
MANIFEST_FILE = ROOT / "install_manifest.json"
WHEELHOUSE = ROOT / "wheelhouse"

CRITICAL_IMPORTS = {
    "torch": "torch",
    "gradio": "gradio",
    "transformers": "transformers",
    "datasets": "datasets",
    "peft": "peft",
    "trl": "trl",
    "accelerate": "accelerate",
    "yaml": "PyYAML",
    "sentencepiece": "sentencepiece",
    "google.protobuf": "protobuf",
    "psutil": "psutil",
}


def now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def emit(message: str, progress: int | None = None, stage: str | None = None) -> None:
    if progress is not None:
        print(f"::progress {int(progress)} {message}", flush=True)
    payload = {"time": now(), "stage": stage or "", "message": message}
    print("::json " + json.dumps(payload, ensure_ascii=False), flush=True)
    print(message, flush=True)


def load_json(path: Path, default: Any) -> Any:
    try:
        if path.exists() and path.stat().st_size > 0:
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def save_state(update: dict[str, Any]) -> dict[str, Any]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    state = load_json(STATE_FILE, {})
    state.update(update)
    state["updated_at"] = now()
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return state


def command_text(cmd: list[str]) -> str:
    return " ".join(f'"{x}"' if any(ch.isspace() for ch in str(x)) else str(x) for x in cmd)


def base_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    env = os.environ.copy()
    env.setdefault("PYTHONUTF8", "1")
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PIP_DISABLE_PIP_VERSION_CHECK", "1")
    env.setdefault("PIP_NO_COLOR", "1")
    env.setdefault("NO_COLOR", "1")
    if extra:
        env.update({str(k): str(v) for k, v in extra.items() if v is not None})
    return env


def run(cmd: list[str], *, cwd: Path = ROOT, dry_run: bool = False, env: dict[str, str] | None = None) -> int:
    emit(f"$ {command_text(cmd)}", stage="command")
    if dry_run:
        emit("dry-run: 已跳过执行。", stage="command")
        return 0
    proc = subprocess.Popen(
        cmd,
        cwd=str(cwd),
        env=base_env(env),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        print(line.rstrip("\n"), flush=True)
    return proc.wait()


def check_output(cmd: list[str], timeout: int = 10) -> str:
    return subprocess.check_output(
        cmd,
        cwd=str(ROOT),
        env=base_env(),
        text=True,
        encoding="utf-8",
        errors="replace",
        stderr=subprocess.STDOUT,
        timeout=timeout,
    ).strip()


def is_python_311(cmd: list[str]) -> bool:
    probe = cmd + ["-c", "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)"]
    try:
        subprocess.check_call(probe, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=base_env())
        return True
    except Exception:
        return False


def python_version(cmd: list[str]) -> str:
    try:
        return check_output(cmd + ["-c", "import sys; print(sys.version.replace('\\n', ' '))"])
    except Exception as exc:
        return f"不可用: {exc}"


def find_python(args: argparse.Namespace) -> list[str]:
    if args.simulate_no_python:
        raise RuntimeError("模拟无 Python 3.11：未找到可用解释器。")
    candidates: list[list[str]] = []
    if args.python_cmd:
        candidates.append(args.python_cmd)
    if args.python_exe:
        candidates.append([args.python_exe])
    env_python = os.environ.get("POLARIS_OS_PYTHON") or os.environ.get("FORGEX_PYTHON")
    if env_python:
        candidates.append([env_python])
    candidates.extend([
        ["py", "-3.11"],
        ["python3.11"],
        ["python"],
    ])
    seen: set[str] = set()
    for cmd in candidates:
        key = "\0".join(cmd)
        if key in seen:
            continue
        seen.add(key)
        exe = shutil.which(cmd[0]) if len(cmd) == 1 else shutil.which(cmd[0])
        if not exe and not Path(cmd[0]).exists():
            continue
        if is_python_311(cmd):
            emit(f"检测到 Python 3.11: {command_text(cmd)} | {python_version(cmd)}", 10, "python")
            return cmd
    raise RuntimeError("未找到 Python 3.11。请在安装器中点击“一键安装 Python 3.11”，或安装后重新检测。")


def venv_python(venv: Path) -> Path:
    if os.name == "nt":
        return venv / "Scripts" / "python.exe"
    return venv / "bin" / "python"


def ensure_venv(base_python: list[str], venv_dir: Path, *, dry_run: bool = False) -> Path:
    py = venv_python(venv_dir)
    if py.exists() and is_python_311([str(py)]):
        emit(f"复用现有虚拟环境: {py}", 18, "venv")
    else:
        if venv_dir.exists():
            backup = venv_dir.with_name(venv_dir.name + ".python-mismatch." + time.strftime("%Y%m%d_%H%M%S"))
            emit(f"现有虚拟环境不是 Python 3.11，备份到: {backup}", 16, "venv")
            if not dry_run:
                venv_dir.rename(backup)
        emit(f"创建虚拟环境: {venv_dir}", 18, "venv")
        rc = run(base_python + ["-m", "venv", str(venv_dir)], dry_run=dry_run)
        if rc != 0:
            raise RuntimeError("创建 venv 失败。请检查安装目录权限和 Python venv 模块。")
    return py


def module_imports(py: Path, module: str) -> bool:
    cmd = [str(py), "-c", f"import importlib; importlib.import_module({module!r})"]
    try:
        subprocess.check_call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=base_env())
        return True
    except Exception:
        return False


def torch_satisfies_backend(py: Path, backend: str) -> bool:
    code = r"""
import sys
try:
    import torch
except Exception:
    raise SystemExit(1)
backend = sys.argv[1]
if backend == "cpu":
    raise SystemExit(0)
raise SystemExit(0 if torch.cuda.is_available() else 1)
"""
    try:
        subprocess.check_call([str(py), "-c", code, backend], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=base_env())
        return True
    except Exception:
        return False


def missing_core_modules(py: Path) -> list[str]:
    return [label for module, label in CRITICAL_IMPORTS.items() if not module_imports(py, module)]


def detect_gpu() -> dict[str, Any]:
    info: dict[str, Any] = {
        "backend_recommended": "cpu",
        "nvidia": False,
        "name": "",
        "vram_mb": 0,
        "driver": "",
        "cuda": "",
        "compute_cap": "",
        "amd_or_npu_hint": "",
    }
    try:
        out = check_output([
            "nvidia-smi",
            "--query-gpu=name,memory.total,driver_version,compute_cap",
            "--format=csv,noheader,nounits",
        ], timeout=8)
        first = [part.strip() for part in out.splitlines()[0].split(",")]
        if first:
            info.update({
                "nvidia": True,
                "backend_recommended": "cuda",
                "name": first[0],
                "vram_mb": int(float(first[1])) if len(first) > 1 and first[1] else 0,
                "driver": first[2] if len(first) > 2 else "",
                "compute_cap": first[3] if len(first) > 3 else "",
            })
        try:
            smi = check_output(["nvidia-smi"], timeout=8)
            marker = "CUDA Version:"
            if marker in smi:
                info["cuda"] = smi.split(marker, 1)[1].split()[0].strip()
        except Exception:
            pass
    except Exception:
        pass
    if not info["nvidia"] and os.name == "nt":
        try:
            video = check_output(["wmic", "path", "win32_VideoController", "get", "name"], timeout=8)
            names = [line.strip() for line in video.splitlines() if line.strip() and line.strip().lower() != "name"]
            hints = [n for n in names if any(k in n.lower() for k in ("amd", "radeon", "arc", "npu", "neural"))]
            if hints:
                info["amd_or_npu_hint"] = "; ".join(hints)
        except Exception:
            pass
    return info


def torch_index_for(gpu: dict[str, Any], backend: str) -> tuple[str, str]:
    if backend == "cpu" or not gpu.get("nvidia"):
        return "cpu", "https://download.pytorch.org/whl/cpu"
    cuda = str(gpu.get("cuda") or "")
    compute = str(gpu.get("compute_cap") or "")
    try:
        cuda_f = float(".".join(cuda.split(".")[:2])) if cuda else 0.0
    except Exception:
        cuda_f = 0.0
    try:
        cap_f = float(compute) if compute else 0.0
    except Exception:
        cap_f = 0.0
    if cap_f >= 12.0 or cuda_f >= 12.8:
        return "cu128", "https://download.pytorch.org/whl/cu128"
    if cuda_f >= 12.6:
        return "cu126", "https://download.pytorch.org/whl/cu126"
    if cuda_f >= 12.4 or cuda_f == 0.0:
        return "cu124", "https://download.pytorch.org/whl/cu124"
    emit(f"检测到 NVIDIA，但 CUDA/驱动版本较低 ({cuda})，改用 CPU fallback。", 28, "gpu")
    return "cpu", "https://download.pytorch.org/whl/cpu"


def pip_base_args() -> list[str]:
    args = ["-m", "pip", "install", "--prefer-binary", "--upgrade-strategy", "only-if-needed"]
    wheels = list(WHEELHOUSE.glob("*.whl")) if WHEELHOUSE.exists() else []
    if wheels:
        args.extend(["--find-links", str(WHEELHOUSE)])
    return args


def install_python_tools(py: Path, *, dry_run: bool) -> None:
    emit("检查 pip / setuptools / wheel...", 24, "pip")
    rc = run([str(py), *pip_base_args(), "--upgrade", "pip", "setuptools", "wheel", "packaging"], dry_run=dry_run)
    if rc != 0:
        raise RuntimeError("pip 基础工具安装失败。可尝试切换网络或清理 pip 缓存后重试。")


def install_torch(py: Path, backend: str, gpu: dict[str, Any], *, dry_run: bool) -> None:
    if torch_satisfies_backend(py, backend):
        emit(f"PyTorch 已满足当前后端: {backend}", 35, "torch")
        return
    label, index = torch_index_for(gpu, backend)
    emit(f"安装 PyTorch 预编译 wheel: {label}", 35, "torch")
    rc = run([str(py), *pip_base_args(), "torch", "torchvision", "torchaudio", "--index-url", index], dry_run=dry_run)
    if rc != 0:
        raise RuntimeError("PyTorch 安装失败。请检查网络、磁盘空间，或切换 CPU fallback 后重试。")


def install_requirements(py: Path, *, dry_run: bool) -> None:
    missing = missing_core_modules(py)
    if not missing:
        emit("核心依赖已满足，跳过重复下载。", 55, "deps")
        return
    emit("缺少依赖: " + ", ".join(missing), 45, "deps")
    cmd = [str(py), *pip_base_args(), "-r", str(ROOT / "requirements.txt")]
    constraints = ROOT / "constraints.txt"
    if constraints.exists():
        cmd.extend(["-c", str(constraints)])
    rc = run(cmd, dry_run=dry_run)
    if rc != 0:
        raise RuntimeError("依赖安装失败。安装日志中最后一个 ERROR 通常就是原因；可点击“重试依赖安装”。")


def configure_paths(args: argparse.Namespace, py: Path, backend: str, gpu: dict[str, Any],
                    *, dry_run: bool = False) -> dict[str, Any]:
    models_dir = Path(args.models_dir).expanduser() if args.models_dir else ROOT / "data" / "models_cache"
    cache_dir = Path(args.cache_dir).expanduser() if args.cache_dir else models_dir
    logs_dir = Path(args.logs_dir).expanduser() if args.logs_dir else Path(os.environ.get("LOCALAPPDATA", str(ROOT / "data"))) / "POLARIS OS" / "logs"
    state = {
        "schema": 1,
        "install_dir": str(ROOT),
        "python": {
            "venv_python": str(py),
            "version": python_version([str(py)]),
        },
        "backend": backend,
        "gpu": gpu,
        "paths": {
            "models_cache": str(models_dir),
            "hf_cache": str(cache_dir),
            "logs": str(logs_dir),
        },
        "shortcuts": {},
    }
    if dry_run:
        emit("dry-run: 已跳过目录创建和 install_state.json 写入。", 80, "state")
        return state
    for path in (models_dir, cache_dir, logs_dir):
        path.mkdir(parents=True, exist_ok=True)
    return save_state(state)


def run_healthcheck(py: Path, *, dry_run: bool) -> None:
    health = ROOT / "scripts" / "healthcheck.py"
    if not health.exists():
        emit("未找到 healthcheck.py，跳过自检。", 85, "health")
        return
    emit("运行安装后自检...", 85, "health")
    rc = run([str(py), str(health), "--project-dir", str(ROOT)], dry_run=dry_run)
    if rc != 0:
        raise RuntimeError("安装后自检失败。请查看上方检查项并点击修复或重试。")


def bootstrap(args: argparse.Namespace) -> int:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    emit("POLARIS OS Windows 环境安装开始。", 3, "start")
    base_py = find_python(args)
    venv_dir = Path(args.venv_dir).expanduser() if args.venv_dir else ROOT / ".venv"
    vpy = ensure_venv(base_py, venv_dir, dry_run=args.dry_run)
    gpu = detect_gpu()
    backend = args.backend
    if backend == "auto":
        backend = str(gpu.get("backend_recommended") or "cpu")
    if backend not in ("cuda", "cpu"):
        emit(f"当前暂不强制支持 {backend}，已切换 CPU fallback。", 22, "gpu")
        backend = "cpu"
    if gpu.get("nvidia"):
        emit(
            f"GPU: {gpu.get('name')} | VRAM {gpu.get('vram_mb')} MB | Driver {gpu.get('driver')} | CUDA {gpu.get('cuda')}",
            22,
            "gpu",
        )
    elif gpu.get("amd_or_npu_hint"):
        emit(f"识别到非 NVIDIA 加速设备: {gpu.get('amd_or_npu_hint')}；当前使用 CPU fallback。", 22, "gpu")
    else:
        emit("未识别到 NVIDIA CUDA，使用 CPU fallback。", 22, "gpu")

    install_python_tools(vpy, dry_run=args.dry_run)
    if not args.no_install_deps:
        install_torch(vpy, backend, gpu, dry_run=args.dry_run)
        install_requirements(vpy, dry_run=args.dry_run)
    else:
        emit("已按参数跳过依赖安装。", 55, "deps")
    state = configure_paths(args, vpy, backend, gpu, dry_run=args.dry_run)
    if not args.dry_run:
        emit(f"安装状态已保存: {STATE_FILE}", 80, "state")
    if args.run_healthcheck:
        run_healthcheck(vpy, dry_run=args.dry_run)
    state["steps"] = {
        "python": "ok",
        "venv": "ok",
        "dependencies": "skipped" if args.no_install_deps else "ok",
        "healthcheck": "ok" if args.run_healthcheck else "not_run",
    }
    if not args.dry_run:
        save_state(state)
    emit("POLARIS OS 环境安装完成。", 100, "done")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="POLARIS OS Windows bootstrapper")
    parser.add_argument("--project-dir", default=str(ROOT), help="Reserved for installer compatibility.")
    parser.add_argument("--python-exe", default="")
    parser.add_argument("--python-cmd", nargs="+")
    parser.add_argument("--venv-dir", default=str(ROOT / ".venv"))
    parser.add_argument("--backend", choices=["auto", "cuda", "cpu"], default="auto")
    parser.add_argument("--models-dir", default="")
    parser.add_argument("--cache-dir", default="")
    parser.add_argument("--logs-dir", default="")
    parser.add_argument("--no-install-deps", action="store_true")
    parser.add_argument("--run-healthcheck", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--simulate-no-python", action="store_true")
    args = parser.parse_args()
    try:
        return bootstrap(args)
    except Exception as exc:
        emit(f"错误: {exc}", 0, "error")
        if not args.dry_run:
            save_state({"last_error": str(exc), "last_error_at": now()})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
