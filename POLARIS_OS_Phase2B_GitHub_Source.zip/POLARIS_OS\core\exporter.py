# core/exporter.py - ForgeX v2.7 導出：GGUF / Ollama
# 修復：gguf 包版本不兼容 convert_hf_to_gguf.py 的 MistralTokenizerType 問題
import shutil
import os
import sys
import json
from pathlib import Path
from typing import Optional

from core import LORAS_DIR, log, run_subprocess, get_timestamp
from core.task_queue import Task

GGUF_QUANT_TYPES = ["Q4_K_M", "Q5_K_M", "Q6_K", "Q8_0", "F16"]
DIRECT_SCRIPT_OUTTYPES = {"F16": "f16", "Q8_0": "q8_0"}


def _write_gguf_source_sidecar(gguf_path: Path, source_model_dir: Path, quant_type: str = "", tokenizer_source: str = ""):
    try:
        payload = {
            "gguf_path": str(gguf_path),
            "source_model_dir": str(source_model_dir),
            "source_model_name": source_model_dir.name if source_model_dir else "",
            "quant_type": str(quant_type or ""),
            "tokenizer_source": str(tokenizer_source or ""),
        }
        sidecars = [gguf_path.parent / "forgex_gguf_source.json", Path(str(gguf_path) + ".forgex.json")]
        for sp in sidecars:
            sp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"写入 GGUF 来源信息失败: {e}")


def _is_problematic_tokenizer_class(tokenizer_class: str) -> bool:
    tc = str(tokenizer_class or '').strip()
    if not tc:
        return False
    bad_exact = {"TokenizersBackend", "TokenizerBackend"}
    if tc in bad_exact:
        return True
    return tc.endswith("Backend") and "Tokenizer" in tc


def _repair_tokenizer_config_if_needed(model_dir: Path) -> tuple[bool, str]:
    tc_path = model_dir / "tokenizer_config.json"
    if not tc_path.exists():
        return False, ""
    try:
        raw = tc_path.read_text(encoding='utf-8')
        data = json.loads(raw)
    except Exception as e:
        return False, f"读取 tokenizer_config.json 失败: {e}"

    changed = False
    notes = []

    tokenizer_class = data.get("tokenizer_class", "")
    if _is_problematic_tokenizer_class(tokenizer_class):
        data.pop("tokenizer_class", None)
        auto_map = data.get("auto_map")
        if isinstance(auto_map, str) and _is_problematic_tokenizer_class(auto_map):
            data.pop("auto_map", None)
        elif isinstance(auto_map, (list, tuple)) and any(_is_problematic_tokenizer_class(x) for x in auto_map):
            data.pop("auto_map", None)
        elif isinstance(auto_map, dict):
            cleaned = {k: v for k, v in auto_map.items() if not _is_problematic_tokenizer_class(v)}
            if cleaned:
                data["auto_map"] = cleaned
            else:
                data.pop("auto_map", None)
        data["forgex_repaired_invalid_tokenizer_class"] = tokenizer_class
        notes.append(f"移除无效 tokenizer_class={tokenizer_class}")
        changed = True

    for bad_key in ("vocab_file", "tokenizer_file"):
        if bad_key in data and not (isinstance(data.get(bad_key), str) and str(data.get(bad_key)).strip()):
            data.pop(bad_key, None)
            notes.append(f"清理无效字段 {bad_key}")
            changed = True

    model_type = ""
    try:
        cfg_path = model_dir / "config.json"
        if cfg_path.exists():
            cfg = json.loads(cfg_path.read_text(encoding='utf-8'))
            model_type = str(cfg.get('model_type', '') or '').strip().lower()
    except Exception:
        pass

    tok_model = model_dir / 'tokenizer.model'
    llama_like = model_type in {'llama', 'mistral', 'mixtral', 'yi'}
    if tok_model.exists() and tok_model.stat().st_size > 0 and llama_like:
        if data.get('tokenizer_class') != 'LlamaTokenizer':
            data['tokenizer_class'] = 'LlamaTokenizer'
            notes.append('强制使用 LlamaTokenizer 慢速 tokenizer')
            changed = True
        if data.get('use_fast', True) is not False:
            data['use_fast'] = False
            changed = True
        if data.get('vocab_file') != 'tokenizer.model':
            data['vocab_file'] = 'tokenizer.model'
            changed = True

    if not changed:
        return False, ""

    backup = model_dir / "tokenizer_config.forgex.backup.json"
    try:
        if not backup.exists():
            backup.write_text(raw, encoding='utf-8')
        tc_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
        return True, '；'.join(notes) if notes else '已修复 tokenizer_config.json'
    except Exception as e:
        return False, f"修复 tokenizer_config.json 失败: {e}"


def _extract_conversion_error(stderr: str, stdout: str) -> str:
    merged = ((stderr or "") + "\n" + (stdout or "")).strip()
    return merged[-1200:] if merged else ""


def _looks_like_invalid_tokenizer_class_error(text: str) -> bool:
    t = str(text or '')
    return ("Tokenizer class" in t and "does not exist" in t) or ("TokenizersBackend" in t)


def _looks_like_missing_protobuf_error(text: str) -> bool:
    t = str(text or '')
    return ("requires the protobuf library" in t) or ("No module named 'google.protobuf'" in t)


def _looks_like_missing_sentencepiece_error(text: str) -> bool:
    t = str(text or '')
    return ("sentencepiece" in t.lower() and ("not found" in t.lower() or "No module named" in t or "requires" in t.lower()))


def _get_hf_cache_roots() -> list[Path]:
    roots: list[Path] = []
    try:
        from huggingface_hub.constants import HF_HUB_CACHE
        roots.append(Path(HF_HUB_CACHE))
    except Exception:
        pass
    home = Path(os.path.expanduser('~'))
    for c in [home / '.cache' / 'huggingface' / 'hub', Path(os.environ.get('HF_HOME', '')) / 'hub' if os.environ.get('HF_HOME') else None, Path(os.environ.get('TRANSFORMERS_CACHE', '')) if os.environ.get('TRANSFORMERS_CACHE') else None]:
        if c and c.is_dir() and c not in roots:
            roots.append(c)
    return roots


def _ensure_runtime_package(import_name: str, pip_spec: str, progress_cb=None) -> tuple[bool, str]:
    try:
        __import__(import_name)
        return True, f"{import_name} 已可用"
    except Exception:
        pass

    if progress_cb:
        progress_cb(14, f"安装导出依赖: {pip_spec} ...")
    try:
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", pip_spec],
            capture_output=True, text=True, timeout=240,
        )
        if result.returncode != 0:
            merged = ((result.stderr or "") + "\n" + (result.stdout or "")).strip()[-500:]
            return False, merged or f"pip install {pip_spec} 失败"
        __import__(import_name)
        return True, f"已安装 {pip_spec}"
    except Exception as e:
        return False, str(e)


def _resolve_local_or_cached_model_dir(model_ref: str) -> Optional[Path]:
    """将本地路径 / HF 模型名解析到可用目录。"""
    ref = str(model_ref or '').strip()
    if not ref:
        return None
    p = Path(ref)
    if p.is_dir():
        return _resolve_hf_snapshot_dir(p)

    try:
        from huggingface_hub import snapshot_download
        cache_dir = snapshot_download(ref, local_files_only=True)
        return _resolve_hf_snapshot_dir(Path(cache_dir))
    except Exception:
        pass

    try:
        from huggingface_hub import try_to_load_from_cache
        cached = try_to_load_from_cache(ref, 'config.json')
        if cached and isinstance(cached, str) and Path(cached).exists():
            return _resolve_hf_snapshot_dir(Path(cached).parent)
    except Exception:
        pass

    cache_dirs = _get_hf_cache_roots()

    safe_name = ref.replace('/', '--')
    for cd in cache_dirs:
        try:
            model_dir = cd / f'models--{safe_name}'
            if model_dir.is_dir():
                return _resolve_hf_snapshot_dir(model_dir)
        except Exception:
            pass
    return None


_TOKENIZER_SIDE_FILES = [
    'tokenizer.model', 'tokenizer.json', 'special_tokens_map.json',
    'added_tokens.json', 'tokenizer_config.json', 'sentencepiece.bpe.model',
]


def _collect_tokenizer_donor_refs(model_dir: Path) -> list[str]:
    refs: list[str] = []

    def _push(v):
        s = str(v or '').strip()
        if s and s not in refs:
            refs.append(s)

    for name in ['forgex_merge_recipe.json', 'forgex_native_merge_recipe.json']:
        try:
            fp = model_dir / name
            if fp.exists():
                meta = json.loads(fp.read_text(encoding='utf-8'))
                _push(meta.get('base_model'))
        except Exception:
            pass

    for name in ['adapter_config.json', 'config.json', 'tokenizer_config.json']:
        try:
            fp = model_dir / name
            if not fp.exists():
                continue
            data = json.loads(fp.read_text(encoding='utf-8'))
            for key in ['base_model_name_or_path', 'base_model_name', '_name_or_path', 'name_or_path']:
                _push(data.get(key))
        except Exception:
            pass

    return refs


def _read_json_file(path: Path) -> dict:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        pass
    return {}


def _model_signature(model_dir: Path) -> dict:
    cfg = _read_json_file(model_dir / 'config.json')
    tok_cfg = _read_json_file(model_dir / 'tokenizer_config.json')
    return {
        'model_type': str(cfg.get('model_type', '') or '').strip().lower(),
        'vocab_size': cfg.get('vocab_size'),
        'hidden_size': cfg.get('hidden_size'),
        'tokenizer_class': str(tok_cfg.get('tokenizer_class', '') or '').strip(),
    }


def _score_tokenizer_donor(target_sig: dict, donor_dir: Path) -> int:
    try:
        if not (donor_dir / 'tokenizer.model').exists():
            return -1
        donor_sig = _model_signature(donor_dir)
        score = 0
        if target_sig.get('model_type') and donor_sig.get('model_type') == target_sig.get('model_type'):
            score += 50
        if target_sig.get('vocab_size') and donor_sig.get('vocab_size') == target_sig.get('vocab_size'):
            score += 40
        if target_sig.get('hidden_size') and donor_sig.get('hidden_size') == target_sig.get('hidden_size'):
            score += 15
        if donor_sig.get('tokenizer_class') == 'LlamaTokenizer':
            score += 5
        score += int(donor_dir.stat().st_mtime // 1) % 5
        return score
    except Exception:
        return -1


def _iter_local_tokenizer_candidates(model_dir: Path):
    seen = set()

    def _yield_dir(p: Path):
        try:
            rp = p.resolve()
        except Exception:
            rp = p
        key = str(rp)
        if key in seen:
            return
        seen.add(key)
        if p.is_dir() and p != model_dir and (p / 'tokenizer.model').exists():
            yield p

    # 同级/项目内目录
    search_roots = []
    for root in [model_dir.parent, LORAS_DIR, model_dir.parent.parent if model_dir.parent != model_dir.parent.parent else None]:
        if root and root.is_dir() and root not in search_roots:
            search_roots.append(root)
    for root in search_roots:
        try:
            for child in root.iterdir():
                if child.is_dir():
                    yield from _yield_dir(child)
        except Exception:
            pass

    # HF cache snapshots
    for cache_root in _get_hf_cache_roots():
        try:
            for model_root in cache_root.glob('models--*'):
                snaps = model_root / 'snapshots'
                if snaps.is_dir():
                    for snap in snaps.iterdir():
                        if snap.is_dir():
                            yield from _yield_dir(snap)
                else:
                    yield from _yield_dir(model_root)
        except Exception:
            pass


def _choose_best_tokenizer_donor(model_dir: Path, preferred_ref: str = '') -> Path | None:
    target_sig = _model_signature(model_dir)
    candidates: list[tuple[int, Path]] = []

    def _consider(p: Path, bonus: int = 0):
        if not p or not p.exists() or p.resolve() == model_dir.resolve() or not (p / 'tokenizer.model').exists():
            return
        score = _score_tokenizer_donor(target_sig, p)
        if score >= 0:
            candidates.append((score + bonus, p))

    if preferred_ref:
        donor = _resolve_local_or_cached_model_dir(preferred_ref)
        if donor:
            _consider(donor, 1000)

    for ref in _collect_tokenizer_donor_refs(model_dir):
        donor = _resolve_local_or_cached_model_dir(ref)
        if donor:
            _consider(donor, 500)

    # 当前目录里如果有 _name_or_path / name_or_path，尝试把最后一个段名当作提示词搜索
    target_name = Path(str((_read_json_file(model_dir / 'config.json').get('_name_or_path') or '') or '')).name.lower()
    for cand in _iter_local_tokenizer_candidates(model_dir):
        bonus = 0
        if target_name and target_name in cand.name.lower():
            bonus += 100
        _consider(cand, bonus)

    if not candidates:
        return None
    candidates.sort(key=lambda x: (x[0], x[1].stat().st_mtime), reverse=True)
    return candidates[0][1]


def _force_sentencepiece_slow_tokenizer(model_dir: Path) -> tuple[bool, str]:
    tc_path = model_dir / 'tokenizer_config.json'
    if not tc_path.exists():
        data = {}
    else:
        data = _read_json_file(tc_path)
    tok_model = model_dir / 'tokenizer.model'
    if not tok_model.exists() or tok_model.stat().st_size <= 0:
        return False, ''
    cfg = _read_json_file(model_dir / 'config.json')
    model_type = str(cfg.get('model_type', '') or '').strip().lower()
    if model_type not in {'llama', 'mistral', 'mixtral', 'yi'}:
        return False, ''
    raw = tc_path.read_text(encoding='utf-8') if tc_path.exists() else ''
    changed = False
    if data.get('tokenizer_class') != 'LlamaTokenizer':
        data['tokenizer_class'] = 'LlamaTokenizer'
        changed = True
    if data.get('use_fast', True) is not False:
        data['use_fast'] = False
        changed = True
    if data.get('vocab_file') != 'tokenizer.model':
        data['vocab_file'] = 'tokenizer.model'
        changed = True
    tf = data.get('tokenizer_file')
    if tf and not isinstance(tf, str):
        data.pop('tokenizer_file', None)
        changed = True
    if not changed:
        return False, ''
    backup = model_dir / 'tokenizer_config.forgex.backup.json'
    try:
        if raw and not backup.exists():
            backup.write_text(raw, encoding='utf-8')
        tc_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
        return True, '已切换到 LlamaTokenizer 慢速模式并指定 tokenizer.model'
    except Exception as e:
        return False, f'强制 sentencepiece tokenizer 失败: {e}'



def _repair_tokenizer_assets_if_needed(model_dir: Path, preferred_ref: str = '') -> tuple[bool, str]:
    """尽量补齐 tokenizer.model 等文件，修复 SentencePiece LLaMA 导出失败。"""
    if (model_dir / 'tokenizer.model').exists() and (model_dir / 'tokenizer.model').stat().st_size > 0:
        # 即便已有 tokenizer.model，也顺手修一下 tokenizer_config，避免 fast->slow 时 vocab_file 为 None
        repaired_cfg, cfg_msg = _force_sentencepiece_slow_tokenizer(model_dir)
        return repaired_cfg, cfg_msg

    donor = _choose_best_tokenizer_donor(model_dir, preferred_ref=preferred_ref)
    if not donor:
        return False, ''

    copied = []
    try:
        for name in _TOKENIZER_SIDE_FILES:
            src = donor / name
            dst = model_dir / name
            if src.exists() and (not dst.exists() or (name == 'tokenizer.model' and dst.stat().st_size <= 0)):
                shutil.copy2(src, dst)
                copied.append(name)
        repaired_cfg, cfg_msg = _force_sentencepiece_slow_tokenizer(model_dir)
        if repaired_cfg and cfg_msg:
            copied.append('tokenizer_config.json(repaired)')
        meta_path = model_dir / 'forgex_tokenizer_repair.json'
        meta = {
            'source': str(donor),
            'copied': copied,
        }
        meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
        if (model_dir / 'tokenizer.model').exists():
            return True, f'已从基座/候选模型补齐 tokenizer 资源: {donor}'
    except Exception as e:
        return False, f'补齐 tokenizer 资源失败: {e}'

    return False, ''


def _looks_like_sentencepiece_vocab_file_error(text: str) -> bool:
    t = str(text or '')
    return ('SentencePieceProcessor_LoadFromFile' in t and 'TypeError: not a string' in t) or ('vocab_file' in t and 'not a string' in t)


def _has_model_weights(model_dir: Path) -> bool:
    if any((model_dir / f).exists() for f in [
        "model.safetensors", "model.safetensors.index.json",
        "pytorch_model.bin", "pytorch_model.bin.index.json",
    ]):
        return True
    return any(any(model_dir.glob(pat)) for pat in [
        "model-*.safetensors", "pytorch_model-*.bin",
        "consolidated*.safetensors", "*.gguf",
    ])


def _resolve_hf_snapshot_dir(model_dir: Path) -> Path:
    """如果传入的是 HF cache 根目录，自动落到最新 snapshot。"""
    if (model_dir / "config.json").exists():
        return model_dir
    snap_dir = model_dir / "snapshots"
    if not snap_dir.exists():
        return model_dir
    best = None
    best_mtime = -1.0
    for s in snap_dir.iterdir():
        if s.is_dir() and (s / "config.json").exists():
            mtime = s.stat().st_mtime
            if mtime > best_mtime:
                best = s
                best_mtime = mtime
    return best or model_dir


def _which(name: str) -> str | None:
    return shutil.which(name)


def _check_gguf_version() -> dict:
    """检测 gguf 包版本及兼容性"""
    info = {"installed": False, "version": "", "has_mistral": False, "path": ""}
    try:
        import gguf
        info["installed"] = True
        info["version"] = getattr(gguf, "__version__", "unknown")
        info["path"] = str(Path(gguf.__file__).parent)
        try:
            from gguf.vocab import MistralTokenizerType  # noqa: F401
            info["has_mistral"] = True
        except ImportError:
            info["has_mistral"] = False
    except ImportError:
        pass
    return info


def _try_upgrade_gguf(progress_cb=None) -> bool:
    """尝试升级 gguf 包以匹配最新 convert_hf_to_gguf.py"""
    if progress_cb:
        progress_cb(15, "尝试升级 gguf 包...")

    # 方法 1: pip install 最新 gguf from PyPI
    try:
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "gguf", "--quiet"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            import importlib
            try:
                import gguf
                importlib.reload(gguf)
                from gguf import vocab as _v
                importlib.reload(_v)
                from gguf.vocab import MistralTokenizerType  # noqa: F401
                log("✅ gguf 包升级成功（PyPI）")
                return True
            except ImportError:
                pass
    except Exception as e:
        log(f"PyPI 升级 gguf 失败: {e}")

    # 方法 2: 从 llama.cpp GitHub 安装最新 gguf-py
    try:
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "gguf @ git+https://github.com/ggml-org/llama.cpp.git@master#subdirectory=gguf-py",
             "--quiet", "--force-reinstall"],
            capture_output=True, text=True, timeout=180,
        )
        if result.returncode == 0:
            log("✅ gguf 包升级成功（llama.cpp GitHub）")
            return True
        log(f"GitHub 安装 gguf 失败: {result.stderr[:300]}")
    except Exception as e:
        log(f"GitHub 安装 gguf 失败: {e}")

    return False


def _download_convert_script(dest_dir: Path) -> Optional[Path]:
    """从 llama.cpp GitHub 下载最新 convert_hf_to_gguf.py"""
    url = "https://raw.githubusercontent.com/ggml-org/llama.cpp/refs/heads/master/convert_hf_to_gguf.py"
    dest = dest_dir / "convert_hf_to_gguf_latest.py"
    try:
        import urllib.request
        log(f"下载最新 convert_hf_to_gguf.py ...")
        urllib.request.urlretrieve(url, str(dest))
        if dest.exists() and dest.stat().st_size > 10000:
            log(f"✅ 下载成功: {dest}")
            return dest
    except Exception as e:
        log(f"下载 convert_hf_to_gguf.py 失败: {e}")
    return None


def _find_convert_scripts() -> list:
    """搜索所有可用的 convert_hf_to_gguf.py 脚本"""
    candidates = []

    # 1. llama.cpp 仓库（最稳定）
    for p in [Path.cwd() / "llama.cpp", Path.home() / "llama.cpp",
              Path("D:/llama.cpp"), Path("C:/llama.cpp")]:
        try:
            script = p / "convert_hf_to_gguf.py"
            if script.exists():
                candidates.append({
                    "path": script, "source": "llama.cpp repo",
                    "priority": 1, "has_gguf_py": (p / "gguf-py").exists(),
                })
        except Exception:
            pass

    # 2. llama-cpp-python 附带
    try:
        import importlib.util
        spec = importlib.util.find_spec("llama_cpp")
        if spec and spec.submodule_search_locations:
            pkg_dir = Path(list(spec.submodule_search_locations)[0])
            for p in pkg_dir.parent.rglob("convert_hf_to_gguf.py"):
                candidates.append({
                    "path": p, "source": "llama-cpp-python",
                    "priority": 3, "has_gguf_py": False,
                })
                break
    except Exception:
        pass

    # 3. site-packages/bin 目录
    for site_dir in [Path(sys.prefix) / "Lib" / "site-packages" / "bin",
                     Path(sys.prefix) / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages" / "bin"]:
        try:
            script = site_dir / "convert_hf_to_gguf.py"
            if script.exists() and not any(c["path"] == script for c in candidates):
                candidates.append({
                    "path": script, "source": "site-packages/bin",
                    "priority": 3, "has_gguf_py": False,
                })
        except Exception:
            pass

    candidates.sort(key=lambda x: x["priority"])
    return candidates


def _find_quantize_bin() -> Optional[str]:
    """搜索 quantize / llama-quantize 二进制。

    兼容 Windows Release/RelWithDebInfo 构建目录，以及新版 llama.cpp
    的 llama-quantize / llama-quantize.exe 命名。
    """
    names = [
        "llama-quantize", "llama-quantize.exe",
        "quantize", "quantize.exe",
    ]
    for name in names:
        p = shutil.which(name)
        if p:
            return p

    repo_candidates = [
        Path.cwd() / "llama.cpp",
        Path.home() / "llama.cpp",
        Path("D:/llama.cpp"),
        Path("C:/llama.cpp"),
    ]
    subpaths = [
        "build/bin/llama-quantize", "build/bin/llama-quantize.exe",
        "build/bin/quantize", "build/bin/quantize.exe",
        "build/bin/Release/llama-quantize.exe", "build/bin/Release/quantize.exe",
        "build/bin/RelWithDebInfo/llama-quantize.exe", "build/bin/RelWithDebInfo/quantize.exe",
        "build/Release/llama-quantize.exe", "build/Release/quantize.exe",
        "build/RelWithDebInfo/llama-quantize.exe", "build/RelWithDebInfo/quantize.exe",
        "llama-quantize", "llama-quantize.exe",
        "quantize", "quantize.exe",
    ]
    for repo in repo_candidates:
        for sub in subpaths:
            p = repo / sub
            if p.exists():
                return str(p)
    return None


class Exporter:
    """模型導出 - GGUF 量化 + Ollama"""

    def export_gguf(
        self,
        model_path: str = "",
        model_dir: str = "",
        quant_type: str = "Q4_K_M",
        quant: str = "",
        output_name: str = "",
        tokenizer_source: str = "",
        task: Optional[Task] = None,
    ) -> Path:
        progress_cb = task.update_progress if task else (lambda p, m="": log(m))

        model_path = model_path or model_dir
        quant_type = (quant or quant_type).upper()

        if quant_type not in GGUF_QUANT_TYPES:
            raise ValueError(f"不支持的量化類型: {quant_type}（支持: {', '.join(GGUF_QUANT_TYPES)}）")
        if not model_path:
            raise ValueError("请指定模型路徑")

        model_dir = _resolve_hf_snapshot_dir(Path(model_path))
        if not model_dir.exists():
            raise FileNotFoundError(f"模型不存在: {model_path}")
        if model_dir.is_file():
            raise ValueError(f"❌ GGUF 导出只接受模型目录，不接受单个文件: {model_dir}")

        # ============================================================
        # 关键检测: 是 LoRA 适配器 还是 完整模型？
        # ============================================================
        is_lora = (model_dir / "adapter_config.json").exists()
        has_config = (model_dir / "config.json").exists()
        has_model_weights = _has_model_weights(model_dir)

        if is_lora and not has_config:
            # 这是一个 LoRA 适配器目录，不能直接转 GGUF
            # 需要先合并到基座模型
            progress_cb(3, "⚠️ 检测到 LoRA 适配器，需要先合并到基座模型...")

            # 从 adapter_config.json 读取原始基座模型
            base_model = None
            try:
                import json
                adapter_cfg = json.loads((model_dir / "adapter_config.json").read_text(encoding="utf-8"))
                base_model = adapter_cfg.get("base_model_name_or_path", "")
            except Exception:
                pass

            if not base_model:
                raise ValueError(
                    f"❌ 你选择的是 LoRA 适配器目录（{model_dir.name}），不能直接导出 GGUF。\n\n"
                    "LoRA 适配器只包含微调的差异权重（adapter_config.json + adapter_model.safetensors），\n"
                    "没有完整的模型权重（config.json），无法直接转换为 GGUF。\n\n"
                    "正确步骤:\n"
                    "  1. 先到「🚀 部署导出」→「🔀 LoRA 合并」\n"
                    "  2. 选择基座模型 + LoRA 适配器 → 点击合并\n"
                    "  3. 合并完成后，用合并后的模型目录来导出 GGUF\n\n"
                    "无法自动合并：adapter_config.json 中未记录基座模型路径。"
                )

            # 自动合并
            progress_cb(5, f"🔀 自动合并 LoRA 到基座模型: {base_model}")
            try:
                from core.merger import merger
                merge_name = output_name or f"{model_dir.name}_merged"
                merged_dir = merger.merge_lora_to_base(
                    base_model=base_model,
                    lora_path=str(model_dir),
                    output_name=merge_name + "_full",
                    task=task,
                )
                progress_cb(50, f"✅ 合并完成: {merged_dir}")
                model_dir = Path(merged_dir)
                log(f"LoRA 已自动合并，继续导出 GGUF: {model_dir}")
            except Exception as e:
                raise RuntimeError(
                    f"❌ 自动合并 LoRA 失败。\n\n"
                    f"LoRA 适配器: {model_path}\n"
                    f"基座模型（自动检测）: {base_model}\n"
                    f"错误: {e}\n\n"
                    "请手动操作:\n"
                    "  1. 到「🚀 部署导出」→「🔀 LoRA 合并」\n"
                    "  2. 手动选择正确的基座模型和 LoRA\n"
                    "  3. 合并后再导出 GGUF"
                ) from e

        elif not has_config:
            raise ValueError(
                f"❌ 目录 {model_dir.name} 中没有 config.json。\n"
                "这不是一个有效的 HuggingFace 模型目录。\n"
                "请选择一个完整的模型目录（合并后的模型或原始 HF 模型）。"
            )

        repaired, repair_msg = _repair_tokenizer_config_if_needed(model_dir)
        if repaired:
            progress_cb(6 if not is_lora else 56, "🔧 自动修复 tokenizer 配置...")
            log(repair_msg)

        repaired_assets, repair_assets_msg = _repair_tokenizer_assets_if_needed(model_dir, preferred_ref=tokenizer_source)
        if repaired_assets:
            progress_cb(7 if not is_lora else 57, "🧩 自动补齐 tokenizer 资源...")
            log(repair_assets_msg)

        # 预检：部分 tokenizer / convert_hf_to_gguf.py 需要 protobuf / sentencepiece
        for import_name, pip_spec in [("google.protobuf", "protobuf>=4.25,<6"), ("sentencepiece", "sentencepiece>=0.2")]:
            ok, msg = _ensure_runtime_package(import_name, pip_spec, progress_cb)
            if not ok:
                log(f"⚠️ 自动安装导出依赖失败: {pip_spec} -> {msg}")

        if not output_name:
            output_name = f"{model_dir.name}_{quant_type}_{get_timestamp()}"
        output_dir = LORAS_DIR / output_name
        output_dir.mkdir(parents=True, exist_ok=True)
        gguf_path = output_dir / f"{output_name}.gguf"

        progress_cb(5 if not is_lora else 55, "準備 GGUF 導出...")

        # ============================================================
        # 策略 1: llama.cpp 仓库脚本（最稳定，自带 gguf-py）
        # ============================================================
        try:
            progress_cb(8, "尝试 llama.cpp 仓库脚本...")
            gguf_done = self._convert_with_llama_cpp_repo(model_dir, gguf_path, quant_type, progress_cb)
            _write_gguf_source_sidecar(gguf_done, model_dir, quant_type, tokenizer_source)
            return gguf_done
        except FileNotFoundError:
            log("llama.cpp 仓库未找到，尝试其他方式...")
        except Exception as e:
            log(f"llama.cpp 仓库脚本失败: {e}")

        # ============================================================
        # 策略 2: 检测 gguf 包兼容性 → 自动修复
        # ============================================================
        progress_cb(10, "检测 gguf 包兼容性...")
        gguf_info = _check_gguf_version()
        log(f"gguf 包状态: {gguf_info}")

        if gguf_info["installed"] and not gguf_info["has_mistral"]:
            progress_cb(12, "⚠️ gguf 包版本过旧，尝试自动升级...")
            upgraded = _try_upgrade_gguf(progress_cb)
            if upgraded:
                gguf_info = _check_gguf_version()
                progress_cb(18, "✅ gguf 包已升级")
            else:
                progress_cb(18, "⚠️ gguf 包升级失败，尝试其他方式...")

        # ============================================================
        # 策略 3: 使用已安装的 convert_hf_to_gguf.py
        # ============================================================
        scripts = _find_convert_scripts()
        for script_info in scripts:
            try:
                progress_cb(20, f"尝试: {script_info['source']} ...")
                gguf_done = self._convert_with_script(
                    script_info["path"], script_info.get("has_gguf_py", False),
                    model_dir, gguf_path, quant_type, progress_cb,
                )
                _write_gguf_source_sidecar(gguf_done, model_dir, quant_type, tokenizer_source)
                return gguf_done
            except Exception as e:
                log(f"{script_info['source']} 失败: {str(e)[:200]}")
                continue

        # ============================================================
        # 策略 4: 从 GitHub 下载最新脚本
        # ============================================================
        try:
            progress_cb(25, "从 GitHub 下载最新转换脚本...")
            downloaded = _download_convert_script(output_dir)
            if downloaded:
                gguf_done = self._convert_with_script(
                    downloaded, False,
                    model_dir, gguf_path, quant_type, progress_cb,
                )
                _write_gguf_source_sidecar(gguf_done, model_dir, quant_type, tokenizer_source)
                return gguf_done
        except Exception as e:
            log(f"GitHub 脚本失败: {e}")

        # ============================================================
        # 全部失败 → 给出详细修复指南
        # ============================================================
        gguf_info = _check_gguf_version()
        guide = self._build_fix_guide(gguf_info, scripts)

        # 收集所有尝试过的策略的最后错误
        last_errors = []
        if scripts:
            last_errors.append(f"已尝试 {len(scripts)} 个转换脚本（含自动补丁）")
        if gguf_info["installed"] and not gguf_info["has_mistral"]:
            last_errors.append(f"gguf v{gguf_info['version']} 缺少 MistralTokenizerType")

        raise RuntimeError(
            f"{guide}\n\n"
            f"{''.join(f'· {e}' + chr(10) for e in last_errors)}"
        )

    def _convert_with_script(
        self, script_path: Path, has_local_gguf_py: bool,
        model_dir: Path, gguf_path: Path, quant_type: str, progress_cb,
    ) -> Path:
        """使用指定的 convert_hf_to_gguf.py 脚本转换

        核心修复: 如果 gguf 包缺少 MistralTokenizerType，会自动创建
        包装脚本，在运行前注入缺失的符号。
        """
        f16_path = gguf_path.parent / f"{gguf_path.stem}_f16.gguf"

        env = os.environ.copy()
        if has_local_gguf_py:
            gguf_py_dir = script_path.parent / "gguf-py"
            if gguf_py_dir.exists():
                env["PYTHONPATH"] = str(gguf_py_dir) + os.pathsep + env.get("PYTHONPATH", "")

        # ----------------------------------------------------------
        # 核心: 当 gguf 包缺少 MistralTokenizerType 时，
        # 优先使用 wrapper 脚本（最可靠的方式）
        # ----------------------------------------------------------
        actual_script = script_path
        gguf_info = _check_gguf_version()
        needs_patch = gguf_info["installed"] and not gguf_info["has_mistral"] and not has_local_gguf_py

        if needs_patch:
            progress_cb(30, "⚠️ gguf 包缺少 MistralTokenizerType，创建兼容包装...")
            # 优先 wrapper（在 Python 级别注入，最可靠）
            wrapper = self._create_wrapper_script(script_path, gguf_path.parent)
            if wrapper:
                actual_script = wrapper
                log(f"使用包装脚本: {wrapper}")
            else:
                # 退回到文本补丁
                patched = self._create_patched_script(script_path, gguf_path.parent)
                if patched:
                    actual_script = patched
                    log(f"使用补丁脚本: {patched}")

        progress_cb(35, f"转换 → F16 GGUF ({actual_script.name})...")

        import subprocess
        result = subprocess.run(
            [sys.executable, str(actual_script), str(model_dir),
             "--outfile", str(f16_path), "--outtype", "f16"],
            capture_output=True, text=True, timeout=3600,
            env=env,
        )

        # 如果第一次失败，且错误仍是 MistralTokenizerType，尝试 Plan B
        if result.returncode != 0:
            error_text = _extract_conversion_error(result.stderr, result.stdout)

            if _looks_like_invalid_tokenizer_class_error(error_text):
                repaired, repair_msg = _repair_tokenizer_config_if_needed(model_dir)
                if repaired:
                    log(repair_msg)
                    progress_cb(36, "🔧 检测到无效 tokenizer_class，已修复后重试...")
                    result = subprocess.run(
                        [sys.executable, str(actual_script), str(model_dir),
                         "--outfile", str(f16_path), "--outtype", "f16"],
                        capture_output=True, text=True, timeout=3600,
                        env=env,
                    )
                    if result.returncode == 0 and f16_path.exists():
                        error_text = ""
                    else:
                        error_text = _extract_conversion_error(result.stderr, result.stdout)

            if result.returncode != 0 and _looks_like_missing_protobuf_error(error_text):
                progress_cb(36, "📦 缺少 protobuf，自动补装后重试...")
                ok, msg = _ensure_runtime_package("google.protobuf", "protobuf>=4.25,<6", progress_cb)
                log(msg if ok else f"protobuf 自动安装失败: {msg}")
                if ok:
                    result = subprocess.run(
                        [sys.executable, str(actual_script), str(model_dir),
                         "--outfile", str(f16_path), "--outtype", "f16"],
                        capture_output=True, text=True, timeout=3600,
                        env=env,
                    )
                    if result.returncode == 0 and f16_path.exists():
                        error_text = ""
                    else:
                        error_text = _extract_conversion_error(result.stderr, result.stdout)

            if result.returncode != 0 and _looks_like_missing_sentencepiece_error(error_text):
                progress_cb(37, "📦 缺少 sentencepiece，自动补装后重试...")
                ok, msg = _ensure_runtime_package("sentencepiece", "sentencepiece>=0.2", progress_cb)
                log(msg if ok else f"sentencepiece 自动安装失败: {msg}")
                if ok:
                    result = subprocess.run(
                        [sys.executable, str(actual_script), str(model_dir),
                         "--outfile", str(f16_path), "--outtype", "f16"],
                        capture_output=True, text=True, timeout=3600,
                        env=env,
                    )
                    if result.returncode == 0 and f16_path.exists():
                        error_text = ""
                    else:
                        error_text = _extract_conversion_error(result.stderr, result.stdout)

            if result.returncode != 0 and _looks_like_sentencepiece_vocab_file_error(error_text):
                progress_cb(38, "🧩 检测到缺失 tokenizer.model，尝试从基座模型补齐后重试...")
                repaired_assets, repair_assets_msg = _repair_tokenizer_assets_if_needed(model_dir, preferred_ref=tokenizer_source)
                log(repair_assets_msg if repaired_assets else f"补齐 tokenizer 资源失败: {repair_assets_msg or '未找到可用基座 tokenizer'}")
                if repaired_assets:
                    result = subprocess.run(
                        [sys.executable, str(actual_script), str(model_dir),
                         "--outfile", str(f16_path), "--outtype", "f16"],
                        capture_output=True, text=True, timeout=3600,
                        env=env,
                    )
                    if result.returncode == 0 and f16_path.exists():
                        error_text = ""
                    else:
                        error_text = _extract_conversion_error(result.stderr, result.stdout)

            if result.returncode != 0 and ("MistralTokenizerType" in error_text or "MistralVocab" in error_text):
                # Plan B: 如果还没用 wrapper，现在用
                if actual_script != script_path or not needs_patch:
                    # wrapper/patch 也失败了，尝试另一种方式
                    progress_cb(37, "补丁失败，尝试备用包装脚本...")
                    alt = (self._create_wrapper_script if actual_script != self._create_wrapper_script
                           else self._create_patched_script)
                else:
                    alt = self._create_wrapper_script

                wrapper_b = self._create_wrapper_script(script_path, gguf_path.parent)
                if wrapper_b and wrapper_b != actual_script:
                    result = subprocess.run(
                        [sys.executable, str(wrapper_b), str(model_dir),
                         "--outfile", str(f16_path), "--outtype", "f16"],
                        capture_output=True, text=True, timeout=3600,
                        env=env,
                    )
                    if result.returncode != 0:
                        error_text = (result.stderr + result.stdout)[-800:]

                        # Plan C: 直接在子进程中预注入
                        progress_cb(38, "尝试内联注入方式...")
                        inject_result = self._convert_with_inline_inject(
                            script_path, model_dir, f16_path, env)
                        if inject_result and f16_path.exists():
                            progress_cb(60, "✅ 内联注入方式成功")
                        else:
                            raise RuntimeError(
                                f"GGUF 導出失敗（gguf 包版本不兼容）。\n\n"
                                f"根本原因: gguf v{gguf_info.get('version','?')} 缺少 MistralTokenizerType\n\n"
                                f"一步修复:\n"
                                f'  pip install "gguf @ git+https://github.com/ggml-org/llama.cpp.git@master#subdirectory=gguf-py"\n\n'
                                f"或克隆 llama.cpp 仓库:\n"
                                f"  git clone https://github.com/ggml-org/llama.cpp.git\n"
                                f"  cd llama.cpp && pip install -e gguf-py\n\n"
                                f"最後错误: {error_text[-300:]}")
                    else:
                        progress_cb(60, "✅ 备用包装脚本成功")
                else:
                    raise RuntimeError(
                        f"GGUF 導出失敗（gguf 包版本不兼容）。\n\n"
                        f"根本原因: gguf v{gguf_info.get('version','?')} 缺少 MistralTokenizerType\n\n"
                        f"一步修复:\n"
                        f'  pip install "gguf @ git+https://github.com/ggml-org/llama.cpp.git@master#subdirectory=gguf-py"\n\n'
                        f"最後错误: {error_text[-300:]}")
            else:
                if _looks_like_invalid_tokenizer_class_error(error_text):
                    raise RuntimeError(
                        "GGUF 导出失败：模型目录中的 tokenizer 配置无效。\n\n"
                        "ForgeX 已尝试自动修复，但 transformers 仍无法加载该 tokenizer。\n"
                        "请检查 tokenizer_config.json / tokenizer.json，尤其是 tokenizer_class 是否被写成 TokenizersBackend 之类的后端名。\n\n"
                        f"最后错误: {error_text[-500:]}"
                    )
                if _looks_like_sentencepiece_vocab_file_error(error_text):
                    raise RuntimeError(
                        "GGUF 导出失败：当前模型目录缺少可供 LLaMA tokenizer 使用的 tokenizer.model。\n\n"
                        "ForgeX 已尝试从基座模型自动补齐 tokenizer 资源，但仍未成功。\n"
                        "请优先检查该模型目录是否包含 tokenizer.model，或在 GGUF 导出面板中手动填写『Tokenizer/基座来源』，也可以重新用最新版 ForgeX 重新执行一次 LoRA 合并。\n\n"
                        f"最后错误: {error_text[-500:]}"
                    )
                raise RuntimeError(f"Command failed (rc={result.returncode}): {error_text}")

        if not f16_path.exists():
            raise FileNotFoundError(f"转换后文件不存在: {f16_path}")

        if quant_type == "F16":
            if gguf_path.exists():
                gguf_path.unlink()
            f16_path.rename(gguf_path)
            progress_cb(100, f"完成: {gguf_path}")
            return gguf_path

        progress_cb(70, f"量化 {quant_type}...")
        quant_bin = _find_quantize_bin()
        if quant_bin is None:
            # 先尝试脚本直出（新版 convert_hf_to_gguf.py 可直接支持部分量化）
            if self._try_direct_script_quant(actual_script, model_dir, gguf_path, quant_type, env, progress_cb):
                f16_path.unlink(missing_ok=True)
                progress_cb(100, f"完成: {gguf_path}")
                return gguf_path
            return self._finalize_f16_fallback(gguf_path, f16_path, quant_type, progress_cb)

        try:
            run_subprocess(
                [str(quant_bin), str(f16_path), str(gguf_path), quant_type],
                progress_cb=lambda l: progress_cb(90, l),
            )
        except Exception as e:
            log(f"量化工具失败: {e}")
            # quantize 存在但失败时，至少再尝试一次脚本直出
            if self._try_direct_script_quant(actual_script, model_dir, gguf_path, quant_type, env, progress_cb):
                f16_path.unlink(missing_ok=True)
                progress_cb(100, f"完成: {gguf_path}")
                return gguf_path
            return self._finalize_f16_fallback(gguf_path, f16_path, quant_type, progress_cb)

        f16_path.unlink(missing_ok=True)
        progress_cb(100, f"完成: {gguf_path}")
        return gguf_path

    def _try_direct_script_quant(
        self, actual_script: Path, model_dir: Path, out_path: Path, quant_type: str, env: dict, progress_cb
    ) -> bool:
        """尝试直接用 convert_hf_to_gguf.py 生成量化文件。

        新版脚本通常支持 F16 / Q8_0 直接输出；当本机缺少 llama-quantize
        时，至少能避免把 F16 伪装成 Q8_0。
        """
        direct_out = DIRECT_SCRIPT_OUTTYPES.get((quant_type or '').upper())
        if not direct_out:
            return False
        progress_cb(72, f"尝试脚本直出 {quant_type}...")
        import subprocess
        result = subprocess.run(
            [sys.executable, str(actual_script), str(model_dir),
             "--outfile", str(out_path), "--outtype", direct_out],
            capture_output=True, text=True, timeout=3600, env=env,
        )
        if result.returncode == 0 and out_path.exists():
            log(f"✅ 脚本直出成功: {out_path} ({quant_type})")
            return True
        err = (result.stderr + result.stdout)[-500:]
        log(f"脚本直出 {quant_type} 失败: {err}")
        return False

    def _finalize_f16_fallback(self, requested_path: Path, f16_path: Path, requested_quant: str, progress_cb) -> Path:
        """缺少量化工具时，明确输出 F16 fallback，避免伪装成其他量化。"""
        fallback = requested_path.parent / f"{requested_path.stem}.F16-fallback.gguf"
        note_path = requested_path.parent / "EXPORT_NOTE.txt"
        if fallback.exists():
            fallback.unlink()
        f16_path.rename(fallback)
        note_path.write_text(
            "ForgeX GGUF 导出说明\n\n"
            f"请求量化: {requested_quant}\n"
            "实际输出: F16 fallback\n\n"
            "原因: 未找到 llama-quantize / quantize，可执行脚本无法完成二次量化。\n"
            "已保留可用的 F16 GGUF，文件名已明确标注 F16-fallback，避免误认为 Q4/Q5/Q6。\n\n"
            "修复建议:\n"
            "1. 安装 / 编译 llama.cpp 的 llama-quantize 二进制\n"
            "2. 或至少确保 convert_hf_to_gguf.py 支持目标量化直出\n",
            encoding="utf-8",
        )
        progress_cb(100, f"⚠️ 未找到量化工具，已输出 F16 fallback: {fallback}")
        return fallback

    def _convert_with_inline_inject(self, script_path: Path, model_dir: Path,
                                      f16_path: Path, env: dict) -> bool:
        """Plan C: 用 -c 参数直接在子进程中注入缺失符号后执行脚本"""
        try:
            import subprocess
            code = f'''
import sys, enum, importlib

# 注入 MistralTokenizerType
class _MistralTokenizerType(enum.Enum):
    spm = "spm"; tekken = "tekken"
class _MistralVocab:
    def __init__(self, *a, **kw): raise NotImplementedError("MistralVocab stub")

try:
    from gguf import vocab as _gv
    if not hasattr(_gv, "MistralTokenizerType"):
        _gv.MistralTokenizerType = _MistralTokenizerType
    if not hasattr(_gv, "MistralVocab"):
        _gv.MistralVocab = _MistralVocab
except Exception:
    pass

sys.argv = [r"{script_path}", r"{model_dir}", "--outfile", r"{f16_path}", "--outtype", "f16"]
with open(r"{script_path}", "r", encoding="utf-8") as _f:
    exec(compile(_f.read(), r"{script_path}", "exec"), {{"__name__":"__main__","__file__":r"{script_path}"}})
'''
            result = subprocess.run(
                [sys.executable, "-c", code],
                capture_output=True, text=True, timeout=3600, env=env,
            )
            return result.returncode == 0 and f16_path.exists()
        except Exception as e:
            log(f"内联注入失败: {e}")
            return False

    def _create_patched_script(self, original: Path, work_dir: Path) -> Optional[Path]:
        """创建补丁版本的 convert_hf_to_gguf.py，将 MistralTokenizerType 导入包裹在 try/except 中"""
        try:
            import re
            src = original.read_text(encoding="utf-8")

            # 用正则匹配各种可能的 import 形式
            # 匹配: from gguf.vocab import ... MistralTokenizerType ...
            pattern = r'^(from\s+gguf\.vocab\s+import\s+.*MistralTokenizerType.*)$'
            match = re.search(pattern, src, re.MULTILINE)
            if not match:
                # 也尝试: from gguf import ... (某些版本的写法)
                pattern2 = r'^(from\s+gguf\b.*import\s+.*MistralTokenizerType.*)$'
                match = re.search(pattern2, src, re.MULTILINE)

            if not match:
                log("补丁脚本: 未找到 MistralTokenizerType import 语句")
                return None

            old_import = match.group(1)
            safe_import = f'''
# [ForgeX patch] 安全导入 MistralTokenizerType（兼容旧版 gguf）
try:
    {old_import}
except ImportError:
    import enum as _enum
    class MistralTokenizerType(_enum.Enum):
        spm = "spm"
        tekken = "tekken"
    class MistralVocab:
        def __init__(self, *a, **kw):
            raise NotImplementedError(
                "MistralVocab 需要最新 gguf 包。"
                "此模型不使用 Mistral tokenizer，不影响转换。"
            )
    # 注入回 gguf.vocab 模块
    try:
        from gguf import vocab as _gv
        if not hasattr(_gv, "MistralTokenizerType"):
            _gv.MistralTokenizerType = MistralTokenizerType
        if not hasattr(_gv, "MistralVocab"):
            _gv.MistralVocab = MistralVocab
    except Exception:
        pass
'''
            patched_src = src.replace(old_import, safe_import, 1)

            dest = work_dir / "convert_hf_to_gguf_patched.py"
            dest.write_text(patched_src, encoding="utf-8")
            log(f"✅ 已创建补丁脚本: {dest}")
            return dest
        except Exception as e:
            log(f"创建补丁脚本失败: {e}")
            return None

    def _create_wrapper_script(self, original: Path, work_dir: Path) -> Optional[Path]:
        """创建包装脚本: 先注入缺失符号到 gguf.vocab，然后 exec 原始脚本"""
        try:
            wrapper_code = f'''#!/usr/bin/env python3
# [ForgeX] Wrapper: 注入 MistralTokenizerType 后运行 convert_hf_to_gguf.py
import sys, enum, importlib

# Step 1: 确保 gguf.vocab 有 MistralTokenizerType
try:
    from gguf.vocab import MistralTokenizerType
except ImportError:
    class MistralTokenizerType(enum.Enum):
        spm = "spm"
        tekken = "tekken"

    class MistralVocab:
        def __init__(self, *a, **kw):
            raise NotImplementedError("MistralVocab 需要最新 gguf 包")

    try:
        from gguf import vocab as _gv
        _gv.MistralTokenizerType = MistralTokenizerType
        _gv.MistralVocab = MistralVocab
    except Exception:
        pass

    # 也注入到 sys.modules 以防 from X import Y 再次触发
    import types
    if "gguf.vocab" not in sys.modules:
        mod = types.ModuleType("gguf.vocab")
        mod.MistralTokenizerType = MistralTokenizerType
        mod.MistralVocab = MistralVocab
        sys.modules["gguf.vocab"] = mod
    else:
        m = sys.modules["gguf.vocab"]
        if not hasattr(m, "MistralTokenizerType"):
            m.MistralTokenizerType = MistralTokenizerType
        if not hasattr(m, "MistralVocab"):
            m.MistralVocab = MistralVocab

# Step 2: exec 原始脚本
script_path = r"{str(original)}"
sys.argv[0] = script_path
with open(script_path, "r", encoding="utf-8") as _f:
    _code = _f.read()
exec(compile(_code, script_path, "exec"), {{"__name__": "__main__", "__file__": script_path}})
'''
            dest = work_dir / "convert_hf_to_gguf_wrapper.py"
            dest.write_text(wrapper_code, encoding="utf-8")
            log(f"✅ 已创建包装脚本: {dest}")
            return dest
        except Exception as e:
            log(f"创建包装脚本失败: {e}")
            return None

    def _find_llama_cpp_repo(self) -> Optional[Path]:
        for p in [Path.cwd() / "llama.cpp", Path.home() / "llama.cpp",
                  Path("D:/llama.cpp"), Path("C:/llama.cpp")]:
            try:
                if (p / "convert_hf_to_gguf.py").exists():
                    return p
            except Exception:
                pass
        return None

    def _convert_with_llama_cpp_repo(self, model_dir, gguf_path, quant_type, progress_cb) -> Path:
        repo = self._find_llama_cpp_repo()
        if repo is None:
            raise FileNotFoundError("未找到 llama.cpp 仓库")
        return self._convert_with_script(
            repo / "convert_hf_to_gguf.py", has_local_gguf_py=True,
            model_dir=model_dir, gguf_path=gguf_path,
            quant_type=quant_type, progress_cb=progress_cb,
        )

    def _build_fix_guide(self, gguf_info: dict, scripts: list) -> str:
        """构建详细的修复指南"""
        lines = ["GGUF 導出失敗。", "", "也请检查模型目录里的 tokenizer_config.json 是否被写入了无效的 tokenizer_class（例如 TokenizersBackend）。", "并确认当前虚拟环境已安装 protobuf / sentencepiece。"]

        if not gguf_info["installed"]:
            lines.append("")
            lines.append("❌ 未安装 gguf 包")
            lines.append("   修复: pip install gguf")
        elif not gguf_info["has_mistral"]:
            lines.append("")
            lines.append(f"❌ gguf 包版本过旧 (v{gguf_info['version']}) — 缺少 MistralTokenizerType")
            lines.append("   convert_hf_to_gguf.py 需要最新版 gguf 包，但你安装的版本太旧。")
            lines.append("")
            lines.append("   最快修复（任选一）:")
            lines.append('   方案A: pip install "gguf @ git+https://github.com/ggml-org/llama.cpp.git@master#subdirectory=gguf-py"')
            lines.append("   方案B: pip install --upgrade gguf")
        else:
            lines.append("")
            lines.append(f"gguf 包正常 (v{gguf_info['version']})")

        if not scripts:
            lines.append("")
            lines.append("❌ 未找到 convert_hf_to_gguf.py 脚本")
            lines.append("   修复: pip install llama-cpp-python")

        lines.append("")
        lines.append("推荐一步到位（最稳定）:")
        lines.append("   git clone https://github.com/ggml-org/llama.cpp.git")
        lines.append("   cd llama.cpp && pip install -e gguf-py")
        if sys.platform == "win32":
            lines.append("   cmake -B build && cmake --build build --config Release")
        else:
            lines.append("   cmake -B build -DGGML_CUDA=ON && cmake --build build -j$(nproc)")
        lines.append("")
        lines.append("   ForgeX 会自动发现 llama.cpp 仓库并使用其脚本。")

        return "\n".join(lines)

    # ================================================================
    #  Ollama
    # ================================================================

    def export_ollama(
        self,
        model_path: str = "",
        gguf_path: str = "",
        ollama_name: str = "",
        model_name: str = "",
        quant_type: str = "Q4_K_M",
        system_prompt: str = "",
        task: Optional[Task] = None,
    ) -> dict:
        model_path = model_path or gguf_path
        ollama_name = ollama_name or model_name
        if not model_path:
            raise ValueError("请指定模型路徑")
        if not ollama_name:
            raise ValueError("请指定 Ollama 模型名")

        progress_cb = task.update_progress if task else (lambda p, m="": log(m))

        gp = Path(model_path)
        if gp.suffix.lower() == ".gguf" and gp.exists():
            gguf_file = gp
        else:
            gguf_file = self.export_gguf(model_path=model_path, quant_type=quant_type,
                                         output_name=ollama_name, task=task)

        mf = gguf_file.parent / "Modelfile"
        source_model_dir = None
        sidecar_candidates = [gguf_file.parent / "forgex_gguf_source.json", Path(str(gguf_file) + ".forgex.json")]
        for sp in sidecar_candidates:
            try:
                if sp.exists():
                    meta = json.loads(sp.read_text(encoding="utf-8"))
                    cand = meta.get("source_model_dir")
                    if cand and Path(cand).exists():
                        source_model_dir = Path(cand)
                        break
            except Exception:
                pass

        wrote_from_profile = False
        if source_model_dir is not None:
            try:
                from core.model_editor import generate_modelfile
                generate_modelfile(str(source_model_dir), str(gguf_file))
                wrote_from_profile = True
            except Exception as e:
                log(f"按模型档案生成 Modelfile 失败，回退到基础模板: {e}")

        if not wrote_from_profile:
            sys_block = f"SYSTEM {system_prompt}\n" if system_prompt else ""
            mf.write_text(f"FROM {gguf_file.name}\n{sys_block}\n", encoding="utf-8")
        else:
            try:
                content = mf.read_text(encoding="utf-8")
                content = content.replace(f"FROM {gguf_file}", f"FROM {gguf_file.name}")
                content = content.replace(f"FROM {str(gguf_file)}", f"FROM {gguf_file.name}")
                if system_prompt and "SYSTEM" not in content:
                    content += f"\nSYSTEM \"\"\"\n{system_prompt}\n\"\"\"\n"
                mf.write_text(content, encoding="utf-8")
            except Exception:
                pass
        progress_cb(90, f"已生成 Modelfile: {mf}")

        ollama_bin = shutil.which("ollama") or shutil.which("ollama.exe")
        if not ollama_bin:
            progress_cb(100, "⚠️ 未找到 ollama")
            return {
                "gguf_path": str(gguf_file), "modelfile": str(mf),
                "ollama_name": ollama_name, "status": "ollama_not_found",
                "manual_cmd": f"ollama create {ollama_name} -f {mf}",
            }
        try:
            run_subprocess([ollama_bin, "create", ollama_name, "-f", str(mf)],
                          progress_cb=lambda l: progress_cb(95, l))
            progress_cb(100, f"✅ 已導入 Ollama: {ollama_name}")
            return {"gguf_path": str(gguf_file), "modelfile": str(mf),
                    "ollama_name": ollama_name, "status": "imported"}
        except Exception as e:
            progress_cb(100, f"⚠️ Ollama 導入失敗: {e}")
            return {"gguf_path": str(gguf_file), "modelfile": str(mf),
                    "ollama_name": ollama_name, "status": f"import_failed: {e}",
                    "manual_cmd": f"ollama create {ollama_name} -f {mf}"}

    def export_ollama_modelfile(self, gguf_path: str, model_name: str = "",
                                task: Optional[Task] = None) -> Path:
        progress_cb = task.update_progress if task else (lambda p, m="": log(m))
        gp = Path(gguf_path)
        if not gp.exists():
            raise FileNotFoundError(f"GGUF 不存在: {gguf_path}")
        if not model_name:
            model_name = gp.stem
        mf = gp.parent / "Modelfile"
        mf.write_text(f"FROM {gp.name}\n\n", encoding="utf-8")
        progress_cb(100, f"已生成 Modelfile: {mf}")
        return mf


exporter = Exporter()
