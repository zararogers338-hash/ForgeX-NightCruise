using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace PolarisOSInstaller
{
    internal static class SetupProgram
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new SetupForm());
        }
    }

    public sealed class SetupForm : Form
    {
        private readonly string[] pageTitles = new string[]
        {
            "欢迎",
            "安装位置",
            "Python 检测",
            "GPU 检测",
            "环境方案",
            "依赖安装",
            "模型/缓存目录",
            "服务自检",
            "完成"
        };

        private readonly Label titleLabel;
        private readonly Label navLabel;
        private readonly Panel body;
        private readonly TextBox logBox;
        private readonly ProgressBar progress;
        private readonly Button backButton;
        private readonly Button nextButton;
        private readonly Button actionButton;
        private readonly Button cancelButton;

        private int pageIndex;
        private string installDir;
        private string modelsDir;
        private string cacheDir;
        private string logsDir;
        private string backend = "auto";
        private string pythonFile = "";
        private string pythonPrefix = "";
        private string pythonDisplay = "";
        private string gpuSummary = "尚未检测";
        private bool sourceExtracted;
        private bool depsInstalled;
        private bool pathsSaved;
        private bool healthPassed;

        private TextBox activeInstallBox;
        private TextBox activeModelsBox;
        private TextBox activeCacheBox;
        private ComboBox activeBackendCombo;

        public SetupForm()
        {
            Text = "POLARIS OS 安装向导";
            Width = 880;
            Height = 680;
            MinimumSize = new Size(820, 620);
            StartPosition = FormStartPosition.CenterScreen;

            installDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "POLARIS OS");
            modelsDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "POLARIS OS", "models_cache");
            cacheDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "POLARIS OS", "hf_cache");
            logsDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "POLARIS OS", "logs");

            var root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.RowCount = 4;
            root.ColumnCount = 1;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 170));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
            Controls.Add(root);

            var header = new Panel();
            header.BackColor = Color.FromArgb(245, 248, 250);
            header.Dock = DockStyle.Fill;
            root.Controls.Add(header, 0, 0);

            titleLabel = new Label();
            titleLabel.Font = new Font(Font.FontFamily, 18, FontStyle.Bold);
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(18, 14);
            header.Controls.Add(titleLabel);

            navLabel = new Label();
            navLabel.AutoSize = true;
            navLabel.Location = new Point(20, 52);
            header.Controls.Add(navLabel);

            body = new Panel();
            body.Dock = DockStyle.Fill;
            body.Padding = new Padding(24, 18, 24, 12);
            root.Controls.Add(body, 0, 1);

            logBox = new TextBox();
            logBox.Dock = DockStyle.Fill;
            logBox.Multiline = true;
            logBox.ScrollBars = ScrollBars.Vertical;
            logBox.ReadOnly = true;
            logBox.Font = new Font("Consolas", 9);
            root.Controls.Add(logBox, 0, 2);

            var footer = new TableLayoutPanel();
            footer.Dock = DockStyle.Fill;
            footer.Padding = new Padding(12, 10, 12, 10);
            footer.ColumnCount = 5;
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            root.Controls.Add(footer, 0, 3);

            progress = new ProgressBar();
            progress.Dock = DockStyle.Fill;
            footer.Controls.Add(progress, 0, 0);

            backButton = MakeButton("上一步");
            actionButton = MakeButton("执行");
            nextButton = MakeButton("下一步");
            cancelButton = MakeButton("取消");
            footer.Controls.Add(backButton, 1, 0);
            footer.Controls.Add(actionButton, 2, 0);
            footer.Controls.Add(nextButton, 3, 0);
            footer.Controls.Add(cancelButton, 4, 0);

            backButton.Click += delegate { SaveCurrentPage(); pageIndex--; ShowPage(); };
            nextButton.Click += delegate { OnNext(); };
            actionButton.Click += delegate { OnAction(); };
            cancelButton.Click += delegate { Close(); };

            ShowPage();
            DetectPython(false);
        }

        private Button MakeButton(string text)
        {
            var button = new Button();
            button.Text = text;
            button.Dock = DockStyle.Fill;
            button.Margin = new Padding(6, 0, 0, 0);
            return button;
        }

        private void ShowPage()
        {
            if (pageIndex < 0) pageIndex = 0;
            if (pageIndex >= pageTitles.Length) pageIndex = pageTitles.Length - 1;
            body.Controls.Clear();
            titleLabel.Text = "POLARIS OS - " + pageTitles[pageIndex];
            navLabel.Text = "步骤 " + (pageIndex + 1) + " / " + pageTitles.Length + "    " + String.Join("  >  ", pageTitles);
            backButton.Enabled = pageIndex > 0;
            nextButton.Text = pageIndex == pageTitles.Length - 1 ? "关闭" : "下一步";
            actionButton.Enabled = true;
            actionButton.Text = "执行";

            if (pageIndex == 0) PageWelcome();
            else if (pageIndex == 1) PageInstallDir();
            else if (pageIndex == 2) PagePython();
            else if (pageIndex == 3) PageGpu();
            else if (pageIndex == 4) PageBackend();
            else if (pageIndex == 5) PageDeps();
            else if (pageIndex == 6) PagePaths();
            else if (pageIndex == 7) PageHealth();
            else PageDone();
        }

        private void AddLabel(string text, int y, bool bold)
        {
            var label = new Label();
            label.Text = text;
            label.AutoSize = false;
            label.Width = body.Width - 60;
            label.Height = 28;
            label.Location = new Point(0, y);
            if (bold) label.Font = new Font(Font.FontFamily, 11, FontStyle.Bold);
            body.Controls.Add(label);
        }

        private TextBox AddPathBox(string text, int y, EventHandler browse)
        {
            var box = new TextBox();
            box.Text = text;
            box.Width = body.Width - 170;
            box.Location = new Point(0, y);
            body.Controls.Add(box);
            var button = new Button();
            button.Text = "浏览...";
            button.Width = 100;
            button.Location = new Point(box.Right + 10, y - 1);
            button.Click += browse;
            body.Controls.Add(button);
            return box;
        }

        private void PageWelcome()
        {
            actionButton.Enabled = false;
            AddLabel("欢迎安装北极星 POLARIS OS 本地 AI Studio。", 0, true);
            AddLabel("安装向导会检测 Python 3.11、GPU、依赖环境，创建本地启动器和快捷方式。", 42, false);
            AddLabel("已有 run.sh / main.py 启动逻辑会被保留；Windows 安装逻辑集中在 installer、launcher、scripts。", 78, false);
        }

        private void PageInstallDir()
        {
            actionButton.Enabled = false;
            AddLabel("选择安装位置", 0, true);
            activeInstallBox = AddPathBox(installDir, 44, delegate
            {
                var dlg = new FolderBrowserDialog();
                dlg.Description = "选择 POLARIS OS 安装目录";
                dlg.SelectedPath = installDir;
                if (dlg.ShowDialog(this) == DialogResult.OK) activeInstallBox.Text = dlg.SelectedPath;
            });
            AddLabel("支持中文用户名和带空格路径。重新安装时会复用 data/install_state.json 并跳过已满足依赖。", 88, false);
        }

        private void PagePython()
        {
            actionButton.Text = "重新检测";
            AddLabel("Python 3.11 检测", 0, true);
            AddLabel(String.IsNullOrEmpty(pythonDisplay) ? "未检测到 Python 3.11" : "已检测到: " + pythonDisplay, 42, false);
            var installButton = new Button();
            installButton.Text = "一键安装 Python 3.11";
            installButton.Width = 190;
            installButton.Height = 32;
            installButton.Location = new Point(0, 86);
            installButton.Click += delegate { InstallPython311(); };
            body.Controls.Add(installButton);
            AddLabel("安装源使用 python.org 官方 Windows x64 安装包，安装完成后会自动重新检测。", 130, false);
        }

        private void PageGpu()
        {
            actionButton.Text = "检测 GPU";
            AddLabel("GPU / 运行后端检测", 0, true);
            AddLabel(gpuSummary, 42, false);
            AddLabel("NVIDIA CUDA 会优先使用对应 PyTorch 预编译 wheel；AMD/NPU 仅提示，默认 CPU fallback。", 86, false);
        }

        private void PageBackend()
        {
            actionButton.Enabled = false;
            AddLabel("选择环境方案", 0, true);
            activeBackendCombo = new ComboBox();
            activeBackendCombo.DropDownStyle = ComboBoxStyle.DropDownList;
            activeBackendCombo.Items.Add("auto");
            activeBackendCombo.Items.Add("cuda");
            activeBackendCombo.Items.Add("cpu");
            activeBackendCombo.SelectedItem = backend;
            activeBackendCombo.Width = 220;
            activeBackendCombo.Location = new Point(0, 44);
            body.Controls.Add(activeBackendCombo);
            AddLabel("auto 会按 GPU 检测结果选择；cuda 适合 NVIDIA；cpu 是最稳妥的 fallback。", 88, false);
        }

        private void PageDeps()
        {
            actionButton.Text = depsInstalled ? "重新安装/修复" : "安装依赖";
            AddLabel("依赖安装", 0, true);
            AddLabel("将解包源码、创建 .venv、安装 PyTorch/Gradio/训练依赖。日志会实时显示命令、stdout/stderr 和进度。", 42, false);
            AddLabel(depsInstalled ? "依赖安装已完成，可以继续。" : "点击“安装依赖”开始。", 86, false);
        }

        private void PagePaths()
        {
            actionButton.Text = "保存目录";
            AddLabel("模型与缓存目录", 0, true);
            AddLabel("模型缓存目录", 42, false);
            activeModelsBox = AddPathBox(modelsDir, 72, delegate
            {
                var dlg = new FolderBrowserDialog();
                dlg.Description = "选择模型缓存目录";
                dlg.SelectedPath = modelsDir;
                if (dlg.ShowDialog(this) == DialogResult.OK) activeModelsBox.Text = dlg.SelectedPath;
            });
            AddLabel("HuggingFace / 下载缓存目录", 112, false);
            activeCacheBox = AddPathBox(cacheDir, 142, delegate
            {
                var dlg = new FolderBrowserDialog();
                dlg.Description = "选择缓存目录";
                dlg.SelectedPath = cacheDir;
                if (dlg.ShowDialog(this) == DialogResult.OK) activeCacheBox.Text = dlg.SelectedPath;
            });
            AddLabel(pathsSaved ? "目录已保存。" : "点击“保存目录”写入 install_state.json。", 184, false);
        }

        private void PageHealth()
        {
            actionButton.Text = "运行自检";
            AddLabel("服务自检", 0, true);
            AddLabel("检查 Python、venv、pip、torch、CUDA、gradio、main.py、端口监听，并实际启动服务验证响应。", 42, false);
            AddLabel(healthPassed ? "自检已通过。" : "点击“运行自检”开始。", 86, false);
        }

        private void PageDone()
        {
            actionButton.Text = "启动 POLARIS OS";
            AddLabel("安装完成", 0, true);
            AddLabel("可以启动 POLARIS OS、打开安装目录，或创建桌面/开始菜单快捷方式。", 42, false);
            var shortcuts = new Button();
            shortcuts.Text = "创建快捷方式";
            shortcuts.Width = 150;
            shortcuts.Height = 34;
            shortcuts.Location = new Point(0, 86);
            shortcuts.Click += delegate { CreateShortcuts(); };
            body.Controls.Add(shortcuts);
            var openDir = new Button();
            openDir.Text = "打开安装目录";
            openDir.Width = 150;
            openDir.Height = 34;
            openDir.Location = new Point(170, 86);
            openDir.Click += delegate { Process.Start(new ProcessStartInfo(installDir) { UseShellExecute = true }); };
            body.Controls.Add(openDir);
        }

        private void OnNext()
        {
            SaveCurrentPage();
            if (pageIndex == pageTitles.Length - 1)
            {
                Close();
                return;
            }
            if (pageIndex == 2 && String.IsNullOrEmpty(pythonFile))
            {
                MessageBox.Show("请先检测或安装 Python 3.11。", "POLARIS OS", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (pageIndex == 5 && !depsInstalled)
            {
                MessageBox.Show("请先完成依赖安装。", "POLARIS OS", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (pageIndex == 6 && !pathsSaved)
            {
                SavePaths();
            }
            pageIndex++;
            ShowPage();
        }

        private void OnAction()
        {
            SaveCurrentPage();
            if (pageIndex == 2) DetectPython(true);
            else if (pageIndex == 3) DetectGpu();
            else if (pageIndex == 5) InstallDependencies();
            else if (pageIndex == 6) SavePaths();
            else if (pageIndex == 7) RunHealthcheck();
            else if (pageIndex == 8) LaunchPolaris();
        }

        private void SaveCurrentPage()
        {
            if (activeInstallBox != null) installDir = activeInstallBox.Text.Trim();
            if (activeModelsBox != null) modelsDir = activeModelsBox.Text.Trim();
            if (activeCacheBox != null) cacheDir = activeCacheBox.Text.Trim();
            if (activeBackendCombo != null && activeBackendCombo.SelectedItem != null) backend = activeBackendCombo.SelectedItem.ToString();
        }

        private void DetectPython(bool showMessage)
        {
            if (ProbePython("py", "-3.11"))
            {
                pythonFile = "py";
                pythonPrefix = "-3.11";
                pythonDisplay = "py -3.11";
            }
            else if (ProbePython("python", ""))
            {
                pythonFile = "python";
                pythonPrefix = "";
                pythonDisplay = "python";
            }
            else
            {
                pythonFile = "";
                pythonPrefix = "";
                pythonDisplay = "";
            }
            AppendLog(String.IsNullOrEmpty(pythonDisplay) ? "未找到 Python 3.11。" : "Python 检测通过: " + pythonDisplay);
            if (showMessage)
            {
                ShowPage();
                MessageBox.Show(String.IsNullOrEmpty(pythonDisplay) ? "未找到 Python 3.11。" : "Python 3.11 可用。", "POLARIS OS");
            }
        }

        private bool ProbePython(string file, string prefix)
        {
            try
            {
                string args = (prefix + " -c \"import sys; raise SystemExit(0 if sys.version_info[:2] == (3,11) else 1)\"").Trim();
                int rc = RunProcess(file, args, null, false);
                return rc == 0;
            }
            catch
            {
                return false;
            }
        }

        private void InstallPython311()
        {
            SetBusy(true);
            var thread = new Thread(delegate()
            {
                try
                {
                    string url = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe";
                    string tmp = Path.Combine(Path.GetTempPath(), "python-3.11.9-amd64.exe");
                    AppendLog("下载 Python 3.11 官方安装包: " + url);
                    using (var client = new WebClient())
                    {
                        client.DownloadFile(url, tmp);
                    }
                    AppendLog("运行 Python 安装器...");
                    int rc = RunProcess(tmp, "/quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1", null, true);
                    if (rc != 0) throw new Exception("Python 安装器退出码: " + rc);
                    DetectPython(false);
                    Ui(delegate { ShowPage(); });
                }
                catch (Exception ex)
                {
                    AppendLog("Python 安装失败: " + FriendlyError(ex));
                    Message("Python 安装失败: " + FriendlyError(ex));
                }
                finally
                {
                    SetBusy(false);
                }
            });
            thread.IsBackground = true;
            thread.Start();
        }

        private void DetectGpu()
        {
            try
            {
                string outText = RunCapture("nvidia-smi", "--query-gpu=name,memory.total,driver_version,compute_cap --format=csv,noheader,nounits");
                if (!String.IsNullOrEmpty(outText.Trim()))
                {
                    string first = outText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)[0];
                    string[] parts = first.Split(',');
                    gpuSummary = "NVIDIA: " + first;
                    backend = "cuda";
                    AppendLog("GPU 检测: " + gpuSummary);
                    ShowPage();
                    return;
                }
            }
            catch { }
            try
            {
                string video = RunCapture("wmic", "path win32_VideoController get name");
                if (video.IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    video.IndexOf("NPU", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    video.IndexOf("Radeon", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    gpuSummary = "识别到非 NVIDIA 加速设备，当前安装器提示但不强制启用: " + video.Replace("\r", " ").Replace("\n", " ");
                }
                else
                {
                    gpuSummary = "未检测到 NVIDIA CUDA，推荐 CPU fallback。";
                }
            }
            catch
            {
                gpuSummary = "GPU 检测不可用，推荐 CPU fallback。";
            }
            backend = "cpu";
            AppendLog("GPU 检测: " + gpuSummary);
            ShowPage();
        }

        private void InstallDependencies()
        {
            if (String.IsNullOrEmpty(pythonFile))
            {
                MessageBox.Show("请先检测或安装 Python 3.11。");
                return;
            }
            SetBusy(true);
            var thread = new Thread(delegate()
            {
                try
                {
                    ExtractSource();
                    string bootstrap = Path.Combine(installDir, "scripts", "bootstrap_env.py");
                    string args = PythonArgs(Quote(bootstrap) +
                        " --project-dir " + Quote(installDir) +
                        " --backend " + backend +
                        " --models-dir " + Quote(modelsDir) +
                        " --cache-dir " + Quote(cacheDir) +
                        " --logs-dir " + Quote(logsDir));
                    int rc = RunProcess(pythonFile, args, installDir, true);
                    if (rc != 0) throw new Exception("依赖安装失败，退出码: " + rc);
                    depsInstalled = true;
                    pathsSaved = true;
                    AppendLog("依赖安装完成。");
                    Ui(delegate { ShowPage(); });
                }
                catch (Exception ex)
                {
                    AppendLog(FriendlyError(ex));
                    Message(FriendlyError(ex));
                }
                finally
                {
                    SetBusy(false);
                }
            });
            thread.IsBackground = true;
            thread.Start();
        }

        private void SavePaths()
        {
            if (String.IsNullOrEmpty(pythonFile))
            {
                DetectPython(false);
            }
            SetBusy(true);
            var thread = new Thread(delegate()
            {
                try
                {
                    Directory.CreateDirectory(modelsDir);
                    Directory.CreateDirectory(cacheDir);
                    Directory.CreateDirectory(logsDir);
                    string bootstrap = Path.Combine(installDir, "scripts", "bootstrap_env.py");
                    if (File.Exists(bootstrap) && !String.IsNullOrEmpty(pythonFile))
                    {
                        string args = PythonArgs(Quote(bootstrap) +
                            " --project-dir " + Quote(installDir) +
                            " --backend " + backend +
                            " --models-dir " + Quote(modelsDir) +
                            " --cache-dir " + Quote(cacheDir) +
                            " --logs-dir " + Quote(logsDir) +
                            " --no-install-deps");
                        RunProcess(pythonFile, args, installDir, true);
                    }
                    pathsSaved = true;
                    AppendLog("模型/缓存目录已保存。");
                    Ui(delegate { ShowPage(); });
                }
                catch (Exception ex)
                {
                    AppendLog("保存目录失败: " + FriendlyError(ex));
                }
                finally
                {
                    SetBusy(false);
                }
            });
            thread.IsBackground = true;
            thread.Start();
        }

        private void RunHealthcheck()
        {
            SetBusy(true);
            var thread = new Thread(delegate()
            {
                try
                {
                    string py = Path.Combine(installDir, ".venv", "Scripts", "python.exe");
                    string health = Path.Combine(installDir, "scripts", "healthcheck.py");
                    if (!File.Exists(py)) throw new Exception("未找到 venv Python: " + py);
                    if (!File.Exists(health)) throw new Exception("未找到 healthcheck.py");
                    int rc = RunProcess(py, Quote(health) + " --project-dir " + Quote(installDir) + " --start-main --json", installDir, true);
                    if (rc != 0) throw new Exception("服务自检失败，退出码: " + rc);
                    healthPassed = true;
                    AppendLog("服务自检通过。");
                    CreateShortcuts();
                    Ui(delegate { ShowPage(); });
                }
                catch (Exception ex)
                {
                    AppendLog(FriendlyError(ex));
                    Message(FriendlyError(ex));
                }
                finally
                {
                    SetBusy(false);
                }
            });
            thread.IsBackground = true;
            thread.Start();
        }

        private void LaunchPolaris()
        {
            try
            {
                string launcher = Path.Combine(installDir, "launcher", "POLARIS_OS_Launcher.exe");
                if (!File.Exists(launcher)) throw new Exception("未找到启动器: " + launcher);
                Process.Start(new ProcessStartInfo(launcher) { UseShellExecute = true, WorkingDirectory = installDir });
            }
            catch (Exception ex)
            {
                Message(FriendlyError(ex));
            }
        }

        private void ExtractSource()
        {
            if (sourceExtracted && File.Exists(Path.Combine(installDir, "main.py"))) return;
            Directory.CreateDirectory(installDir);
            AppendLog("解包 POLARIS OS 源码到: " + installDir);
            string temp = Path.Combine(Path.GetTempPath(), "POLARIS_OS_Source_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(temp);
            try
            {
                Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("POLARIS_Source.zip");
                if (stream != null)
                {
                    string zip = Path.Combine(temp, "source.zip");
                    using (var file = File.Create(zip))
                    {
                        stream.CopyTo(file);
                    }
                    ZipFile.ExtractToDirectory(zip, temp);
                    string sourceRoot = File.Exists(Path.Combine(temp, "main.py")) ? temp : Path.Combine(temp, "POLARIS_OS_Source");
                    CopyDirectory(sourceRoot, installDir);
                }
                else
                {
                    string exeDir = AppDomain.CurrentDomain.BaseDirectory;
                    string candidate = Path.Combine(exeDir, "POLARIS_OS_Source");
                    if (!Directory.Exists(candidate)) candidate = exeDir;
                    if (!File.Exists(Path.Combine(candidate, "main.py"))) throw new Exception("安装器未包含源码资源，也未在旁边找到 POLARIS_OS_Source。");
                    CopyDirectory(candidate, installDir);
                }
                sourceExtracted = true;
            }
            finally
            {
                try { Directory.Delete(temp, true); } catch { }
            }
        }

        private void CopyDirectory(string src, string dst)
        {
            Directory.CreateDirectory(dst);
            foreach (string dir in Directory.GetDirectories(src, "*", SearchOption.AllDirectories))
            {
                string rel = dir.Substring(src.Length).TrimStart(Path.DirectorySeparatorChar);
                if (ShouldSkip(rel)) continue;
                Directory.CreateDirectory(Path.Combine(dst, rel));
            }
            foreach (string file in Directory.GetFiles(src, "*", SearchOption.AllDirectories))
            {
                string rel = file.Substring(src.Length).TrimStart(Path.DirectorySeparatorChar);
                if (ShouldSkip(rel)) continue;
                string outFile = Path.Combine(dst, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(outFile));
                File.Copy(file, outFile, true);
            }
        }

        private bool ShouldSkip(string rel)
        {
            string low = rel.Replace('\\', '/').ToLowerInvariant();
            if (low == "source.zip") return true;
            return low.StartsWith(".venv/") || low == ".venv" || low.StartsWith("dist/") || low.StartsWith("build/");
        }

        private void CreateShortcuts()
        {
            try
            {
                string launcher = Path.Combine(installDir, "launcher", "POLARIS_OS_Launcher.exe");
                if (!File.Exists(launcher)) throw new Exception("未找到启动器: " + launcher);
                string desktop = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "POLARIS OS.lnk");
                CreateShortcut(desktop, launcher, installDir);
                string startFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", "POLARIS OS");
                Directory.CreateDirectory(startFolder);
                CreateShortcut(Path.Combine(startFolder, "POLARIS OS.lnk"), launcher, installDir);
                AppendLog("快捷方式已创建。");
            }
            catch (Exception ex)
            {
                AppendLog("快捷方式创建失败: " + ex.Message);
            }
        }

        private void CreateShortcut(string link, string target, string workDir)
        {
            string ps = "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('" + Ps(link) + "');" +
                "$s.TargetPath='" + Ps(target) + "';" +
                "$s.WorkingDirectory='" + Ps(workDir) + "';" +
                "$s.Description='POLARIS OS 本地 AI Studio';" +
                "$s.Save()";
            RunProcess("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command " + Quote(ps), null, false);
        }

        private string PythonArgs(string scriptAndArgs)
        {
            return String.IsNullOrEmpty(pythonPrefix) ? scriptAndArgs : pythonPrefix + " " + scriptAndArgs;
        }

        private int RunProcess(string file, string args, string cwd, bool stream)
        {
            var psi = new ProcessStartInfo();
            psi.FileName = file;
            psi.Arguments = args;
            psi.WorkingDirectory = String.IsNullOrEmpty(cwd) ? Environment.CurrentDirectory : cwd;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;
            psi.EnvironmentVariables["PYTHONUTF8"] = "1";
            psi.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";
            psi.EnvironmentVariables["PIP_DISABLE_PIP_VERSION_CHECK"] = "1";
            psi.EnvironmentVariables["PIP_NO_COLOR"] = "1";
            var proc = new Process();
            proc.StartInfo = psi;
            proc.Start();
            if (stream)
            {
                var outThread = new Thread(delegate() { ReadStream(proc.StandardOutput); });
                var errThread = new Thread(delegate() { ReadStream(proc.StandardError); });
                outThread.Start();
                errThread.Start();
                proc.WaitForExit();
                outThread.Join();
                errThread.Join();
            }
            else
            {
                proc.StandardOutput.ReadToEnd();
                proc.StandardError.ReadToEnd();
                proc.WaitForExit();
            }
            return proc.ExitCode;
        }

        private string RunCapture(string file, string args)
        {
            var psi = new ProcessStartInfo();
            psi.FileName = file;
            psi.Arguments = args;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;
            var proc = Process.Start(psi);
            string output = proc.StandardOutput.ReadToEnd() + proc.StandardError.ReadToEnd();
            proc.WaitForExit(15000);
            return output;
        }

        private void ReadStream(StreamReader reader)
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                AppendLog(line);
                ParseProgress(line);
            }
        }

        private void ParseProgress(string line)
        {
            if (!line.StartsWith("::progress ")) return;
            string rest = line.Substring("::progress ".Length);
            int space = rest.IndexOf(' ');
            if (space <= 0) return;
            int value;
            if (!Int32.TryParse(rest.Substring(0, space), out value)) return;
            Ui(delegate
            {
                progress.Style = ProgressBarStyle.Blocks;
                progress.Value = Math.Max(0, Math.Min(100, value));
            });
        }

        private void SetBusy(bool busy)
        {
            Ui(delegate
            {
                backButton.Enabled = !busy && pageIndex > 0;
                nextButton.Enabled = !busy;
                actionButton.Enabled = !busy;
                cancelButton.Enabled = !busy;
                if (busy)
                {
                    progress.Style = ProgressBarStyle.Marquee;
                }
                else
                {
                    progress.Style = ProgressBarStyle.Blocks;
                }
            });
        }

        private string FriendlyError(Exception ex)
        {
            string msg = ex.Message;
            if (msg.IndexOf("Python", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Python 环境不可用: " + msg + "\r\n请点击“一键安装 Python 3.11”后重新检测。";
            if (msg.IndexOf("依赖", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("pip", StringComparison.OrdinalIgnoreCase) >= 0)
                return "依赖安装失败: " + msg + "\r\n请检查网络或切换 CPU fallback 后点击“重新安装/修复”。";
            if (msg.IndexOf("自检", StringComparison.OrdinalIgnoreCase) >= 0)
                return "服务自检未通过: " + msg + "\r\n请查看日志框中的失败项。";
            return msg;
        }

        private void AppendLog(string text)
        {
            Ui(delegate
            {
                logBox.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + text + Environment.NewLine);
            });
        }

        private void Message(string text)
        {
            Ui(delegate { MessageBox.Show(this, text, "POLARIS OS", MessageBoxButtons.OK, MessageBoxIcon.Warning); });
        }

        private void Ui(MethodInvoker invoker)
        {
            if (IsDisposed) return;
            if (InvokeRequired)
            {
                try { BeginInvoke(invoker); } catch { }
            }
            else
            {
                invoker();
            }
        }

        private string Quote(string value)
        {
            return "\"" + value.Replace("\"", "\\\"") + "\"";
        }

        private string Ps(string value)
        {
            return value.Replace("'", "''");
        }
    }
}
