def run(text, old_text, new_text, count=0):
    text = str(text or '')
    old_text = str(old_text or '')
    new_text = str(new_text or '')
    if not old_text:
        return {'ok': False, 'error': 'old_text_empty'}
    replaced = text.replace(old_text, new_text, int(count or 0) if int(count or 0) > 0 else -1)
    return {'ok': True, 'text': replaced, 'changed': replaced != text}
