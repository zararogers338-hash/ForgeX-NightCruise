from pathlib import Path
from datetime import datetime

def run(path, old_text, new_text, encoding='utf-8', copy_only=True, output_path=''):
    p = Path(path).expanduser().resolve()
    raw = p.read_text(encoding=encoding, errors='ignore')
    old_text = str(old_text or '')
    new_text = str(new_text or '')
    if old_text and old_text not in raw:
        return {'ok': False, 'error': 'old_text_not_found', 'path': str(p)}
    updated = raw.replace(old_text, new_text, 1) if old_text else (raw + new_text)
    if output_path:
        target = Path(output_path).expanduser().resolve()
    elif copy_only:
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        target = p.parent / f"{p.stem}.edited_{stamp}{p.suffix}"
    else:
        target = p
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(updated, encoding=encoding)
    return {'ok': True, 'path': str(p), 'output_path': str(target), 'changed': updated != raw, 'copy_only': bool(copy_only)}
