#!/usr/bin/env bash
# 北极星 / POLARIS OS - 自举式启动脚本
# 功能：自动创建/启用虚拟环境、按硬件选择依赖安装路径、启动后自动打开本地网页

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

APP_NAME="北极星 POLARIS OS"
APP_VERSION="Phase 2B"
VENV_DIR="${POLARIS_OS_VENV_DIR:-${FORGEX_VENV_DIR:-$PROJECT_DIR/.venv}}"
AUTO_INSTALL="${POLARIS_OS_AUTO_INSTALL:-${FORGEX_AUTO_INSTALL:-1}}"
FORCE_REINSTALL="${POLARIS_OS_FORCE_REINSTALL:-${FORGEX_FORCE_REINSTALL:-0}}"
OPEN_BROWSER="${POLARIS_OS_OPEN_BROWSER:-${FORGEX_OPEN_BROWSER:-1}}"
HOST="${POLARIS_OS_SERVER_HOST:-${FORGEX_SERVER_HOST:-127.0.0.1}}"
PAUSE_ON_ERROR="${POLARIS_OS_PAUSE_ON_ERROR:-${FORGEX_PAUSE_ON_ERROR:-1}}"
PYTHON_CMD=()
PYTHON_LABEL=""

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

banner() {
  echo ""
  echo -e "${BLUE}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${BLUE}║   ${APP_NAME} ${APP_VERSION} - Local AI Training Studio        ║${NC}"
  echo -e "${BLUE}╚══════════════════════════════════════════════════════╝${NC}"
  echo ""
}

log() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err() { echo -e "${RED}[ERROR]${NC} $*"; }

pause_on_error() {
  [[ "$PAUSE_ON_ERROR" == "1" ]] || return 0
  [[ -t 0 ]] || return 0
  case "$(uname -s)" in
    MINGW*|MSYS*|CYGWIN*)
      echo ""
      read -r -p "启动失败，按回车关闭窗口..." _ || true
      ;;
  esac
}

on_error() {
  local exit_code=$?
  local line_no=${1:-unknown}
  err "启动脚本在第 ${line_no} 行失败，退出码: ${exit_code}"
  err "若你在 Windows 的 Git Bash / MSYS 中运行，POLARIS OS 已兼容 .venv/Scripts 路径；若仍失败，请把上面的报错发给我。"
  pause_on_error
  exit "$exit_code"
}
trap 'on_error $LINENO' ERR

python_is_311() {
  "$@" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)
PY
}

select_python() {
  local requested="${POLARIS_OS_PYTHON:-${FORGEX_PYTHON:-}}"
  if [[ -n "$requested" ]] && command -v "$requested" >/dev/null 2>&1; then
    if python_is_311 "$requested"; then
      PYTHON_CMD=("$requested")
      PYTHON_LABEL="$requested"
      return 0
    fi
    warn "指定的解释器不是 Python 3.11，已忽略: $requested"
  fi
  if command -v py >/dev/null 2>&1 && python_is_311 py -3.11; then
    PYTHON_CMD=(py -3.11)
    PYTHON_LABEL="py -3.11"
    return 0
  fi
  for py in python3.11 python; do
    if command -v "$py" >/dev/null 2>&1 && python_is_311 "$py"; then
      PYTHON_CMD=("$py")
      PYTHON_LABEL="$py"
      return 0
    fi
  done
  return 1
}

base_python() {
  "${PYTHON_CMD[@]}" "$@"
}

venv_is_311() {
  local py="$1"
  "$py" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)
PY
}

venv_python_path() {
  if [[ -x "$VENV_DIR/bin/python" ]]; then
    echo "$VENV_DIR/bin/python"
    return 0
  fi
  if [[ -x "$VENV_DIR/Scripts/python.exe" ]]; then
    echo "$VENV_DIR/Scripts/python.exe"
    return 0
  fi
  if [[ -x "$VENV_DIR/Scripts/python" ]]; then
    echo "$VENV_DIR/Scripts/python"
    return 0
  fi
  return 1
}

venv_activate_path() {
  if [[ -f "$VENV_DIR/bin/activate" ]]; then
    echo "$VENV_DIR/bin/activate"
    return 0
  fi
  if [[ -f "$VENV_DIR/Scripts/activate" ]]; then
    echo "$VENV_DIR/Scripts/activate"
    return 0
  fi
  return 1
}

read_port() {
  "$VENV_PYTHON" - <<'PY'
from pathlib import Path
import os
try:
    import yaml
except Exception:
    print(os.environ.get("POLARIS_OS_SERVER_PORT") or os.environ.get("FORGEX_SERVER_PORT", "7860"))
    raise SystemExit(0)
root = Path.cwd()
config_path = Path(os.environ.get("FORGEX_CONFIG", root / "data" / "configs" / "forgex.yaml"))
if not config_path.is_absolute():
    config_path = (root / config_path).resolve()
port = os.environ.get("POLARIS_OS_SERVER_PORT") or os.environ.get("FORGEX_SERVER_PORT")
if port:
    print(port)
    raise SystemExit(0)
if config_path.exists():
    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        print(int(data.get("server_port", 7860)))
    except Exception:
        print("7860")
else:
    print("7860")
PY
}

ensure_venv() {
  local vpy
  vpy="$(venv_python_path || true)"
  if [[ -n "$vpy" ]] && ! venv_is_311 "$vpy"; then
    local backup="${VENV_DIR}.python-mismatch.$(date +%Y%m%d_%H%M%S)"
    warn "现有虚拟环境不是 Python 3.11，将移到: $backup"
    mv "$VENV_DIR" "$backup"
    vpy=""
  fi
  if [[ -z "$vpy" ]]; then
    log "创建虚拟环境: $VENV_DIR"
    base_python -m venv "$VENV_DIR"
    vpy="$(venv_python_path || true)"
  fi
  if [[ -z "$vpy" ]]; then
    err "虚拟环境已创建，但未找到 Python 可执行文件。预期路径应为 .venv/bin/python 或 .venv/Scripts/python.exe"
    return 1
  fi
  VENV_PYTHON="$vpy"
  export VENV_PYTHON

  local act
  act="$(venv_activate_path || true)"
  if [[ -z "$act" ]]; then
    err "未找到虚拟环境激活脚本。预期路径应为 .venv/bin/activate 或 .venv/Scripts/activate"
    return 1
  fi
  # shellcheck disable=SC1090
  source "$act"
  export PYTHONUNBUFFERED=1
  export PIP_DISABLE_PIP_VERSION_CHECK=1
  export PYTHONIOENCODING=utf-8
  export LANG="${LANG:-en_US.UTF-8}"
  export LC_ALL="${LC_ALL:-en_US.UTF-8}"
  log "当前 Python: $($VENV_PYTHON -V 2>&1)"
  log "虚拟环境路径: $VENV_DIR"
}

torch_missing_active_gpu_arch() {
  command -v nvidia-smi >/dev/null 2>&1 || return 1
  local cap
  cap="$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -n1 | xargs || true)"
  [[ -n "$cap" ]] || return 1
  "$VENV_PYTHON" - "$cap" <<'PY' >/dev/null 2>&1
import sys
try:
    major, minor = (int(part) for part in sys.argv[1].split(".", 1))
except Exception:
    raise SystemExit(1)
if major < 12:
    raise SystemExit(1)
try:
    import torch
    arches = set(torch.cuda.get_arch_list() or [])
except Exception:
    raise SystemExit(1)
raise SystemExit(0 if f"sm_{major}{minor}" not in arches else 1)
PY
}

prepare_cuda_runtime() {
  if [[ "${POLARIS_OS_ALLOW_UNSUPPORTED_CUDA:-${FORGEX_ALLOW_UNSUPPORTED_CUDA:-0}}" == "1" ]]; then
    return 0
  fi
  if [[ "${CUDA_VISIBLE_DEVICES:-}" == "-1" ]]; then
    return 0
  fi
  if torch_missing_active_gpu_arch; then
    export CUDA_VISIBLE_DEVICES=-1
    export POLARIS_OS_CUDA_FALLBACK=1
    warn "检测到 RTX 50 系 GPU，但当前 PyTorch 不支持 sm_120；本次已自动切到 CPU，防止训练任务触发 CUDA 崩溃。"
    warn "要启用 5080 GPU 训练，请先运行 ./install.sh 更新 PyTorch；确认可用后再启动。"
  fi
}

need_install() {
  [[ "$FORCE_REINSTALL" == "1" ]] && return 1
  local missing=()
  local checks=(
    "torch:torch"
    "gradio:gradio"
    "yaml:yaml"
    "transformers:transformers"
    "accelerate:accelerate"
    "datasets:datasets"
    "peft:peft"
    "protobuf:google.protobuf"
    "sentencepiece:sentencepiece"
    "gguf:gguf"
  )
  local item label mod
  for item in "${checks[@]}"; do
    label="${item%%:*}"
    mod="${item#*:}"
    if ! "$VENV_PYTHON" - "$mod" >/dev/null 2>&1 <<'PY'; then
import importlib
import sys
importlib.import_module(sys.argv[1])
PY
      missing+=("$label")
    fi
  done
  if [[ "${CUDA_VISIBLE_DEVICES:-}" != "-1" ]] && torch_missing_active_gpu_arch; then
    if [[ "${POLARIS_OS_AUTO_FIX_TORCH:-${FORGEX_AUTO_FIX_TORCH:-0}}" == "1" ]]; then
      missing+=("torch-sm120")
    else
      warn "检测到 RTX 50 系 GPU，但当前 PyTorch 不支持 sm_120；GPU 训练前请重新运行 ./install.sh。"
    fi
  fi
  if (( ${#missing[@]} > 0 )); then
    local joined
    joined="$(IFS=,; echo "${missing[*]}")"
    echo "missing:${joined}"
    return 1
  fi
  return 0
}

wait_for_web() {
  local url="$1"
  local pid="${2:-}"
  local expected="${3:-}"
  for _ in $(seq 1 180); do
    if [[ -n "$pid" ]] && ! kill -0 "$pid" >/dev/null 2>&1; then
      return 1
    fi
    if "$VENV_PYTHON" - "$url" "$expected" <<'PY'
import sys, urllib.request
url = sys.argv[1]
expected = sys.argv[2]
try:
    with urllib.request.urlopen(url, timeout=2) as r:
        body = r.read(300000).decode("utf-8", "ignore")
        status = getattr(r, "status", 200)
        if 200 <= status < 500 and (not expected or expected in body):
            raise SystemExit(0)
except Exception:
    pass
raise SystemExit(1)
PY
    then
      return 0
    fi
    sleep 1
  done
  return 1
}

url_responds() {
  local url="$1"
  "$VENV_PYTHON" - "$url" <<'PY'
import sys, urllib.request
try:
    with urllib.request.urlopen(sys.argv[1], timeout=1) as r:
        raise SystemExit(0 if 200 <= getattr(r, "status", 200) < 500 else 1)
except Exception:
    raise SystemExit(1)
PY
}

find_free_port() {
  local host="$1"
  local start_port="$2"
  "$VENV_PYTHON" - "$host" "$start_port" <<'PY'
import socket, sys
host = sys.argv[1]
start = int(sys.argv[2])
bind_host = "" if host in {"0.0.0.0", "::"} else host
for port in range(start, start + 80):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((bind_host, port))
        except OSError:
            continue
        print(port)
        raise SystemExit(0)
raise SystemExit(1)
PY
}

print_running_service_hint() {
  local port="$1"
  if command -v netstat.exe >/dev/null 2>&1; then
    netstat.exe -ano 2>/dev/null | grep -E "[:.]${port}[[:space:]]" | head -n 5 || true
  fi
}

legacy_wait_for_web() {
  local url="$1"
  "$VENV_PYTHON" - "$url" <<'PY'
import sys, time, urllib.request
url = sys.argv[1]
for _ in range(180):
    try:
        with urllib.request.urlopen(url, timeout=2) as r:
            if 200 <= getattr(r, 'status', 200) < 500:
                raise SystemExit(0)
    except Exception:
        time.sleep(1)
raise SystemExit(1)
PY
}

open_browser() {
  local url="$1"
  [[ "$OPEN_BROWSER" == "1" ]] || return 0

  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$url" >/dev/null 2>&1 & disown || true
    return 0
  fi
  if command -v open >/dev/null 2>&1; then
    open "$url" >/dev/null 2>&1 & disown || true
    return 0
  fi
  if command -v powershell.exe >/dev/null 2>&1; then
    powershell.exe -NoProfile -Command "Start-Process '$url'" >/dev/null 2>&1 || true
    return 0
  fi
  if command -v cmd.exe >/dev/null 2>&1; then
    cmd.exe /c start "" "$url" >/dev/null 2>&1 || true
    return 0
  fi
  warn "未找到可用浏览器启动器，请手动打开: $url"
}

banner

if ! select_python; then
  err "未找到 Python 3.11。请安装 Python 3.11，或通过 POLARIS_OS_PYTHON 指定解释器。"
  pause_on_error
  exit 1
fi
log "使用 Python 解释器: $PYTHON_LABEL"

ensure_venv
prepare_cuda_runtime

if [[ "$AUTO_INSTALL" == "1" ]]; then
  if need_install; then
    log "检测到核心依赖已就绪，跳过自动安装。"
  else
    warn "检测到环境缺少关键依赖，开始自适应安装。"
    bash "$PROJECT_DIR/install.sh"
  fi
else
  warn "已禁用自动安装 (POLARIS_OS_AUTO_INSTALL=0)。"
fi

PORT="$(read_port)"
URL="http://${HOST}:${PORT}"

if [[ "${POLARIS_OS_STRICT_PORT:-${FORGEX_STRICT_PORT:-0}}" != "1" ]] && url_responds "$URL"; then
  warn "端口 ${PORT} 已经有服务响应，可能是旧的 ForgeX/POLARIS 进程。"
  print_running_service_hint "$PORT"
  NEW_PORT="$(find_free_port "$HOST" "$((PORT + 1))" || true)"
  if [[ -n "$NEW_PORT" ]]; then
    PORT="$NEW_PORT"
    URL="http://${HOST}:${PORT}"
    log "本次改用空闲端口: $PORT"
  else
    warn "没有找到空闲备用端口，将继续尝试原端口。"
  fi
fi

export FORGEX_SERVER_HOST="$HOST"
export FORGEX_SERVER_PORT="$PORT"
export POLARIS_OS_SERVER_HOST="$HOST"
export POLARIS_OS_SERVER_PORT="$PORT"

log "启动 ${APP_NAME}，地址: $URL"
"$VENV_PYTHON" main.py &
APP_PID=$!

cleanup() {
  if [[ -n "${APP_PID:-}" ]] && kill -0 "$APP_PID" >/dev/null 2>&1; then
    kill "$APP_PID" >/dev/null 2>&1 || true
  fi
}
trap cleanup INT TERM

if wait_for_web "$URL" "$APP_PID" "POLARIS"; then
  log "服务已响应，正在打开浏览器..."
  open_browser "$URL"
else
  warn "服务未在预期时间内响应，浏览器不会自动打开。你仍可稍后手动访问: $URL"
fi

set +e
wait "$APP_PID"
EXIT_CODE=$?
set -e
trap - INT TERM ERR

if [[ $EXIT_CODE -ne 0 ]]; then
  err "程序退出，状态码: $EXIT_CODE"
  pause_on_error
else
  log "POLARIS OS 已退出。"
fi

exit $EXIT_CODE
