# POLARIS OS / 北极星

POLARIS OS 是一个面向本地 GPU 的 AI 训练工作台，用 Gradio 提供桌面式本地界面，覆盖数据管理、SFT/偏好训练、LoRA/QLoRA、导出 GGUF、任务队列、日志监控和环境自检。

这个仓库包是 GitHub 源码版。它不包含虚拟环境、模型权重、训练数据、LoRA 输出、GGUF 文件或缓存。首次运行时请按文档安装依赖，并把模型和数据放到本机目录中。

## Highlights

- 本地训练工作台：项目、数据、训练、导出、日志和设置集中在一个 App Shell 中。
- 支持主流本地训练流程：SFT、DPO、ORPO、KTO、LoRA、QLoRA、DoRA、rsLoRA、Sample Packing。
- 面向消费级显卡优化：RTX 5080 Laptop / 16GB 等移动显卡默认使用更稳的 batch 1、seq 2048、GA 8。
- 训练稳定性保护：默认关闭验证集评估和 label smoothing，避免 eval/logits 显存峰值 OOM。
- 导出能力：支持 LoRA 合并、GGUF 导出、Runtime 打包和本地推理服务。

## Quick Start

### Windows

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt -c constraints.txt
python selfcheck.py
python main.py
```

也可以直接运行：

```powershell
.\run.bat
```

如果你使用 Git Bash / MSYS2：

```bash
bash run.sh
```

启动后打开终端里显示的本地地址，例如：

```text
http://127.0.0.1:7860
```

## Recommended Defaults

对 16GB 移动显卡，尤其是 RTX 5080 Laptop，建议先这样测试：

```text
batch_size = 1
gradient_accumulation_steps = 8
max_seq_len = 2048
label_smoothing = 0
eval_ratio = 0
use_packing = true
```

如果发生 CUDA OOM，先停止训练并重启 POLARIS OS 服务，再降低 `max_seq_len` 到 1024 或开启 QLoRA。

## Repository Layout

```text
core/              training, export, runtime and utility modules
ui/                UI assets and style helpers
launcher/          optional local launcher resources
installer/         installer and deployment experiments
scripts/           maintenance scripts
tests/             lightweight tests
data/              local runtime data folders, kept empty in git
docs/              install, hardware and troubleshooting docs
main.py            Gradio application entry
run.sh             adaptive local launcher
run.bat            Windows launcher
selfcheck.py       environment self-check
```

## What Is Not Included

This GitHub package intentionally excludes:

- `.venv/`
- `data/loras/`
- `data/models_cache/`
- `data/datasets/*.jsonl`
- GGUF / safetensors / bin / checkpoint files
- build output and wheelhouse folders

Keep those files local or publish them through a separate release artifact if needed.

## Docs

- [Windows install guide](docs/INSTALL_WINDOWS.md)
- [Hardware presets](docs/HARDWARE_PRESETS.md)
- [CUDA troubleshooting](docs/TROUBLESHOOTING_CUDA.md)
- [GitHub upload checklist](docs/GITHUB_UPLOAD_CHECKLIST.md)
- [VIP release notes](docs/RELEASE_NOTES_PHASE_2B_VIP.md)

## License

No open-source license is granted by default in this package. Replace `LICENSE.md` before public distribution if you want to publish it under MIT, Apache-2.0, GPL, or another license.
