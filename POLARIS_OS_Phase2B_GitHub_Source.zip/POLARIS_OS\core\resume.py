"""Resume discovery and validation for training runs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from core.config import DATASETS_DIR, LORAS_DIR
from core.run_manifest import (
    MANIFEST_FILENAME,
    latest_checkpoint,
    load_manifest,
    manifest_path,
    normalize_dataset_list,
)


CORE_PARAM_KEYS = {
    "lr",
    "batch_size",
    "max_seq_len",
    "use_qlora",
    "rank",
    "gradient_accumulation_steps",
    "warmup_ratio",
    "use_dora",
    "use_rslora",
    "use_packing",
    "auto_clean",
    "label_smoothing",
    "neftune_noise_alpha",
}


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _adapter_base(out_dir: Path) -> str:
    cfg = _read_json(out_dir / "adapter_config.json")
    return str(cfg.get("base_model_name_or_path") or "")


def _looks_like_local_path(value: str) -> bool:
    raw = str(value or "").strip()
    if not raw:
        return False
    p = Path(raw).expanduser()
    return p.is_absolute() or raw.startswith((".", "~")) or "\\" in raw or Path(raw).exists()


def _summary_from_manifest(out_dir: Path, data: Dict[str, Any]) -> Dict[str, Any]:
    checkpoint = str(data.get("last_checkpoint") or latest_checkpoint(out_dir) or "")
    datasets = normalize_dataset_list(data.get("dataset_list") or data.get("datasets") or [])
    status = str(data.get("status") or "unknown")
    return {
        "run_id": str(data.get("run_id") or out_dir.name),
        "output_name": out_dir.name,
        "output_dir": str(out_dir),
        "status": status,
        "method": str(data.get("method") or "sft").upper(),
        "base_model": str(data.get("base_model") or ""),
        "datasets": datasets,
        "dataset_count": len(datasets),
        "last_heartbeat": str(data.get("last_heartbeat") or ""),
        "last_checkpoint": checkpoint,
        "checkpoint_name": Path(checkpoint).name if checkpoint else "",
        "error_message": str(data.get("error_message") or ""),
        "manifest_path": str(manifest_path(out_dir)),
        "source": "manifest",
        "recoverable": bool(checkpoint),
    }


def _summary_from_legacy(out_dir: Path) -> Dict[str, Any]:
    meta = _read_json(out_dir / "forgex_meta.json")
    checkpoint = latest_checkpoint(out_dir)
    datasets = normalize_dataset_list(meta.get("datasets") or [])
    return {
        "run_id": f"legacy:{out_dir.name}",
        "output_name": out_dir.name,
        "output_dir": str(out_dir),
        "status": "legacy",
        "method": str(meta.get("method") or "sft").upper(),
        "base_model": str(meta.get("base_model") or _adapter_base(out_dir)),
        "datasets": datasets,
        "dataset_count": len(datasets),
        "last_heartbeat": str(meta.get("timestamp") or ""),
        "last_checkpoint": checkpoint,
        "checkpoint_name": Path(checkpoint).name if checkpoint else "",
        "error_message": "",
        "manifest_path": "",
        "source": "legacy",
        "recoverable": bool(checkpoint),
    }


def list_resumable_runs(loras_dir: Path | None = None) -> List[Dict[str, Any]]:
    root = Path(loras_dir or LORAS_DIR)
    if not root.exists():
        return []
    runs: List[Dict[str, Any]] = []
    for out_dir in sorted(root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
        if not out_dir.is_dir():
            continue
        data = load_manifest(out_dir / MANIFEST_FILENAME)
        if data:
            runs.append(_summary_from_manifest(out_dir, data))
            continue
        if latest_checkpoint(out_dir):
            runs.append(_summary_from_legacy(out_dir))
    return runs


def resumable_choices() -> List[str]:
    choices = []
    for run in list_resumable_runs():
        if not run.get("last_checkpoint"):
            continue
        status = run.get("status") or "unknown"
        ckpt = run.get("checkpoint_name") or "checkpoint"
        choices.append(f"{run['output_name']} ({status}; {ckpt})")
    return choices


def resumable_table() -> List[List[str]]:
    rows: List[List[str]] = []
    for run in list_resumable_runs():
        rows.append([
            str(run.get("run_id", "")),
            str(run.get("output_name", "")),
            str(run.get("status", "")),
            str(run.get("last_heartbeat", "")),
            str(run.get("checkpoint_name", "") or "无"),
            str(run.get("dataset_count", 0)),
            str(run.get("error_message", ""))[:160],
        ])
    return rows


def extract_output_name(choice: str) -> str:
    raw = str(choice or "").strip()
    if not raw:
        return ""
    return raw.split(" (", 1)[0].strip()


def checkpoint_choices_for_output(choice: str) -> List[str]:
    output_name = extract_output_name(choice)
    if not output_name:
        return ["最新"]
    out_dir = LORAS_DIR / output_name
    if not out_dir.exists():
        return ["最新"]
    ckpts = []
    for d in sorted(out_dir.glob("checkpoint-*"), key=lambda p: p.name):
        if d.is_dir():
            ckpts.append(d.name)
    return ["最新"] + ckpts


def _resolve_checkpoint(out_dir: Path, checkpoint_name: str) -> str:
    if checkpoint_name and checkpoint_name != "最新":
        checkpoint = out_dir / checkpoint_name
    else:
        latest = latest_checkpoint(out_dir)
        checkpoint = Path(latest) if latest else Path("")
    if not checkpoint or not checkpoint.exists():
        raise FileNotFoundError(f"没有找到可恢复 checkpoint: {out_dir}")
    return str(checkpoint)


def _load_training_metadata(out_dir: Path) -> Dict[str, Any]:
    manifest = load_manifest(out_dir)
    if manifest:
        params = manifest.get("training_params") or {}
        return {
            "source": "manifest",
            "base_model": manifest.get("base_model", ""),
            "method": manifest.get("method", "sft"),
            "datasets": manifest.get("dataset_list", []),
            "params": params,
            "manifest": manifest,
        }

    legacy = _read_json(out_dir / "forgex_meta.json")
    return {
        "source": "legacy",
        "base_model": legacy.get("base_model", "") or _adapter_base(out_dir),
        "method": legacy.get("method", "sft"),
        "datasets": legacy.get("datasets", []),
        "params": legacy.get("params", {}),
        "manifest": {},
    }


def validate_resume_sources(base_model: str, datasets: List[str]) -> List[str]:
    errors: List[str] = []
    if not base_model:
        errors.append("无法确定基座模型。请保留 run_manifest.json 或 forgex_meta.json。")
    elif _looks_like_local_path(base_model) and not Path(base_model).expanduser().exists():
        errors.append(f"基座模型路径不存在: {base_model}")

    if not datasets:
        errors.append("没有可用数据集。")
    for ds in datasets:
        p = Path(ds).expanduser()
        if not p.is_absolute():
            p = DATASETS_DIR / ds
        if not p.exists():
            errors.append(f"数据集不存在: {ds}")
    return errors


def compare_resume_params(original: Dict[str, Any], candidate: Dict[str, Any]) -> List[str]:
    mismatches = []
    for key in sorted(CORE_PARAM_KEYS):
        if key not in original or key not in candidate:
            continue
        if str(original.get(key)) != str(candidate.get(key)):
            mismatches.append(f"{key}: {original.get(key)} != {candidate.get(key)}")
    return mismatches


def build_resume_plan(
    lora_choice: str,
    checkpoint_name: str,
    extra_datasets: Any,
    extra_epochs: float,
) -> Dict[str, Any]:
    output_name = extract_output_name(lora_choice)
    if not output_name:
        raise ValueError("请选择要恢复的训练。")

    out_dir = LORAS_DIR / output_name
    if not out_dir.exists():
        raise FileNotFoundError(f"LoRA 输出目录不存在: {out_dir}")

    checkpoint = _resolve_checkpoint(out_dir, checkpoint_name)
    meta = _load_training_metadata(out_dir)
    base_model = str(meta.get("base_model") or "")
    method = str(meta.get("method") or "sft")
    orig_datasets = normalize_dataset_list(meta.get("datasets") or [])

    if isinstance(extra_datasets, str):
        extra_ds = [extra_datasets] if extra_datasets else []
    elif isinstance(extra_datasets, (list, tuple)):
        extra_ds = [str(x) for x in extra_datasets if x]
    else:
        extra_ds = []

    seen_names = {Path(d).name for d in orig_datasets}
    datasets = list(orig_datasets)
    for item in extra_ds:
        if Path(item).name not in seen_names:
            datasets.append(str(DATASETS_DIR / item))
            seen_names.add(Path(item).name)

    params = dict(meta.get("params") or {})
    params.update({
        "output_name": output_name,
        "epochs": float(extra_epochs or params.get("epochs", 1)),
        "resume_from_checkpoint": checkpoint,
    })
    params.setdefault("lr", 2e-4)
    params.setdefault("batch_size", 1)
    params.setdefault("max_seq_len", params.get("max_seq_length", 2048))
    params.setdefault("use_qlora", False)
    params.setdefault("rank", 64)
    params.setdefault("gradient_accumulation_steps", 8)
    params.setdefault("warmup_ratio", 0.05)
    params.setdefault("use_dora", True)
    params.setdefault("use_rslora", True)
    params.setdefault("use_packing", True)
    params.setdefault("auto_clean", True)
    params.setdefault("label_smoothing", 0.0)
    params.setdefault("neftune_noise_alpha", 5.0)

    errors = validate_resume_sources(base_model, datasets)
    mismatches = compare_resume_params(meta.get("params") or {}, params)
    if mismatches:
        errors.append("恢复参数不一致: " + "; ".join(mismatches[:6]))
    if errors:
        raise ValueError("；".join(errors))

    return {
        "output_name": output_name,
        "output_dir": str(out_dir),
        "base_model": base_model,
        "method": method,
        "datasets": datasets,
        "params": params,
        "checkpoint_path": checkpoint,
        "checkpoint_name": Path(checkpoint).name,
        "extra_dataset_names": extra_ds,
        "source": meta.get("source", ""),
    }
