from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist" / "windows_installer"
STAGE = DIST / "POLARIS_OS_Source"
SOURCE_ZIP = DIST / "POLARIS_Source.zip"
SETUP_EXE = DIST / "POLARIS_OS_Setup.exe"
PORTABLE_ZIP = DIST / "POLARIS_OS_Portable.zip"
OUTPUTS = Path(r"C:\Users\夏霖云\Documents\Codex\2026-06-04\windows-python-ai-polaris-os-gradio\outputs")

EXCLUDE_DIRS = {
    ".venv",
    "__pycache__",
    ".git",
    "dist",
    "build",
    ".pytest_cache",
}

EXCLUDE_FILES = {
    "install_state.json",
}

EXCLUDE_PREFIXES = {
    "data/loras",
    "data/models_cache",
    "data/logs",
    "data/runs",
    "data/tmp",
    "data/datasets",
}


def inside(path: Path, parent: Path) -> bool:
    path = path.resolve()
    parent = parent.resolve()
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def safe_rmtree(path: Path, allowed_parent: Path) -> None:
    if not path.exists():
        return
    if not inside(path, allowed_parent):
        raise RuntimeError(f"Refusing to delete outside {allowed_parent}: {path}")
    shutil.rmtree(path)


def find_csc() -> Path:
    found = shutil.which("csc.exe") or shutil.which("csc")
    if found:
        return Path(found)
    candidates = [
        Path(r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"),
        Path(r"C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"),
    ]
    for csc in candidates:
        if csc.exists():
            return csc
    raise RuntimeError("csc.exe not found. Install .NET Framework build tools.")


def run(cmd: list[str], cwd: Path = ROOT) -> None:
    print("$ " + " ".join(f'"{x}"' if " " in str(x) else str(x) for x in cmd), flush=True)
    subprocess.check_call(cmd, cwd=str(cwd))


def should_skip(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    rel_posix = rel.as_posix()
    parts = set(rel.parts)
    if parts & EXCLUDE_DIRS:
        return True
    if any(rel_posix == prefix or rel_posix.startswith(prefix + "/") for prefix in EXCLUDE_PREFIXES):
        return True
    if path.name in EXCLUDE_FILES:
        return True
    if path.name.startswith("train_") and path.suffix.lower() == ".jsonl":
        return True
    if path.suffix.lower() in {".pyc", ".pyo", ".log", ".tmp"}:
        return True
    return False


def copy_source_tree() -> None:
    safe_rmtree(STAGE, DIST)
    STAGE.mkdir(parents=True, exist_ok=True)
    for item in ROOT.rglob("*"):
        if should_skip(item):
            continue
        rel = item.relative_to(ROOT)
        target = STAGE / rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif item.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)
    for rel in ("wheelhouse", "data/datasets", "data/loras", "data/models_cache", "data/logs", "data/configs"):
        (STAGE / rel).mkdir(parents=True, exist_ok=True)


def compile_launcher(csc: Path) -> Path:
    out = ROOT / "launcher" / "POLARIS_OS_Launcher.exe"
    cmd = [
        str(csc),
        "/nologo",
        "/codepage:65001",
        "/target:winexe",
        "/platform:anycpu",
        "/reference:System.Windows.Forms.dll",
        "/reference:System.Drawing.dll",
        "/out:" + str(out),
        str(ROOT / "launcher" / "POLARIS_OS_Launcher.cs"),
    ]
    run(cmd)
    return out


def compile_setup(csc: Path) -> Path:
    cmd = [
        str(csc),
        "/nologo",
        "/codepage:65001",
        "/target:winexe",
        "/platform:anycpu",
        "/reference:System.Windows.Forms.dll",
        "/reference:System.Drawing.dll",
        "/reference:System.IO.Compression.dll",
        "/reference:System.IO.Compression.FileSystem.dll",
        "/out:" + str(SETUP_EXE),
        "/resource:" + str(SOURCE_ZIP) + ",POLARIS_Source.zip",
        str(ROOT / "installer" / "POLARIS_OS_Setup.cs"),
    ]
    run(cmd)
    return SETUP_EXE


def zip_dir(source: Path, zip_path: Path, root_name: str | None = None) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for path in source.rglob("*"):
            if path.is_file():
                rel = path.relative_to(source)
                arc = Path(root_name) / rel if root_name else rel
                zf.write(path, arc.as_posix())


def write_report(out_setup: Path, out_zip: Path, copied_setup: Path, copied_zip: Path) -> Path:
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    report = OUTPUTS / "POLARIS_OS_Installer_Report.md"
    text = f"""# POLARIS OS Windows Installer Report

Build time: {time.strftime('%Y-%m-%d %H:%M:%S')}

## Strategy

- Installer: .NET Framework WinForms setup EXE with embedded source zip.
- Launcher: .NET Framework WinForms desktop launcher, no visible console.
- Environment: Python 3.11 venv managed by `scripts/bootstrap_env.py`.
- Healthcheck: `scripts/healthcheck.py` validates Python, venv, pip, torch, CUDA, Gradio, `main.py`, port and service response.

## Artifacts

- Setup: `{copied_setup}`
- Portable zip: `{copied_zip}`
- Build setup: `{out_setup}`
- Build portable zip: `{out_zip}`

## Encoding Fix

- Launcher and installer read redirected Python stdout/stderr as UTF-8.
- C# sources are compiled with `/codepage:65001`.
- This fixes mojibake in Chinese paths and app logs such as `[compat] 已修补: PIL.ANTIALIAS`.

## Audit Summary

- Preserved `run.sh` and existing `main.py` launch behavior.
- Gradio still launches from `main.py`; Windows launcher only chooses host/port and starts the service.
- Task queue, export pipeline and training core are not rewritten.
- Training guard added in `core/trainer.py`: model context limit detection, max sequence downgrade, token batch validation before GPU, and CUDA device-side assert restart guidance.

## Verification To Run

- `py -3.11 scripts/bootstrap_env.py --dry-run --backend cpu`
- `.venv\\Scripts\\python.exe scripts\\healthcheck.py --project-dir .`
- `.venv\\Scripts\\python.exe scripts\\healthcheck.py --project-dir . --start-main --port 7860`
"""
    report.write_text(text, encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-setup", action="store_true")
    args = parser.parse_args()

    csc = find_csc()
    safe_rmtree(DIST, ROOT / "dist")
    DIST.mkdir(parents=True, exist_ok=True)
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    launcher = compile_launcher(csc)
    copy_source_tree()
    shutil.copy2(launcher, STAGE / "launcher" / "POLARIS_OS_Launcher.exe")

    zip_dir(STAGE, SOURCE_ZIP)
    zip_dir(STAGE, PORTABLE_ZIP, root_name="POLARIS_OS_Source")

    if args.skip_setup:
        print("Skipped setup exe build.")
    else:
        compile_setup(csc)

    copied_setup = OUTPUTS / "POLARIS_OS_Setup.exe"
    copied_zip = OUTPUTS / "POLARIS_OS_Portable.zip"
    if SETUP_EXE.exists():
        shutil.copy2(SETUP_EXE, copied_setup)
    shutil.copy2(PORTABLE_ZIP, copied_zip)
    report = write_report(SETUP_EXE, PORTABLE_ZIP, copied_setup, copied_zip)
    print("Built:")
    if SETUP_EXE.exists():
        print("  " + str(copied_setup))
    print("  " + str(copied_zip))
    print("  " + str(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
