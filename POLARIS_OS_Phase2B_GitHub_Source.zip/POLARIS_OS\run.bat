cd /d %~dp0
@echo off
chcp 65001 >nul
title 北极星 POLARIS OS
set HF_ENDPOINT=https://hf-mirror.com
echo 启动 北极星 POLARIS OS...
py -3.11 --version >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] 未找到 Python 3.11。请先安装 Python 3.11。
    pause
    exit /b 1
)
py -3.11 main.py
if %errorlevel% neq 0 (
    echo.
    echo 启动失败！运行 install.bat 安装依赖
)
pause
