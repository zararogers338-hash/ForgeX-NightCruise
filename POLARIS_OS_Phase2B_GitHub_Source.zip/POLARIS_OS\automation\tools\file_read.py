from pathlib import Path

def run(path, encoding='utf-8', max_chars=200000):
    p = Path(path).expanduser().resolve()
    text = p.read_text(encoding=encoding, errors='ignore')
    return {'ok': True, 'path': str(p), 'text': text[:max_chars], 'truncated': len(text) > max_chars}
