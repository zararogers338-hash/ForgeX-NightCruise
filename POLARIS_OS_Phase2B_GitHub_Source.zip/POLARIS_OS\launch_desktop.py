from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def _find_free_port(host: str, start: int) -> int:
    bind_host = "" if host in {"0.0.0.0", "::"} else host
    for port in range(start, start + 80):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((bind_host, port))
            except OSError:
                continue
            return port
    raise RuntimeError(f"No free port found from {start} to {start + 79}")


def _wait_for(url: str, proc: subprocess.Popen[str], timeout: int = 180) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc.poll() is not None:
            return False
        try:
            with urllib.request.urlopen(url, timeout=2) as response:
                if 200 <= getattr(response, "status", 200) < 500:
                    return True
        except Exception:
            time.sleep(1)
    return False


def _stop(proc: subprocess.Popen[str]) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=8)
    except subprocess.TimeoutExpired:
        proc.kill()


def main() -> int:
    host = os.environ.get("POLARIS_OS_SERVER_HOST") or os.environ.get("FORGEX_SERVER_HOST") or "127.0.0.1"
    start_port = int(os.environ.get("POLARIS_OS_SERVER_PORT") or os.environ.get("FORGEX_SERVER_PORT") or "7860")
    port = _find_free_port(host, start_port)
    url = f"http://{host}:{port}"

    env = os.environ.copy()
    env["POLARIS_OS_SERVER_HOST"] = host
    env["POLARIS_OS_SERVER_PORT"] = str(port)
    env["FORGEX_SERVER_HOST"] = host
    env["FORGEX_SERVER_PORT"] = str(port)
    env.setdefault("POLARIS_OS_OPEN_BROWSER", "0")
    env.setdefault("PYTHONIOENCODING", "utf-8")

    proc = subprocess.Popen(
        [sys.executable, str(ROOT / "main.py")],
        cwd=str(ROOT),
        env=env,
        text=True,
    )

    try:
        if not _wait_for(url, proc):
            print(f"POLARIS OS did not become ready. Try opening manually: {url}")
            return proc.wait()

        try:
            import webview  # type: ignore

            webview.create_window(
                "北极星 POLARIS OS",
                url,
                width=1440,
                height=940,
                min_size=(1024, 720),
                confirm_close=True,
            )
            webview.start()
        except Exception:
            print(f"pywebview is unavailable; opening the local studio in your browser: {url}")
            webbrowser.open(url)
            proc.wait()
        return 0
    finally:
        _stop(proc)


if __name__ == "__main__":
    raise SystemExit(main())
