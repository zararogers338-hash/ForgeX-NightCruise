from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
STATE_FILE = ROOT / "data" / "install_state.json"


def load_state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def log_dir() -> Path:
    state = load_state()
    raw = ((state.get("paths") or {}).get("logs") or "")
    if raw:
        path = Path(raw)
    else:
        path = Path(os.environ.get("LOCALAPPDATA", str(ROOT / "data"))) / "POLARIS OS" / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def venv_python() -> Path:
    state = load_state()
    raw = ((state.get("python") or {}).get("venv_python") or "")
    if raw and Path(raw).exists():
        return Path(raw)
    cand = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    return cand


def find_free_port(host: str, start: int) -> int:
    bind_host = "" if host in {"0.0.0.0", "::"} else host
    for port in range(start, start + 100):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((bind_host, port))
            except OSError:
                continue
            return port
    raise RuntimeError(f"没有找到空闲端口: {start}-{start + 99}")


def wait_http(url: str, proc: subprocess.Popen, timeout: int) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc.poll() is not None:
            return False
        try:
            with urllib.request.urlopen(url, timeout=2) as response:
                if 200 <= getattr(response, "status", 200) < 500:
                    return True
        except Exception:
            time.sleep(1)
    return False


def env_for_launch(host: str, port: int) -> dict[str, str]:
    env = os.environ.copy()
    state = load_state()
    paths = state.get("paths") or {}
    env.update({
        "POLARIS_OS_SERVER_HOST": host,
        "POLARIS_OS_SERVER_PORT": str(port),
        "FORGEX_SERVER_HOST": host,
        "FORGEX_SERVER_PORT": str(port),
        "FORGEX_SHARE": "false",
        "POLARIS_OS_OPEN_BROWSER": "0",
        "PYTHONUTF8": "1",
        "PYTHONIOENCODING": "utf-8",
    })
    if paths.get("models_cache"):
        env["POLARIS_OS_MODELS_CACHE_DIR"] = str(paths["models_cache"])
    if paths.get("logs"):
        env["POLARIS_OS_LOGS_DIR"] = str(paths["logs"])
    if paths.get("hf_cache"):
        env.setdefault("HF_HOME", str(paths["hf_cache"]))
        env.setdefault("TRANSFORMERS_CACHE", str(paths["hf_cache"]))
    if state.get("backend") == "cpu":
        env.setdefault("CUDA_VISIBLE_DEVICES", "-1")
    return env


def main() -> int:
    parser = argparse.ArgumentParser(description="Launch POLARIS OS local Gradio service.")
    parser.add_argument("--host", default=os.environ.get("POLARIS_OS_SERVER_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("POLARIS_OS_SERVER_PORT", "7860")))
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()

    py = venv_python()
    if not py.exists():
        print(f"未找到虚拟环境 Python: {py}")
        print("请先运行安装器或 scripts/bootstrap_env.py。")
        return 2
    port = find_free_port(args.host, int(args.port))
    url = f"http://{args.host}:{port}/"
    log_path = log_dir() / f"launcher_{time.strftime('%Y%m%d_%H%M%S')}.log"
    with log_path.open("w", encoding="utf-8", errors="replace") as log:
        print(f"启动 POLARIS OS: {url}")
        print(f"日志: {log_path}")
        proc = subprocess.Popen(
            [str(py), str(ROOT / "main.py")],
            cwd=str(ROOT),
            env=env_for_launch(args.host, port),
            stdout=log,
            stderr=subprocess.STDOUT,
            text=True,
        )
        try:
            if not wait_http(url, proc, args.timeout):
                print(f"服务未按时响应，请查看日志: {log_path}")
                return proc.poll() if proc.poll() is not None else 3
            print(f"服务已启动: {url}")
            if not args.no_browser:
                webbrowser.open(url)
            return proc.wait()
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()


if __name__ == "__main__":
    raise SystemExit(main())
