#!/usr/bin/env bash
# 北极星 / POLARIS OS - 自适应环境安装脚本
# 目标：新建/复用虚拟环境，并根据硬件安装更合适的依赖栈，而不是硬编码单一版本路线

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

PRODUCT_NAME="北极星 / POLARIS OS"
VENV_DIR="${POLARIS_OS_VENV_DIR:-${FORGEX_VENV_DIR:-$PROJECT_DIR/.venv}}"
PIP_ARGS=(--upgrade)
[[ -n "${PIP_INDEX_URL:-}" ]] && PIP_ARGS+=(--index-url "$PIP_INDEX_URL")
PAUSE_ON_ERROR="${POLARIS_OS_PAUSE_ON_ERROR:-${FORGEX_PAUSE_ON_ERROR:-1}}"
PYTHON_CMD=()
PYTHON_LABEL=""

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err() { echo -e "${RED}[ERROR]${NC} $*"; }

pause_on_error() {
  [[ "$PAUSE_ON_ERROR" == "1" ]] || return 0
  [[ -t 0 ]] || return 0
  case "$(uname -s)" in
    MINGW*|MSYS*|CYGWIN*)
      echo ""
      read -r -p "安装失败，按回车关闭窗口..." _ || true
      ;;
  esac
}

on_error() {
  local exit_code=$?
  local line_no=${1:-unknown}
  err "安装脚本在第 ${line_no} 行失败，退出码: ${exit_code}"
  pause_on_error
  exit "$exit_code"
}
trap 'on_error $LINENO' ERR

python_is_311() {
  "$@" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)
PY
}

select_python() {
  local requested="${POLARIS_OS_PYTHON:-${FORGEX_PYTHON:-}}"
  if [[ -n "$requested" ]] && command -v "$requested" >/dev/null 2>&1; then
    if python_is_311 "$requested"; then
      PYTHON_CMD=("$requested")
      PYTHON_LABEL="$requested"
      return 0
    fi
    warn "指定的解释器不是 Python 3.11，已忽略: $requested"
  fi
  if command -v py >/dev/null 2>&1 && python_is_311 py -3.11; then
    PYTHON_CMD=(py -3.11)
    PYTHON_LABEL="py -3.11"
    return 0
  fi
  for py in python3.11 python; do
    if command -v "$py" >/dev/null 2>&1 && python_is_311 "$py"; then
      PYTHON_CMD=("$py")
      PYTHON_LABEL="$py"
      return 0
    fi
  done
  return 1
}

base_python() {
  "${PYTHON_CMD[@]}" "$@"
}

venv_is_311() {
  local py="$1"
  "$py" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)
PY
}

venv_python_path() {
  if [[ -x "$VENV_DIR/bin/python" ]]; then
    echo "$VENV_DIR/bin/python"
    return 0
  fi
  if [[ -x "$VENV_DIR/Scripts/python.exe" ]]; then
    echo "$VENV_DIR/Scripts/python.exe"
    return 0
  fi
  if [[ -x "$VENV_DIR/Scripts/python" ]]; then
    echo "$VENV_DIR/Scripts/python"
    return 0
  fi
  return 1
}

venv_activate_path() {
  if [[ -f "$VENV_DIR/bin/activate" ]]; then
    echo "$VENV_DIR/bin/activate"
    return 0
  fi
  if [[ -f "$VENV_DIR/Scripts/activate" ]]; then
    echo "$VENV_DIR/Scripts/activate"
    return 0
  fi
  return 1
}

ensure_venv() {
  local vpy
  vpy="$(venv_python_path || true)"
  if [[ -n "$vpy" ]] && ! venv_is_311 "$vpy"; then
    local backup="${VENV_DIR}.python-mismatch.$(date +%Y%m%d_%H%M%S)"
    warn "现有虚拟环境不是 Python 3.11，将移到: $backup"
    mv "$VENV_DIR" "$backup"
    vpy=""
  fi
  if [[ -z "$vpy" ]]; then
    log "创建虚拟环境: $VENV_DIR"
    base_python -m venv "$VENV_DIR"
    vpy="$(venv_python_path || true)"
  fi
  if [[ -z "$vpy" ]]; then
    err "虚拟环境已创建，但未找到 Python 可执行文件。预期路径应为 .venv/bin/python 或 .venv/Scripts/python.exe"
    return 1
  fi
  VENV_PYTHON="$vpy"
  export VENV_PYTHON

  local act
  act="$(venv_activate_path || true)"
  if [[ -z "$act" ]]; then
    err "未找到虚拟环境激活脚本。预期路径应为 .venv/bin/activate 或 .venv/Scripts/activate"
    return 1
  fi
  # shellcheck disable=SC1090
  source "$act"
  export PYTHONUNBUFFERED=1
  export PIP_DISABLE_PIP_VERSION_CHECK=1
  "$VENV_PYTHON" -m pip install --upgrade pip setuptools wheel packaging
}

ver_ge() {
  "$VENV_PYTHON" - "$1" "$2" <<'PY'
from packaging.version import Version
import sys
raise SystemExit(0 if Version(sys.argv[1]) >= Version(sys.argv[2]) else 1)
PY
}

detect_hardware() {
  OS_NAME="$(uname -s)"
  ARCH_NAME="$(uname -m)"
  HW_KIND="cpu"
  TORCH_INDEX_URL="https://download.pytorch.org/whl/cpu"
  EXTRA_LABEL="cpu"
  NVIDIA_NAME=""
  CUDA_VERSION=""
  NVIDIA_COMPUTE_CAP=""
  TORCH_FORCE_REINSTALL=0

  if [[ "$OS_NAME" == "Darwin" ]]; then
    HW_KIND="apple"
    TORCH_INDEX_URL=""
    EXTRA_LABEL="mps"
    return 0
  fi

  if command -v nvidia-smi >/dev/null 2>&1; then
    HW_KIND="nvidia"
    NVIDIA_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -n1 | xargs || true)"
    NVIDIA_COMPUTE_CAP="$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -n1 | xargs || true)"
    CUDA_VERSION="$(nvidia-smi | sed -n 's/.*CUDA Version: \([0-9.]*\).*/\1/p' | head -n1)"
    if [[ -n "$NVIDIA_COMPUTE_CAP" ]] && ver_ge "$NVIDIA_COMPUTE_CAP" "12.0"; then
      TORCH_INDEX_URL="https://download.pytorch.org/whl/cu128"
      EXTRA_LABEL="cu128-sm120"
      TORCH_FORCE_REINSTALL=1
      if [[ -n "$CUDA_VERSION" ]] && ! ver_ge "$CUDA_VERSION" "12.8"; then
        warn "检测到 RTX 50 系 / sm_${NVIDIA_COMPUTE_CAP/./}，将优先安装 cu128 PyTorch。若后续 CUDA 初始化失败，请升级 NVIDIA 驱动。"
      fi
      return 0
    fi
    if [[ -z "$CUDA_VERSION" ]]; then
      TORCH_INDEX_URL="https://download.pytorch.org/whl/cu124"
      EXTRA_LABEL="cu124"
      return 0
    fi
    if ver_ge "$CUDA_VERSION" "12.8"; then
      TORCH_INDEX_URL="https://download.pytorch.org/whl/cu128"
      EXTRA_LABEL="cu128"
    elif ver_ge "$CUDA_VERSION" "12.6"; then
      TORCH_INDEX_URL="https://download.pytorch.org/whl/cu126"
      EXTRA_LABEL="cu126"
    elif ver_ge "$CUDA_VERSION" "12.4"; then
      TORCH_INDEX_URL="https://download.pytorch.org/whl/cu124"
      EXTRA_LABEL="cu124"
    else
      warn "检测到 NVIDIA，但 CUDA 版本较低 ($CUDA_VERSION)。将回退 CPU 轮子以减少安装失败。"
      HW_KIND="cpu"
      TORCH_INDEX_URL="https://download.pytorch.org/whl/cpu"
      EXTRA_LABEL="cpu"
    fi
  fi
}

install_torch_stack() {
  local torch_args=("${PIP_ARGS[@]}")
  if [[ "${TORCH_FORCE_REINSTALL:-0}" == "1" ]]; then
    torch_args+=(--force-reinstall)
  fi
  if [[ -n "$TORCH_INDEX_URL" ]]; then
    log "安装 PyTorch 轮子通道: $EXTRA_LABEL"
    "$VENV_PYTHON" -m pip install "${torch_args[@]}" torch torchvision torchaudio --index-url "$TORCH_INDEX_URL"
  else
    log "安装 PyTorch（系统默认轮子）"
    "$VENV_PYTHON" -m pip install "${torch_args[@]}" torch torchvision torchaudio
  fi
}

install_core_stack() {
  local core_packages=(
    "transformers>=4.47,<5"
    "datasets>=3,<5"
    "peft>=0.14,<1"
    "trl>=0.12,<1"
    "accelerate>=1,<2"
    "huggingface-hub>=0.25,<1"
    "safetensors>=0.4"
    "tokenizers>=0.20"
    "gradio>=4.40,<6"
    "numpy>=1.26,<2"
    "scipy>=1.13,<1.14"
    "pandas>=2.2,<2.3"
    "pyarrow>=21,<22"
    "scikit-learn>=1.5,<1.6"
    "PyYAML>=6"
    "requests>=2.31"
    "Pillow>=10"
    "sentencepiece>=0.2"
    "protobuf>=4.25,<6"
    "gguf>=0.10"
    "PyMuPDF>=1.24"
    "pdfplumber>=0.11"
    "python-docx>=1.1"
    "soundfile>=0.12"
    "librosa>=0.10"
    "openai>=1.30"
    "psutil>=5.9"
  )
  log "安装 POLARIS OS 核心依赖..."
  "$VENV_PYTHON" -m pip install "${PIP_ARGS[@]}" "${core_packages[@]}"
}

install_optional_stack() {
  if [[ "$HW_KIND" == "nvidia" && "$OS_NAME" == "Linux" && "$ARCH_NAME" == "x86_64" ]]; then
    log "安装 NVIDIA/Linux 可选加速包..."
    "$VENV_PYTHON" -m pip install "${PIP_ARGS[@]}" "bitsandbytes>=0.44" || warn "bitsandbytes 安装失败，将回退普通路径。"
  else
    warn "当前硬件不适合自动安装 bitsandbytes，已跳过。"
  fi

  if [[ "${POLARIS_OS_INSTALL_LLAMA_CPP:-${FORGEX_INSTALL_LLAMA_CPP:-0}}" == "1" ]]; then
    log "按用户要求尝试安装 llama-cpp-python（GGUF 本地推理/导出相关）..."
    "$VENV_PYTHON" -m pip install "${PIP_ARGS[@]}" "llama-cpp-python>=0.2.90" || warn "llama-cpp-python 安装失败，可稍后手动安装。"
  else
    warn "默认跳过 llama-cpp-python 源码构建；如需 GGUF 本地推理，请设置 POLARIS_OS_INSTALL_LLAMA_CPP=1 后重试。"
  fi

  if [[ "${POLARIS_OS_INSTALL_UNSLOTH:-${FORGEX_INSTALL_UNSLOTH:-0}}" == "1" ]]; then
    if [[ "$HW_KIND" == "nvidia" && "$OS_NAME" == "Linux" && "$ARCH_NAME" == "x86_64" ]]; then
      log "按用户要求尝试安装 Unsloth..."
      "$VENV_PYTHON" -m pip install "${PIP_ARGS[@]}" unsloth || warn "Unsloth 安装失败，POLARIS OS 会继续使用标准训练路径。"
    else
      warn "当前硬件不建议自动装 Unsloth，已跳过。"
    fi
  else
    warn "默认不自动安装 Unsloth；如需尝试，请设置 POLARIS_OS_INSTALL_UNSLOTH=1。"
  fi
}

verify_install() {
  local failed=()
  local checks=(
    "torch:torch"
    "gradio:gradio"
    "transformers:transformers"
    "datasets:datasets"
    "peft:peft"
    "trl:trl"
    "accelerate:accelerate"
    "yaml:yaml"
  )
  local item label mod output
  for item in "${checks[@]}"; do
    label="${item%%:*}"
    mod="${item#*:}"
    if output="$("$VENV_PYTHON" - "$mod" 2>&1 <<'PY'
import importlib
import sys
m = importlib.import_module(sys.argv[1])
print(getattr(m, "__version__", "ok"))
PY
    )"; then
      printf '  ✅ %-14s %s\n' "$label" "$output"
    else
      failed+=("$label")
      printf '  ❌ %-14s %s\n' "$label" "$output"
    fi
  done
  echo
  if (( ${#failed[@]} > 0 )); then
    warn "以下依赖导入失败: ${failed[*]}"
    return 1
  fi
  if ! "$VENV_PYTHON" - <<'PY'; then
import sys
try:
    import torch
    cap = torch.cuda.get_device_capability(0) if torch.cuda.is_available() else None
    arches = set(torch.cuda.get_arch_list() or [])
except Exception:
    raise SystemExit(0)
if cap and cap >= (12, 0) and "sm_120" not in arches:
    print(f"[WARN] 当前 PyTorch 不支持检测到的 GPU 架构 sm_{cap[0]}{cap[1]}，已编译架构: {sorted(arches)}")
    raise SystemExit(1)
raise SystemExit(0)
PY
    warn "检测到 RTX 50 系 GPU，但当前 PyTorch 轮子不支持 sm_120。请重新运行安装脚本，或升级 NVIDIA 驱动后重试。"
    return 1
  fi
  return 0
}

if ! select_python; then
  err "未找到 Python 3.11。请安装 Python 3.11，或通过 POLARIS_OS_PYTHON 指定解释器。"
  pause_on_error
  exit 1
fi
log "使用 Python 解释器: $PYTHON_LABEL"

ensure_venv
detect_hardware

log "平台: ${OS_NAME}/${ARCH_NAME}"
if [[ "$HW_KIND" == "nvidia" ]]; then
  log "检测到 NVIDIA GPU: ${NVIDIA_NAME:-unknown} | compute ${NVIDIA_COMPUTE_CAP:-unknown} | CUDA ${CUDA_VERSION:-unknown} | 轮子通道 ${EXTRA_LABEL}"
elif [[ "$HW_KIND" == "apple" ]]; then
  log "检测到 Apple 平台，将使用默认 PyTorch 轮子并启用 MPS 路线。"
else
  log "未检测到可用 GPU，将使用 CPU 路线。"
fi

install_torch_stack
install_core_stack
install_optional_stack

log "验证安装..."
verify_install
trap - ERR
log "安装完成。之后直接运行: ./run.sh"
