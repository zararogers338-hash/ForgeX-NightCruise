# ForgeX 完整依赖安装指南

## 版本策略

ForgeX 当前采用 **方案 B：正式支持新版本栈**。已按 Gradio 6、Transformers 5、TRL 0.28 进行兼容修补，不再把 `constraints.txt` 作为 Gradio 4 / Transformers 4 / TRL 0.9 的保守基线。

已覆盖的关键变更：
- Gradio 6：`Dataframe.col_count` 已改为 `column_count`。
- Transformers 5：训练器入口继续通过签名检测兼容 `processing_class` / `tokenizer` 参数差异。
- TRL 0.28：`DataCollatorForCompletionOnlyLM` 不再依赖 TRL 内置导出，ForgeX 自带 completion-only fallback。
- Blackwell GPU：compute capability >= 10 时自动使用 SDPA/eager，并禁用 flash_attn/xformers。

---

## 适用硬件: NVIDIA RTX 5060 / 5060 Ti (Blackwell, sm_120, 8GB VRAM)

> **核心问题**: RTX 5060 使用 Blackwell 架构 (sm_120)，截至 2026 年 2 月，PyTorch 稳定版
> 对 sm_120 的支持仍不完善。必须使用 **cu128 构建** 才能正确启用 GPU 加速。
> 此外 **flash-attn 和 xformers 均不支持 sm_120**，ForgeX 已内置自动禁用逻辑，
> 会 fallback 到 SDPA/eager attention，无需手动处理。

---

## 前置要求

| 项目         | 要求                                       |
|:------------ |:------------------------------------------ |
| 操作系统     | Ubuntu 22.04 / 24.04 LTS (Linux 最佳)     |
| Python       | 3.11.x（兼容性最佳，3.12 也可）           |
| NVIDIA 驱动  | ≥ 576.x（支持 CUDA 12.8+）                |
| CUDA Toolkit | 12.8+（驱动自带，无需单独安装）           |
| 磁盘空间     | ≥ 50GB（模型 + 缓存）                     |
| 内存         | ≥ 16GB RAM                                |

---

## 第 0 步: 创建虚拟环境

```bash
# 创建干净的 Python 3.11 虚拟环境
python3.11 -m venv forgex_env
source forgex_env/bin/activate

# 升级基础工具
pip install --upgrade pip setuptools wheel
```

---

## 第 1 步: 安装 PyTorch (cu128 — Blackwell 必需)

**这是最关键的一步，必须第一个安装，且必须使用 cu128 构建。**

```bash
# 方案 A: 稳定版 + cu128（推荐，如果官方已发布）
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128

# 方案 B: 如果方案 A 报 sm_120 不兼容，改用 nightly
pip install --pre torch torchvision torchaudio --index-url https://download.pytorch.org/whl/nightly/cu128
```

**验证 GPU 是否正确识别:**

```bash
python -c "
import torch
print('PyTorch:', torch.__version__)
print('CUDA available:', torch.cuda.is_available())
if torch.cuda.is_available():
    print('GPU:', torch.cuda.get_device_name(0))
    print('Compute Capability:', torch.cuda.get_device_capability(0))
    # 简单 matmul 测试
    a = torch.randn(1000, 1000, device='cuda')
    b = a @ a
    print('GPU matmul OK:', b.shape)
"
```

> 输出应显示 `Compute Capability: (12, 0)` 且 `CUDA available: True`。
> 如果看到 `sm_120 is not compatible` 警告，说明 PyTorch 版本不对，请换方案 B。

---

## 第 2 步: HuggingFace 核心生态 (transformers + trl + peft)

**安装顺序很重要，先装 transformers 再装 trl，避免版本回滚。**

```bash
# accelerate — 分布式训练 + 混合精度
pip install accelerate

# transformers — 模型加载/训练核心
pip install transformers

# datasets — HuggingFace 数据集加载
pip install datasets

# peft — LoRA / QLoRA 参数高效微调
pip install peft

# trl — SFT / DPO / KTO / ORPO 训练器
pip install trl

# tokenizers — 分词器（通常被 transformers 自动装，确保最新）
pip install tokenizers

# safetensors — 安全的模型权重格式
pip install safetensors

# huggingface-hub — 模型上传下载
pip install huggingface-hub
```

---

## 第 3 步: bitsandbytes (8bit/4bit 量化 — 省显存利器)

```bash
# 方案 A: 直接 pip 安装最新版（大多数情况够用）
pip install bitsandbytes

# 方案 B: 如果方案 A 报 GPU 不支持或 "compiled without GPU support"，从源码编译
pip uninstall bitsandbytes -y
git clone https://github.com/bitsandbytes-foundation/bitsandbytes.git
cd bitsandbytes
cmake -DCOMPUTE_BACKEND=cuda -S .
make
pip install -e .
cd ..
```

**验证:**

```bash
python -c "
import bitsandbytes as bnb
print('bitsandbytes:', bnb.__version__)
p = bnb.optim.PagedAdamW8bit([__import__('torch').nn.Parameter(__import__('torch').zeros(1))], lr=1e-4)
print('PagedAdamW8bit OK')
"
```

---

## 第 4 步: Unsloth (加速微调 — 可选但强烈推荐)

**Unsloth 官方已支持 Blackwell，但安装方式需注意不被自动降级 PyTorch。**

```bash
# 使用 --no-deps 避免 Unsloth 覆盖你已装好的 PyTorch 版本
pip install "unsloth @ git+https://github.com/unslothai/unsloth.git" --no-deps

# 单独安装 Unsloth 的非 PyTorch 依赖
pip install unsloth_zoo --no-deps
pip install xformers --no-deps 2>/dev/null || true   # sm_120 不支持 xformers，装了也不用
pip install triton --no-deps 2>/dev/null || true      # triton 可能在 sm_120 上部分可用
```

> **重要**: ForgeX 的 trainer.py 会在运行时检测 compute_cap >= 10 时自动禁用
> xformers 和 flash_attn，fallback 到 SDPA。所以即使装了也不会出错。

---

## 第 5 步: Gradio (Web UI 框架)

```bash
pip install gradio
```

---

## 第 6 步: 模型导出 & 推理

```bash
# GGUF 格式支持（llama.cpp 生态）
pip install gguf

# llama-cpp-python（本地 GGUF 推理引擎）
# 必须带 CUDA 编译才能用 GPU
CMAKE_ARGS="-DGGML_CUDA=on" pip install llama-cpp-python --force-reinstall --no-cache-dir

# OpenAI 兼容 API 客户端（用于 API 蒸馏等）
pip install openai
```

---

## 第 7 步: 文档处理 (PDF / Word / 数据)

```bash
# PDF 读取
pip install PyMuPDF        # import fitz
pip install pdfplumber     # 表格提取备选方案

# Word 文档读取
pip install python-docx    # import docx

# 数据处理
pip install pandas
pip install numpy

# YAML 配置
pip install PyYAML         # import yaml

# 图像处理
pip install Pillow         # import PIL

# HTTP 请求
pip install requests
```

---

## 第 8 步: 多模态训练 (音频相关 — 可选)

```bash
# 仅在需要多模态训练（音频）时安装
pip install librosa        # 音频特征提取
pip install soundfile      # 音频文件读写

# Linux 系统级依赖（如果 soundfile 报错）
# sudo apt-get install libsndfile1
```

---

## 第 9 步: 最终验证

```bash
python -c "
import sys
print(f'Python: {sys.version}')

# PyTorch + CUDA
import torch
print(f'PyTorch: {torch.__version__}')
print(f'CUDA: {torch.cuda.is_available()} | GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"N/A\"}')
cap = torch.cuda.get_device_capability(0) if torch.cuda.is_available() else (0,0)
print(f'Compute Capability: {cap[0]}.{cap[1]}')

# HuggingFace 生态
import transformers; print(f'transformers: {transformers.__version__}')
import trl; print(f'trl: {trl.__version__}')
import peft; print(f'peft: {peft.__version__}')
import datasets; print(f'datasets: {datasets.__version__}')
import accelerate; print(f'accelerate: {accelerate.__version__}')

# 量化
try:
    import bitsandbytes; print(f'bitsandbytes: {bitsandbytes.__version__}')
except: print('bitsandbytes: NOT INSTALLED')

# Unsloth
try:
    import unsloth; print(f'unsloth: OK')
except: print('unsloth: NOT INSTALLED (optional)')

# 推理 / 导出
import gguf; print(f'gguf: OK')
try:
    import llama_cpp; print(f'llama-cpp-python: OK')
except: print('llama-cpp-python: NOT INSTALLED')

# UI
import gradio; print(f'gradio: {gradio.__version__}')

# 文档处理
import fitz; print(f'PyMuPDF: {fitz.__version__}')
import docx; print(f'python-docx: OK')
import pandas; print(f'pandas: {pandas.__version__}')
import yaml; print(f'PyYAML: OK')

print()
print('✅ All dependencies OK' if torch.cuda.is_available() else '⚠️ CUDA not available!')
"
```

---

## 完整一键安装脚本 (复制即用)

```bash
#!/bin/bash
set -e

echo "=== ForgeX 依赖安装 — RTX 5060 Blackwell (sm_120) ==="

# 0. 虚拟环境
python3.11 -m venv forgex_env && source forgex_env/bin/activate
pip install --upgrade pip setuptools wheel

# 1. PyTorch cu128 (Blackwell 必需)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128

# 2. HuggingFace 核心生态
pip install accelerate
pip install transformers
pip install datasets
pip install peft
pip install trl
pip install tokenizers
pip install safetensors
pip install huggingface-hub

# 3. 量化
pip install bitsandbytes

# 4. Unsloth (不动 PyTorch)
pip install "unsloth @ git+https://github.com/unslothai/unsloth.git" --no-deps
pip install unsloth_zoo --no-deps 2>/dev/null || true

# 5. UI
pip install gradio

# 6. 导出 & 推理
pip install gguf
pip install openai
CMAKE_ARGS="-DGGML_CUDA=on" pip install llama-cpp-python --force-reinstall --no-cache-dir

# 7. 文档 & 数据处理
pip install PyMuPDF pdfplumber python-docx
pip install pandas numpy Pillow PyYAML requests

# 8. 多模态 (可选)
pip install librosa soundfile

echo "=== 安装完成 ==="
```

---

## 已知限制 & 注意事项

| 项目 | 状态 | 说明 |
|:-----|:-----|:-----|
| flash-attn | ❌ 不支持 sm_120 | ForgeX 自动 fallback 到 SDPA，无需安装 |
| xformers | ❌ 不支持 sm_120 | ForgeX 自动禁用，即使安装了也会被跳过 |
| triton | ⚠️ 部分支持 | torch.compile 可能用到，非必需 |
| PyTorch 稳定版 | ⚠️ 取决于版本 | cu128 构建才支持 sm_120，cu124 不行 |
| bitsandbytes | ✅ 最新版支持 | 如果 pip 版有问题就从源码编译 |
| Unsloth | ✅ 官方已支持 | 必须 --no-deps 防止降级 PyTorch |
| Gradio | ✅ 无 GPU 依赖 | 任何版本都行 |
| bf16 训练 | ✅ 支持 | Blackwell compute_cap >= 8，bf16 可用 |
| fp8 训练 | ✅ 原生支持 | Blackwell 的独特优势，通过 Unsloth 使用 |

---

## 故障排除

**问题: `sm_120 is not compatible with the current PyTorch installation`**
→ 你的 PyTorch 不是 cu128 构建。卸载后重装:
```bash
pip uninstall torch torchvision torchaudio -y
pip install --pre torch torchvision torchaudio --index-url https://download.pytorch.org/whl/nightly/cu128
```

**问题: `bitsandbytes compiled without GPU support`**
→ 从源码编译 bitsandbytes（见第 3 步方案 B）

**问题: `CUDA error: no kernel image is available`**
→ 同上，PyTorch 缺少 sm_120 内核。必须用 cu128 构建。

**问题: Unsloth 安装后 PyTorch 被降级到旧版**
→ 检查 `pip list | grep torch`，如果版本变了，重新执行第 1 步，然后用 `--no-deps` 重装 Unsloth

**问题: `llama-cpp-python` GPU 推理不工作**
→ 确认编译时带了 CUDA: `CMAKE_ARGS="-DGGML_CUDA=on" pip install llama-cpp-python --force-reinstall --no-cache-dir`
