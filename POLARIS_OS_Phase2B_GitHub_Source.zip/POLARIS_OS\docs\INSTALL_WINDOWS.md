# Windows Install Guide

Recommended environment:

- Windows 10/11
- Python 3.11
- NVIDIA GPU with recent driver
- CUDA-capable PyTorch installed through `requirements.txt`

## Install

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt -c constraints.txt
python selfcheck.py
python main.py
```

If port 7860 is already occupied, POLARIS OS will choose another local port.

## Launch

```powershell
.\run.bat
```

or:

```bash
bash run.sh
```

## Local Data Folders

```text
data/datasets/      training datasets
data/loras/         LoRA outputs and checkpoints
data/models_cache/  local model cache
data/logs/          runtime logs
```

These folders are intentionally empty in the GitHub package.
