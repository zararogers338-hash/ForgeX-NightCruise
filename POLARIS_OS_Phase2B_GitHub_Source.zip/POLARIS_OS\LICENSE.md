# License Notice

Copyright (c) 2026. All rights reserved unless the repository owner replaces this file with an explicit open-source license.

This package is provided as a source distribution draft for POLARIS OS / 北极星. No permission is granted by this file to redistribute, sublicense, sell, or host model weights, datasets, LoRA outputs, GGUF files, or third-party assets.

Before publishing this repository publicly, choose and replace this notice with the license you actually intend to use.
