using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace PolarisOS
{
    internal static class LauncherProgram
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LauncherForm());
        }
    }

    public sealed class LauncherForm : Form
    {
        private readonly Label statusLabel;
        private readonly Label urlLabel;
        private readonly TextBox logBox;
        private readonly ProgressBar progress;
        private readonly Button startButton;
        private readonly Button openButton;
        private readonly Button stopButton;
        private readonly Button killOldButton;
        private readonly Button healthButton;

        private Process serviceProcess;
        private string sourceDir;
        private string venvPython;
        private string currentUrl;
        private string logFile;
        private int selectedPort = 7860;
        private readonly List<int> occupiedPids = new List<int>();

        public LauncherForm()
        {
            Text = "北极星 POLARIS OS 启动器";
            Width = 760;
            Height = 560;
            MinimumSize = new Size(700, 480);
            StartPosition = FormStartPosition.CenterScreen;

            var root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.RowCount = 4;
            root.ColumnCount = 1;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
            Controls.Add(root);

            var header = new Panel();
            header.Dock = DockStyle.Fill;
            header.BackColor = Color.FromArgb(245, 248, 250);
            root.Controls.Add(header, 0, 0);

            var title = new Label();
            title.Text = "北极星 POLARIS OS";
            title.Font = new Font(Font.FontFamily, 18, FontStyle.Bold);
            title.AutoSize = true;
            title.Location = new Point(18, 14);
            header.Controls.Add(title);

            statusLabel = new Label();
            statusLabel.Text = "准备启动本地 AI Studio...";
            statusLabel.AutoSize = true;
            statusLabel.Location = new Point(20, 52);
            header.Controls.Add(statusLabel);

            urlLabel = new Label();
            urlLabel.Dock = DockStyle.Fill;
            urlLabel.TextAlign = ContentAlignment.MiddleLeft;
            urlLabel.Padding = new Padding(20, 0, 0, 0);
            root.Controls.Add(urlLabel, 0, 1);

            logBox = new TextBox();
            logBox.Dock = DockStyle.Fill;
            logBox.Multiline = true;
            logBox.ScrollBars = ScrollBars.Both;
            logBox.ReadOnly = true;
            logBox.Font = new Font("Consolas", 9);
            root.Controls.Add(logBox, 0, 2);

            var footer = new TableLayoutPanel();
            footer.Dock = DockStyle.Fill;
            footer.ColumnCount = 6;
            footer.Padding = new Padding(12, 10, 12, 10);
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            root.Controls.Add(footer, 0, 3);

            progress = new ProgressBar();
            progress.Dock = DockStyle.Fill;
            progress.Style = ProgressBarStyle.Marquee;
            footer.Controls.Add(progress, 0, 0);

            startButton = MakeButton("启动");
            openButton = MakeButton("打开");
            stopButton = MakeButton("停止");
            healthButton = MakeButton("自检");
            killOldButton = MakeButton("结束旧进程");
            footer.Controls.Add(startButton, 1, 0);
            footer.Controls.Add(openButton, 2, 0);
            footer.Controls.Add(stopButton, 3, 0);
            footer.Controls.Add(killOldButton, 4, 0);
            footer.Controls.Add(healthButton, 5, 0);

            startButton.Click += delegate { StartService(); };
            openButton.Click += delegate { OpenCurrentUrl(); };
            stopButton.Click += delegate { StopService(); };
            killOldButton.Click += delegate { KillOldPolarisProcesses(); };
            healthButton.Click += delegate { RunHealthcheck(); };

            openButton.Enabled = false;
            stopButton.Enabled = false;
            killOldButton.Enabled = false;
            Shown += delegate { StartService(); };
            FormClosing += OnClosing;
        }

        private Button MakeButton(string text)
        {
            var button = new Button();
            button.Text = text;
            button.Dock = DockStyle.Fill;
            button.Margin = new Padding(6, 0, 0, 0);
            return button;
        }

        private void StartService()
        {
            if (serviceProcess != null && !serviceProcess.HasExited)
            {
                AppendLog("服务已经在运行。");
                return;
            }

            try
            {
                sourceDir = FindSourceDir();
                venvPython = FindVenvPython(sourceDir);
                if (String.IsNullOrEmpty(venvPython) || !File.Exists(venvPython))
                {
                    Fail("未找到虚拟环境 Python。请先运行安装器完成依赖安装。");
                    return;
                }

                KillOldPolarisProcesses();
                selectedPort = PickPortWithFallback("127.0.0.1", 7860);
                currentUrl = "http://127.0.0.1:" + selectedPort + "/";
                logFile = Path.Combine(GetLogsDir(), "launcher_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".log");
                Directory.CreateDirectory(Path.GetDirectoryName(logFile));

                AppendLog("源码目录: " + sourceDir);
                AppendLog("Python: " + venvPython);
                AppendLog("日志文件: " + logFile);
                AppendLog("本地地址: " + currentUrl);

                var psi = new ProcessStartInfo();
                psi.FileName = venvPython;
                psi.Arguments = Quote(Path.Combine(sourceDir, "main.py"));
                psi.WorkingDirectory = sourceDir;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                psi.StandardOutputEncoding = Encoding.UTF8;
                psi.StandardErrorEncoding = Encoding.UTF8;
                psi.EnvironmentVariables["POLARIS_OS_SERVER_HOST"] = "127.0.0.1";
                psi.EnvironmentVariables["POLARIS_OS_SERVER_PORT"] = selectedPort.ToString();
                psi.EnvironmentVariables["FORGEX_SERVER_HOST"] = "127.0.0.1";
                psi.EnvironmentVariables["FORGEX_SERVER_PORT"] = selectedPort.ToString();
                psi.EnvironmentVariables["FORGEX_SHARE"] = "false";
                psi.EnvironmentVariables["POLARIS_OS_OPEN_BROWSER"] = "0";
                psi.EnvironmentVariables["PYTHONUTF8"] = "1";
                psi.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";
                ApplyStateEnvironment(psi);

                serviceProcess = new Process();
                serviceProcess.StartInfo = psi;
                serviceProcess.EnableRaisingEvents = true;
                serviceProcess.OutputDataReceived += OnProcessOutput;
                serviceProcess.ErrorDataReceived += OnProcessOutput;
                serviceProcess.Exited += delegate
                {
                    Ui(delegate
                    {
                        progress.Style = ProgressBarStyle.Blocks;
                        statusLabel.Text = "服务已退出，退出码: " + serviceProcess.ExitCode;
                        stopButton.Enabled = false;
                        startButton.Enabled = true;
                    });
                };
                serviceProcess.Start();
                serviceProcess.BeginOutputReadLine();
                serviceProcess.BeginErrorReadLine();

                statusLabel.Text = "正在启动服务...";
                startButton.Enabled = false;
                stopButton.Enabled = true;
                openButton.Enabled = false;
                progress.Style = ProgressBarStyle.Marquee;

                var waiter = new Thread(delegate()
                {
                    if (WaitForHttp(currentUrl, 180))
                    {
                        Ui(delegate
                        {
                            statusLabel.Text = "服务已启动";
                            urlLabel.Text = currentUrl;
                            openButton.Enabled = true;
                            progress.Style = ProgressBarStyle.Blocks;
                            progress.Value = 100;
                        });
                        OpenCurrentUrl();
                    }
                    else
                    {
                        Ui(delegate
                        {
                            statusLabel.Text = "服务未按时响应，请查看日志";
                            progress.Style = ProgressBarStyle.Blocks;
                        });
                    }
                });
                waiter.IsBackground = true;
                waiter.Start();
            }
            catch (Exception ex)
            {
                Fail(FriendlyError(ex));
            }
        }

        private void OnProcessOutput(object sender, DataReceivedEventArgs e)
        {
            if (e.Data == null) return;
            AppendLog(e.Data);
            try
            {
                File.AppendAllText(logFile, e.Data + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }

        private int PickPortWithFallback(string host, int start)
        {
            occupiedPids.Clear();
            if (CanBind(host, start))
            {
                return start;
            }
            occupiedPids.AddRange(GetPidsOnPort(start));
            if (occupiedPids.Count > 0)
            {
                AppendLog("端口 " + start + " 已被占用，PID: " + String.Join(", ", occupiedPids));
                killOldButton.Enabled = true;
            }
            for (int p = start + 1; p < start + 100; p++)
            {
                if (CanBind(host, p))
                {
                    AppendLog("自动切换到空闲端口: " + p);
                    return p;
                }
            }
            throw new Exception("未找到可用端口。");
        }

        private bool CanBind(string host, int port)
        {
            try
            {
                IPAddress ip = host == "127.0.0.1" ? IPAddress.Loopback : IPAddress.Any;
                var listener = new TcpListener(ip, port);
                listener.Start();
                listener.Stop();
                return true;
            }
            catch
            {
                return false;
            }
        }

        private List<int> GetPidsOnPort(int port)
        {
            var pids = new List<int>();
            try
            {
                string output = RunCapture("netstat", "-ano");
                string needle = ":" + port.ToString();
                string[] lines = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string line in lines)
                {
                    string[] parts = Regex.Split(line.Trim(), "\\s+");
                    if (parts.Length >= 5 && parts[1].IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        int pid;
                        if (Int32.TryParse(parts[parts.Length - 1], out pid) && !pids.Contains(pid))
                        {
                            pids.Add(pid);
                        }
                    }
                }
            }
            catch { }
            return pids;
        }

        private void KillOldPolarisProcesses()
        {
            if (String.IsNullOrEmpty(sourceDir))
            {
                try { sourceDir = FindSourceDir(); } catch { }
            }
            var pids = FindPolarisPids();
            foreach (int pid in pids)
            {
                try
                {
                    Process proc = Process.GetProcessById(pid);
                    AppendLog("结束旧 POLARIS 进程 PID=" + pid);
                    proc.Kill();
                }
                catch (Exception ex)
                {
                    AppendLog("无法结束 PID=" + pid + ": " + ex.Message);
                }
            }
            killOldButton.Enabled = false;
        }

        private List<int> FindPolarisPids()
        {
            var pids = new List<int>();
            try
            {
                string output = RunCapture("wmic", "process where \"CommandLine like '%main.py%'\" get ProcessId,CommandLine /format:list");
                string[] blocks = output.Split(new[] { "\r\r\n\r\r\n", "\r\n\r\n", "\n\n" }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string block in blocks)
                {
                    if (block.IndexOf("main.py", StringComparison.OrdinalIgnoreCase) < 0) continue;
                    if (!String.IsNullOrEmpty(sourceDir) && block.IndexOf(sourceDir, StringComparison.OrdinalIgnoreCase) < 0) continue;
                    Match m = Regex.Match(block, @"ProcessId=(\d+)");
                    if (m.Success)
                    {
                        int pid = Int32.Parse(m.Groups[1].Value);
                        if (serviceProcess != null && serviceProcess.Id == pid) continue;
                        if (!pids.Contains(pid)) pids.Add(pid);
                    }
                }
            }
            catch { }
            return pids;
        }

        private void RunHealthcheck()
        {
            try
            {
                if (String.IsNullOrEmpty(sourceDir)) sourceDir = FindSourceDir();
                if (String.IsNullOrEmpty(venvPython)) venvPython = FindVenvPython(sourceDir);
                string health = Path.Combine(sourceDir, "scripts", "healthcheck.py");
                if (!File.Exists(health))
                {
                    AppendLog("未找到 healthcheck.py");
                    return;
                }
                AppendLog("运行自检...");
                var thread = new Thread(delegate()
                {
                    string args = Quote(health) + " --project-dir " + Quote(sourceDir);
                    if (!String.IsNullOrEmpty(currentUrl))
                    {
                        args += " --service-url " + Quote(currentUrl);
                    }
                    string output = RunCapture(venvPython, args);
                    AppendLog(output);
                });
                thread.IsBackground = true;
                thread.Start();
            }
            catch (Exception ex)
            {
                AppendLog(FriendlyError(ex));
            }
        }

        private bool WaitForHttp(string url, int seconds)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(seconds);
            while (DateTime.UtcNow < deadline)
            {
                try
                {
                    if (serviceProcess != null && serviceProcess.HasExited) return false;
                    var request = (HttpWebRequest)WebRequest.Create(url);
                    request.Timeout = 2500;
                    using (var response = (HttpWebResponse)request.GetResponse())
                    {
                        int code = (int)response.StatusCode;
                        if (code >= 200 && code < 500) return true;
                    }
                }
                catch
                {
                    Thread.Sleep(1000);
                }
            }
            return false;
        }

        private void OpenCurrentUrl()
        {
            if (String.IsNullOrEmpty(currentUrl)) return;
            try
            {
                Process.Start(new ProcessStartInfo(currentUrl) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                AppendLog("无法打开浏览器: " + ex.Message);
            }
        }

        private void StopService()
        {
            try
            {
                if (serviceProcess != null && !serviceProcess.HasExited)
                {
                    AppendLog("正在停止服务...");
                    serviceProcess.Kill();
                    serviceProcess.WaitForExit(8000);
                }
            }
            catch (Exception ex)
            {
                AppendLog("停止失败: " + ex.Message);
            }
            finally
            {
                stopButton.Enabled = false;
                startButton.Enabled = true;
                statusLabel.Text = "服务已停止";
            }
        }

        private void OnClosing(object sender, FormClosingEventArgs e)
        {
            StopService();
        }

        private string FindSourceDir()
        {
            string exeDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            string[] candidates = new string[]
            {
                exeDir,
                Directory.GetParent(exeDir) == null ? exeDir : Directory.GetParent(exeDir).FullName,
                Path.Combine(exeDir, "POLARIS_OS_Source"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "POLARIS OS")
            };
            foreach (string dir in candidates)
            {
                if (!String.IsNullOrEmpty(dir) && File.Exists(Path.Combine(dir, "main.py")))
                {
                    return Path.GetFullPath(dir);
                }
            }
            throw new Exception("未找到 POLARIS OS 源码目录。请把启动器放在源码根目录或 launcher 子目录下。");
        }

        private string FindVenvPython(string dir)
        {
            string statePy = ReadStateValue(Path.Combine(dir, "data", "install_state.json"), "venv_python");
            if (!String.IsNullOrEmpty(statePy) && File.Exists(statePy)) return statePy;
            string py = Path.Combine(dir, ".venv", "Scripts", "python.exe");
            if (File.Exists(py)) return py;
            return "";
        }

        private void ApplyStateEnvironment(ProcessStartInfo psi)
        {
            string state = Path.Combine(sourceDir, "data", "install_state.json");
            string models = ReadStateValue(state, "models_cache");
            string logs = ReadStateValue(state, "logs");
            string cache = ReadStateValue(state, "hf_cache");
            string backend = ReadStateValue(state, "backend");
            if (!String.IsNullOrEmpty(models)) psi.EnvironmentVariables["POLARIS_OS_MODELS_CACHE_DIR"] = models;
            if (!String.IsNullOrEmpty(logs)) psi.EnvironmentVariables["POLARIS_OS_LOGS_DIR"] = logs;
            if (!String.IsNullOrEmpty(cache))
            {
                psi.EnvironmentVariables["HF_HOME"] = cache;
                psi.EnvironmentVariables["TRANSFORMERS_CACHE"] = cache;
            }
            if (backend == "cpu") psi.EnvironmentVariables["CUDA_VISIBLE_DEVICES"] = "-1";
        }

        private string GetLogsDir()
        {
            string logs = ReadStateValue(Path.Combine(sourceDir, "data", "install_state.json"), "logs");
            if (!String.IsNullOrEmpty(logs)) return logs;
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "POLARIS OS", "logs");
        }

        private string ReadStateValue(string stateFile, string key)
        {
            try
            {
                if (!File.Exists(stateFile)) return "";
                string text = File.ReadAllText(stateFile, Encoding.UTF8);
                Match m = Regex.Match(text, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"([^\"]*)\"");
                if (!m.Success) return "";
                return Regex.Unescape(m.Groups[1].Value.Replace("\\\\", "\\"));
            }
            catch
            {
                return "";
            }
        }

        private string RunCapture(string file, string args)
        {
            var psi = new ProcessStartInfo();
            psi.FileName = file;
            psi.Arguments = args;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;
            var proc = Process.Start(psi);
            string output = proc.StandardOutput.ReadToEnd() + proc.StandardError.ReadToEnd();
            proc.WaitForExit(15000);
            return output;
        }

        private string FriendlyError(Exception ex)
        {
            string msg = ex.Message;
            if (msg.IndexOf("venv", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("Python", StringComparison.OrdinalIgnoreCase) >= 0)
                return "环境未就绪: " + msg + Environment.NewLine + "请先运行 POLARIS_OS_Setup.exe 完成 Python 和依赖安装。";
            if (msg.IndexOf("port", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("端口", StringComparison.OrdinalIgnoreCase) >= 0)
                return "端口不可用: " + msg + Environment.NewLine + "可以点击“结束旧进程”或稍后重试。";
            return "启动失败: " + msg;
        }

        private void Fail(string message)
        {
            AppendLog(message);
            statusLabel.Text = "启动失败";
            progress.Style = ProgressBarStyle.Blocks;
            startButton.Enabled = true;
            stopButton.Enabled = false;
            MessageBox.Show(message, "POLARIS OS", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void AppendLog(string text)
        {
            Ui(delegate
            {
                logBox.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + text + Environment.NewLine);
            });
        }

        private void Ui(MethodInvoker invoker)
        {
            if (IsDisposed) return;
            if (InvokeRequired)
            {
                try { BeginInvoke(invoker); } catch { }
            }
            else
            {
                invoker();
            }
        }

        private string Quote(string value)
        {
            return "\"" + value.Replace("\"", "\\\"") + "\"";
        }
    }
}
