"""Tiny SFT regression for ForgeX.

Runs a 2-step CPU LoRA train on sshleifer/tiny-gpt2 with a local Alpaca
fixture, then validates completion-only metadata and expected artifacts.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path


os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")


ROOT = Path(__file__).resolve().parent
DATASET_PATH = ROOT / "data" / "datasets" / "smoke_train_tiny_alpaca.jsonl"


FIXTURE = [
    {"instruction": "Name one color in the sky.", "input": "", "output": "Blue."},
    {"instruction": "Turn this into a short answer.", "input": "A cat is sleeping.", "output": "A cat sleeps."},
    {"instruction": "Add two numbers.", "input": "2 + 3", "output": "5."},
    {"instruction": "Classify the sentiment.", "input": "This is helpful.", "output": "Positive."},
    {"instruction": "Write a tiny greeting.", "input": "", "output": "Hello."},
    {"instruction": "Give one fruit.", "input": "", "output": "Apple."},
    {"instruction": "Complete the phrase.", "input": "Good", "output": "morning."},
    {"instruction": "Answer yes or no.", "input": "Is water wet?", "output": "Yes."},
]


def _write_fixture() -> None:
    DATASET_PATH.parent.mkdir(parents=True, exist_ok=True)
    DATASET_PATH.write_text(
        "\n".join(json.dumps(row, ensure_ascii=False) for row in FIXTURE) + "\n",
        encoding="utf-8",
    )


def _assert_file(path: Path) -> None:
    if not path.exists():
        raise AssertionError(f"missing expected file: {path}")


def main() -> int:
    _write_fixture()

    from core import LORAS_DIR
    from core.trainer import Trainer

    output_name = f"smoke_train_tiny_{time.strftime('%Y%m%d_%H%M%S')}"
    params = {
        "output_name": output_name,
        "max_steps": 2,
        "epochs": 1,
        "batch_size": 1,
        "gradient_accumulation_steps": 1,
        "max_seq_len": 128,
        "lr": 5e-4,
        "rank": 4,
        "alpha": 8,
        "target_modules": ["c_attn"],
        "use_qlora": False,
        "use_unsloth": False,
        "use_packing": True,
        "auto_clean": False,
        "label_smoothing": 0.0,
        "neftune_noise_alpha": 0.0,
        "save_steps": 2,
        "logging_steps": 1,
        "report_to": "none",
        "fp16": False,
        "bf16": False,
    }

    base_model = os.environ.get("FORGEX_TINY_MODEL", "sshleifer/tiny-gpt2")
    result = Path(Trainer().train(
        method="sft",
        backend="hf",
        base_model=base_model,
        dataset_path=str(DATASET_PATH),
        params=params,
    ))
    out_dir = Path(result) if result.exists() else Path(LORAS_DIR) / output_name

    _assert_file(out_dir / "adapter_config.json")
    _assert_file(out_dir / "adapter_model.safetensors")
    _assert_file(out_dir / "checkpoint-2" / "trainer_state.json")
    _assert_file(out_dir / "forgex_meta.json")

    state = json.loads((out_dir / "checkpoint-2" / "trainer_state.json").read_text(encoding="utf-8"))
    if int(state.get("global_step", -1)) != 2:
        raise AssertionError(f"expected global_step == 2, got {state.get('global_step')}")

    meta = json.loads((out_dir / "forgex_meta.json").read_text(encoding="utf-8"))
    if meta.get("completion_only") is not True:
        raise AssertionError(f"expected completion_only true, got {meta.get('completion_only')}")
    if meta.get("effective_use_packing") is not False:
        raise AssertionError(f"expected effective_use_packing false, got {meta.get('effective_use_packing')}")
    if int(meta.get("dataset_size", 0)) <= 0:
        raise AssertionError(f"invalid dataset_size: {meta.get('dataset_size')}")
    if meta.get("final_loss") is None:
        raise AssertionError("final_loss was not recorded")

    print(f"OK tiny train: {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
