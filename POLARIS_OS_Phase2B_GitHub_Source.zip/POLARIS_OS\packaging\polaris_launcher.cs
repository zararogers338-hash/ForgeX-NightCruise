using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace PolarisOSLauncher
{
    internal static class Program
    {
        private const string ProductName = "北极星 POLARIS OS";

        private static int Main(string[] args)
        {
            Process child = null;
            try
            {
                string exeDir = AppDomain.CurrentDomain.BaseDirectory;
                string sourceDir = FindSourceDir(exeDir);
                if (sourceDir == null)
                {
                    Console.Error.WriteLine(ProductName + " source folder was not found.");
                    Console.Error.WriteLine("Place POLARIS_OS_Source next to POLARIS_OS_Portable.exe, or extract POLARIS_OS_Source.zip first.");
                    Console.ReadKey();
                    return 2;
                }

                int port = PickFreePort();
                string url = "http://127.0.0.1:" + port + "/";
                Console.Title = ProductName;
                Console.WriteLine(ProductName);
                Console.WriteLine("Starting local UI at " + url);
                Console.WriteLine("Close this window to stop the background service.");

                var psi = new ProcessStartInfo
                {
                    FileName = "py",
                    Arguments = "-3.11 main.py",
                    WorkingDirectory = sourceDir,
                    UseShellExecute = false,
                    CreateNoWindow = false,
                };
                psi.EnvironmentVariables["FORGEX_SERVER_HOST"] = "127.0.0.1";
                psi.EnvironmentVariables["FORGEX_SERVER_PORT"] = port.ToString();
                psi.EnvironmentVariables["FORGEX_SHARE"] = "false";
                child = Process.Start(psi);

                if (!WaitForHttp(url, 90))
                {
                    Console.Error.WriteLine("The local UI did not become reachable in time.");
                    return 3;
                }

                if (Environment.GetEnvironmentVariable("POLARIS_OS_NO_BROWSER") != "1")
                {
                    Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
                }
                while (child != null && !child.HasExited)
                {
                    Thread.Sleep(1000);
                }
                return child == null ? 0 : child.ExitCode;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ProductName + " failed to start:");
                Console.Error.WriteLine(ex.Message);
                Console.WriteLine("Press any key to close.");
                Console.ReadKey();
                return 1;
            }
            finally
            {
                try
                {
                    if (child != null && !child.HasExited)
                    {
                        child.Kill();
                    }
                }
                catch { }
            }
        }

        private static string FindSourceDir(string exeDir)
        {
            string[] candidates =
            {
                Path.Combine(exeDir, "POLARIS_OS_Source"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PolarisOS", "source"),
                exeDir
            };
            foreach (string dir in candidates)
            {
                if (File.Exists(Path.Combine(dir, "main.py")))
                {
                    return dir;
                }
            }
            return null;
        }

        private static int PickFreePort()
        {
            var listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Start();
            int port = ((IPEndPoint)listener.LocalEndpoint).Port;
            listener.Stop();
            return port;
        }

        private static bool WaitForHttp(string url, int seconds)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(seconds);
            while (DateTime.UtcNow < deadline)
            {
                try
                {
                    var request = (HttpWebRequest)WebRequest.Create(url);
                    request.Timeout = 3000;
                    using (var response = (HttpWebResponse)request.GetResponse())
                    {
                        if ((int)response.StatusCode >= 200 && (int)response.StatusCode < 500)
                        {
                            return true;
                        }
                    }
                }
                catch
                {
                    Thread.Sleep(1000);
                }
            }
            return false;
        }
    }
}
