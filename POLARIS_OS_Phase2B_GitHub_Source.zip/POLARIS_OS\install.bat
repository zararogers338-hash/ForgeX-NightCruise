cd /d %~dp0
@echo off
chcp 65001 >nul
title 北极星 POLARIS OS Installer
echo ================================================
echo   北极星 POLARIS OS - 安装依赖
echo ================================================
echo.

set HF_ENDPOINT=https://hf-mirror.com

py -3.11 --version >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] 未找到 Python 3.11。请先安装 Python 3.11。
    pause
    exit /b 1
)

py -3.11 -m pip install --upgrade pip
py -3.11 -m pip install -r requirements.txt -c constraints.txt

echo.
echo ================================================
echo   安装完成！运行 run.bat 启动
echo ================================================
pause
