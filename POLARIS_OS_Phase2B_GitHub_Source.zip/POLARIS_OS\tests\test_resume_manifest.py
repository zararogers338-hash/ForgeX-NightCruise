from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.resume import compare_resume_params, list_resumable_runs, validate_resume_sources
from core.run_manifest import (
    create_or_update_manifest,
    heartbeat,
    latest_checkpoint,
    load_manifest,
    manifest_path,
    mark_failed,
)


class ResumeManifestTests(unittest.TestCase):
    def test_manifest_lifecycle_and_scan(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            out_dir = root / "demo_lora"
            ckpt = out_dir / "checkpoint-12"
            ckpt.mkdir(parents=True)
            (ckpt / "trainer_state.json").write_text("{}", encoding="utf-8")

            data = create_or_update_manifest(
                out_dir,
                base_model="Qwen/Qwen2.5-0.5B",
                dataset_list=[root / "train.jsonl"],
                method="sft",
                training_params={"output_name": "demo_lora", "lr": 2e-4, "save_steps": 12},
                status="training",
                task_id="task_1",
            )

            self.assertEqual(data["schema_version"], 1)
            self.assertEqual(data["status"], "training")
            self.assertTrue(manifest_path(out_dir).exists())
            self.assertEqual(Path(latest_checkpoint(out_dir)).name, "checkpoint-12")

            heartbeat(manifest_path(out_dir), checkpoint=str(ckpt), step=12, metrics={"loss": 0.5})
            updated = load_manifest(out_dir)
            self.assertEqual(updated["last_step"], 12)
            self.assertEqual(updated["last_metrics"]["loss"], 0.5)

            runs = list_resumable_runs(root)
            self.assertEqual(len(runs), 1)
            self.assertEqual(runs[0]["output_name"], "demo_lora")
            self.assertEqual(runs[0]["checkpoint_name"], "checkpoint-12")

            mark_failed(out_dir, "boom")
            failed = load_manifest(out_dir)
            self.assertEqual(failed["status"], "failed")
            self.assertEqual(failed["error_message"], "boom")

    def test_resume_validation_reports_missing_local_inputs(self):
        errors = validate_resume_sources(
            str(Path("Z:/missing/local/model")),
            [str(Path("Z:/missing/data.jsonl"))],
        )
        self.assertTrue(any("基座模型路径不存在" in x for x in errors))
        self.assertTrue(any("数据集不存在" in x for x in errors))

    def test_resume_param_mismatch_ignores_epochs_but_checks_core_keys(self):
        original = {"lr": 2e-4, "batch_size": 1, "epochs": 1}
        candidate = {"lr": 1e-4, "batch_size": 1, "epochs": 2}
        mismatches = compare_resume_params(original, candidate)
        self.assertEqual(mismatches, ["lr: 0.0002 != 0.0001"])


if __name__ == "__main__":
    unittest.main()
