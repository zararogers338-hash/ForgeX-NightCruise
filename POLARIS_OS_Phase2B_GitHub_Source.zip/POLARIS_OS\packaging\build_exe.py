"""Build the POLARIS OS portable launcher.

This builder prefers a native C# launcher when PyInstaller is unavailable.  The
launcher intentionally stays small: it starts the source tree next to it with
``py -3.11 main.py`` and opens the local Gradio URL.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
LAUNCHER_SOURCE = ROOT / "packaging" / "polaris_launcher.cs"


def find_csc() -> Path | None:
    found = shutil.which("csc.exe") or shutil.which("csc")
    if found:
        return Path(found)
    for base in (
        Path(r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319"),
        Path(r"C:\Windows\Microsoft.NET\Framework\v4.0.30319"),
    ):
        csc = base / "csc.exe"
        if csc.exists():
            return csc
    return None


def build_csharp_launcher(output: Path) -> Path:
    csc = find_csc()
    if not csc:
        raise RuntimeError("csc.exe not found; install .NET Framework build tools or PyInstaller.")
    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(csc),
        "/nologo",
        "/target:exe",
        f"/out:{output}",
        str(LAUNCHER_SOURCE),
    ]
    subprocess.check_call(cmd, cwd=str(ROOT))
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(ROOT / "dist" / "POLARIS_OS_Portable.exe"))
    args = parser.parse_args()
    out = build_csharp_launcher(Path(args.output).resolve())
    print(f"built {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
