"""Run manifest helpers for resumable training.

Each training output directory owns one ``run_manifest.json`` file.  The
manifest is intentionally plain JSON so it remains useful after a crash or a
power loss, before any Python state can be reconstructed.
"""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


MANIFEST_FILENAME = "run_manifest.json"
SCHEMA_VERSION = 1

FINAL_STATUSES = {"completed"}
RECOVERABLE_STATUSES = {
    "queued",
    "training",
    "running",
    "resuming",
    "interrupted",
    "failed",
    "cancelled",
}


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def manifest_path(output_dir: str | Path) -> Path:
    return Path(output_dir) / MANIFEST_FILENAME


def new_run_id() -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"run_{stamp}_{uuid.uuid4().hex[:8]}"


def _jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items() if not str(k).startswith("_")}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def normalize_dataset_list(dataset_paths: Any) -> List[str]:
    if dataset_paths is None:
        return []
    if isinstance(dataset_paths, (str, Path)):
        items: Iterable[Any] = [dataset_paths]
    else:
        items = dataset_paths
    return [str(Path(x)) for x in items if str(x or "").strip()]


def latest_checkpoint(output_dir: str | Path) -> str:
    root = Path(output_dir)
    if not root.exists():
        return ""

    def _step(p: Path) -> int:
        try:
            return int(p.name.rsplit("-", 1)[-1])
        except Exception:
            return -1

    candidates = []
    for d in root.glob("checkpoint-*"):
        if not d.is_dir():
            continue
        if (
            (d / "trainer_state.json").exists()
            or (d / "optimizer.pt").exists()
            or (d / "model.safetensors").exists()
            or (d / "adapter_model.safetensors").exists()
        ):
            candidates.append(d)
    candidates.sort(key=lambda p: (_step(p), p.stat().st_mtime))
    return str(candidates[-1]) if candidates else ""


def checkpoint_strategy_from_params(params: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "save_steps": int(params.get("save_steps", 500) or 500),
        "save_total_limit": int(params.get("save_total_limit", 2) or 2),
        "resume_from_checkpoint": str(params.get("resume_from_checkpoint") or ""),
    }


def load_manifest(path_or_output_dir: str | Path) -> Dict[str, Any]:
    path = Path(path_or_output_dir)
    if path.is_dir():
        path = manifest_path(path)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_manifest(path_or_output_dir: str | Path, data: Dict[str, Any]) -> Path:
    path = Path(path_or_output_dir)
    if path.suffix.lower() != ".json":
        path = manifest_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(_jsonable(data), indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)
    return path


def create_or_update_manifest(
    output_dir: str | Path,
    *,
    base_model: str,
    dataset_list: Any,
    method: str,
    training_params: Dict[str, Any],
    seed: Optional[int] = None,
    status: str = "training",
    task_id: str = "",
) -> Dict[str, Any]:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = manifest_path(out_dir)
    existing = load_manifest(path)
    started_at = existing.get("start_time") or now_iso()
    resume_checkpoint = str(training_params.get("resume_from_checkpoint") or "")
    run_id = existing.get("run_id") or new_run_id()
    latest = resume_checkpoint or existing.get("last_checkpoint") or latest_checkpoint(out_dir)

    data = {
        **existing,
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "base_model": str(base_model or existing.get("base_model", "")),
        "dataset_list": normalize_dataset_list(dataset_list),
        "output_dir": str(out_dir),
        "method": str(method or existing.get("method") or "sft").lower(),
        "training_params": _jsonable(training_params or {}),
        "seed": int(seed if seed is not None else training_params.get("seed", existing.get("seed", 42) or 42)),
        "checkpoint_strategy": checkpoint_strategy_from_params(training_params or {}),
        "start_time": started_at,
        "last_heartbeat": now_iso(),
        "status": status,
        "last_checkpoint": latest,
        "error_message": "" if status in {"training", "resuming", "queued"} else existing.get("error_message", ""),
        "task_id": str(task_id or existing.get("task_id", "")),
        "resume_count": int(existing.get("resume_count", 0)) + (1 if resume_checkpoint and existing else 0),
    }
    save_manifest(path, data)
    return data


def update_manifest(path_or_output_dir: str | Path, **updates: Any) -> Dict[str, Any]:
    data = load_manifest(path_or_output_dir)
    if not data:
        return {}
    data.update({k: _jsonable(v) for k, v in updates.items()})
    data["last_heartbeat"] = updates.get("last_heartbeat", data.get("last_heartbeat") or now_iso())
    save_manifest(path_or_output_dir, data)
    return data


def heartbeat(
    path_or_output_dir: str | Path,
    *,
    status: str = "training",
    checkpoint: str = "",
    step: Optional[int] = None,
    metrics: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    updates: Dict[str, Any] = {"status": status, "last_heartbeat": now_iso()}
    if checkpoint:
        updates["last_checkpoint"] = str(checkpoint)
    if step is not None:
        updates["last_step"] = int(step)
    if metrics:
        updates["last_metrics"] = _jsonable(metrics)
    return update_manifest(path_or_output_dir, **updates)


def mark_completed(path_or_output_dir: str | Path, result: Any = "") -> Dict[str, Any]:
    data = load_manifest(path_or_output_dir)
    out_dir = data.get("output_dir") if data else path_or_output_dir
    checkpoint = latest_checkpoint(out_dir)
    return update_manifest(
        path_or_output_dir,
        status="completed",
        finished_time=now_iso(),
        last_checkpoint=checkpoint or data.get("last_checkpoint", ""),
        result=str(result or ""),
        error_message="",
    )


def mark_failed(path_or_output_dir: str | Path, error: Any, *, status: str = "failed") -> Dict[str, Any]:
    data = load_manifest(path_or_output_dir)
    out_dir = data.get("output_dir") if data else path_or_output_dir
    checkpoint = latest_checkpoint(out_dir)
    return update_manifest(
        path_or_output_dir,
        status=status,
        finished_time=now_iso(),
        last_checkpoint=checkpoint or data.get("last_checkpoint", ""),
        error_message=str(error or ""),
    )


def manifest_is_recoverable(data: Dict[str, Any]) -> bool:
    status = str(data.get("status") or "").lower()
    checkpoint = str(data.get("last_checkpoint") or "")
    return bool(checkpoint) and status not in FINAL_STATUSES


def heartbeat_age_seconds(data: Dict[str, Any]) -> Optional[float]:
    raw = data.get("last_heartbeat")
    if not raw:
        return None
    try:
        dt = datetime.fromisoformat(str(raw))
        return max(0.0, time.time() - dt.timestamp())
    except Exception:
        return None
