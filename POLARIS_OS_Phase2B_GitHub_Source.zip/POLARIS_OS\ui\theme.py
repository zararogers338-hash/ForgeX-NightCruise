from __future__ import annotations

import gradio as gr


APP_THEME = gr.themes.Soft(
    primary_hue=gr.themes.colors.blue,
    secondary_hue=gr.themes.colors.teal,
    neutral_hue=gr.themes.colors.gray,
)


APP_JS = r"""
() => {
  const root = document.documentElement;
  const mq = window.matchMedia("(prefers-color-scheme: dark)");
  const preferredKey = "polaris-theme-mode";

  function storedMode() {
    return localStorage.getItem(preferredKey) || "Light";
  }

  function apply(mode) {
    const selected = mode || storedMode();
    const dark = selected === "Dark" || (selected === "Auto" && mq.matches);
    root.classList.toggle("dark", dark);
    root.dataset.themeMode = selected;
    document.body?.classList.toggle("dark", dark);
    document.body?.classList.add("polaris-local-studio");
  }

  window.polarisApplyTheme = (mode) => {
    const selected = mode || "Light";
    localStorage.setItem(preferredKey, selected);
    apply(selected);
    return selected;
  };

  window.forgexApplyTheme = window.polarisApplyTheme;
  mq.addEventListener?.("change", () => apply());
  apply();
}
"""


THEME_CHANGE_JS = r"""
(mode) => {
  if (window.polarisApplyTheme) {
    return window.polarisApplyTheme(mode || "Light");
  }
  localStorage.setItem("polaris-theme-mode", mode || "Light");
  const dark = mode === "Dark" || (mode === "Auto" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
  document.body?.classList.toggle("dark", dark);
  document.documentElement.dataset.themeMode = mode || "Light";
  return mode || "Light";
}
"""


APP_CSS = r"""
:root {
  color-scheme: light;
  --fx-bg: #f7f8fb;
  --fx-bg-elevated: #ffffff;
  --fx-surface: #ffffff;
  --fx-surface-muted: #f1f3f6;
  --fx-surface-hover: #eef3fb;
  --fx-border: #d9dee7;
  --fx-border-strong: #c3c9d4;
  --fx-text: #202124;
  --fx-text-soft: #3f4652;
  --fx-text-muted: #697386;
  --fx-primary: #1a73e8;
  --fx-primary-hover: #155fc0;
  --fx-primary-soft: #e8f0fe;
  --fx-accent: #0f766e;
  --fx-accent-soft: #e3f4f1;
  --fx-success: #188038;
  --fx-success-soft: #e6f4ea;
  --fx-warning: #b06000;
  --fx-warning-soft: #fff4df;
  --fx-danger: #d93025;
  --fx-danger-soft: #fce8e6;
  --fx-radius: 8px;
  --fx-radius-sm: 6px;
  --fx-control-h: 40px;
  --fx-gap: 12px;
  --fx-shadow: 0 1px 2px rgba(15, 23, 42, .06);
  --fx-shadow-lift: 0 8px 24px rgba(60, 64, 67, .08);
  --fx-font: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans CJK SC", Arial, sans-serif;
  --fx-mono: "SFMono-Regular", Consolas, "Liberation Mono", "Microsoft YaHei Mono", monospace;
}

:root.dark,
html.dark,
body.dark {
  color-scheme: dark;
  --fx-bg: #111317;
  --fx-bg-elevated: #171a20;
  --fx-surface: #191c22;
  --fx-surface-muted: #22262e;
  --fx-surface-hover: #252b34;
  --fx-border: #333944;
  --fx-border-strong: #46505d;
  --fx-text: #eef1f5;
  --fx-text-soft: #d7dde6;
  --fx-text-muted: #a2acba;
  --fx-primary: #8ab4f8;
  --fx-primary-hover: #aecbfa;
  --fx-primary-soft: #24334d;
  --fx-accent: #63c7bd;
  --fx-accent-soft: #183934;
  --fx-success: #81c995;
  --fx-success-soft: #1f3527;
  --fx-warning: #fdd663;
  --fx-warning-soft: #3a2d12;
  --fx-danger: #f28b82;
  --fx-danger-soft: #3d211f;
  --fx-shadow: 0 1px 2px rgba(0, 0, 0, .28);
  --fx-shadow-lift: 0 12px 28px rgba(0, 0, 0, .26);
}

@media (prefers-color-scheme: dark) {
  :root[data-theme-mode="Auto"] {
    color-scheme: dark;
    --fx-bg: #111317;
    --fx-bg-elevated: #171a20;
    --fx-surface: #191c22;
    --fx-surface-muted: #22262e;
    --fx-surface-hover: #252b34;
    --fx-border: #333944;
    --fx-border-strong: #46505d;
    --fx-text: #eef1f5;
    --fx-text-soft: #d7dde6;
    --fx-text-muted: #a2acba;
    --fx-primary: #8ab4f8;
    --fx-primary-hover: #aecbfa;
    --fx-primary-soft: #24334d;
    --fx-accent: #63c7bd;
    --fx-accent-soft: #183934;
    --fx-success: #81c995;
    --fx-success-soft: #1f3527;
    --fx-warning: #fdd663;
    --fx-warning-soft: #3a2d12;
    --fx-danger: #f28b82;
    --fx-danger-soft: #3d211f;
    --fx-shadow: 0 1px 2px rgba(0, 0, 0, .28);
    --fx-shadow-lift: 0 12px 28px rgba(0, 0, 0, .26);
  }
}

html,
body {
  width: 100%;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  scrollbar-gutter: stable;
  background: var(--fx-bg) !important;
  color: var(--fx-text) !important;
  font-family: var(--fx-font) !important;
  font-size: 14px;
}

* {
  box-sizing: border-box;
  letter-spacing: 0 !important;
}

footer,
.built-with,
[data-testid="built-with"] {
  display: none !important;
}

.gradio-container {
  width: 100% !important;
  max-width: none !important;
  min-height: 100vh !important;
  margin: 0 !important;
  padding: 0 22px 32px !important;
  background: var(--fx-bg) !important;
  color: var(--fx-text) !important;
  font-family: var(--fx-font) !important;
}

.app,
.contain,
.main,
main {
  width: 100% !important;
  max-width: none !important;
  background: var(--fx-bg) !important;
}

.fx-topbar {
  position: sticky;
  top: 0;
  z-index: 50;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  gap: 14px !important;
  min-height: 58px;
  margin: 0 -22px 14px !important;
  padding: 10px 22px !important;
  border-bottom: 1px solid var(--fx-border);
  background: color-mix(in srgb, var(--fx-bg-elevated) 92%, transparent);
  backdrop-filter: blur(10px);
  overflow: hidden;
  flex-wrap: nowrap !important;
}

.fx-titlebar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex: 1 1 auto;
  width: auto;
  min-width: 0;
  gap: 16px;
  flex-wrap: nowrap;
}

.fx-topbar > div:first-child {
  flex: 1 1 0 !important;
  width: auto !important;
  min-width: 0 !important;
}

.fx-brand {
  display: flex;
  align-items: center;
  min-width: 180px;
  gap: 10px;
}

.fx-brand-mark {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border: 1px solid var(--fx-border-strong);
  border-radius: 8px;
  background: var(--fx-surface);
  color: var(--fx-primary);
  font-weight: 750;
  line-height: 1;
}

.fx-topbar-title {
  color: var(--fx-text);
  font-size: .96rem;
  font-weight: 720;
  line-height: 1.15;
}

.fx-topbar-sub {
  color: var(--fx-text-muted);
  font-size: .78rem;
  line-height: 1.2;
}

.fx-statusline {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex-wrap: nowrap;
  gap: 8px;
  flex: 1 1 auto;
  min-width: 0;
}

.fx-status-badge,
.fx-badge,
.fx-step,
.fx-lane-chip {
  display: inline-flex;
  align-items: center;
  min-height: 28px;
  max-width: 100%;
  padding: 4px 9px;
  border: 1px solid var(--fx-border);
  border-radius: 999px;
  background: var(--fx-surface-muted);
  color: var(--fx-text-muted);
  font-size: .8rem;
  font-weight: 560;
  line-height: 1.25;
  white-space: nowrap;
}

.fx-status-badge strong {
  color: var(--fx-text);
  font-weight: 650;
}

.fx-status-badge.ok {
  border-color: color-mix(in srgb, var(--fx-success) 28%, var(--fx-border));
  background: var(--fx-success-soft);
  color: var(--fx-success);
}

.fx-status-badge.accent {
  border-color: color-mix(in srgb, var(--fx-accent) 30%, var(--fx-border));
  background: var(--fx-accent-soft);
  color: var(--fx-accent);
}

.fx-topbar .gr-radio,
.fx-theme-toggle {
  width: min(236px, 100%) !important;
  margin-left: auto;
  flex: 0 1 236px;
}

.fx-theme-toggle .wrap,
.fx-theme-toggle fieldset,
.fx-theme-toggle label {
  min-height: 32px !important;
}

.fx-theme-toggle .wrap,
.fx-theme-toggle fieldset {
  display: flex !important;
  gap: 3px !important;
  padding: 3px !important;
  border: 1px solid var(--fx-border) !important;
  border-radius: var(--fx-radius-sm) !important;
  background: var(--fx-surface-muted) !important;
}

.fx-theme-toggle label {
  justify-content: center !important;
  flex: 1 1 0 !important;
  min-width: 0 !important;
  padding: 0 8px !important;
  border: 0 !important;
  border-radius: 5px !important;
  background: transparent !important;
  color: var(--fx-text-muted) !important;
  font-size: .8rem !important;
  font-weight: 650 !important;
}

.fx-theme-toggle input {
  display: none !important;
}

.fx-theme-toggle label:has(input:checked) {
  background: var(--fx-surface) !important;
  color: var(--fx-primary) !important;
  box-shadow: var(--fx-shadow) !important;
}

.fx-shell {
  display: grid;
  grid-template-columns: minmax(0, 1.25fr) minmax(260px, .75fr);
  gap: 18px;
  align-items: stretch;
  padding: 18px 18px 16px;
  margin: 4px 0 14px;
  border: 1px solid var(--fx-border);
  border-radius: var(--fx-radius);
  background: var(--fx-surface);
  box-shadow: var(--fx-shadow);
  color: var(--fx-text);
}

.fx-shell h1 {
  margin: 0;
  color: var(--fx-text);
  font-size: 1.38rem;
  line-height: 1.18;
}

.fx-shell-kicker,
.fx-overview-kicker,
.fx-cta-kicker,
.fx-composer-kicker,
.fx-fixed-kicker,
.fx-mini-title {
  color: var(--fx-text-muted);
  font-size: .74rem;
  font-weight: 700;
  line-height: 1.25;
  text-transform: uppercase;
}

.fx-shell-main,
.fx-shell-side {
  min-width: 0;
}

.fx-sub,
.fx-section-desc,
.fx-dock-note,
.fx-grid-note,
.fx-overview-list,
.fx-cta-list,
.forgex-muted {
  color: var(--fx-text-muted) !important;
  line-height: 1.52;
}

.fx-sub {
  max-width: 980px;
  margin-top: 7px;
}

.fx-steps,
.fx-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
  margin: 12px 0 0;
}

.fx-step {
  border-radius: var(--fx-radius-sm);
  background: var(--fx-surface);
}

.fx-step-active {
  color: var(--fx-primary);
  border-color: color-mix(in srgb, var(--fx-primary) 38%, var(--fx-border));
  background: var(--fx-primary-soft);
}

.fx-badge {
  color: var(--fx-text-soft);
  background: var(--fx-bg);
}

.fx-shell-meter {
  display: grid;
  gap: 8px;
}

.fx-shell-meter-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 8px 10px;
  border: 1px solid var(--fx-border);
  border-radius: var(--fx-radius-sm);
  background: var(--fx-bg);
  color: var(--fx-text-soft);
  font-size: .85rem;
}

.fx-shell-meter-row b {
  color: var(--fx-text);
  font-weight: 650;
}

.fx-section,
.forgex-tip,
.fx-panel,
.fx-form-shell,
.fx-dock,
.fx-mini-card,
.fx-preview-card,
.fx-lane-card,
.fx-cta-card,
.fx-fixed-card,
.fx-overview-card,
.fx-composer-step,
.fx-composer-summary,
.fx-export-panel {
  border: 1px solid var(--fx-border) !important;
  border-radius: var(--fx-radius) !important;
  background: var(--fx-surface) !important;
  box-shadow: var(--fx-shadow) !important;
  color: var(--fx-text) !important;
}

.forgex-tip,
.fx-panel,
.fx-section,
.fx-form-shell,
.fx-dock,
.fx-export-panel {
  padding: 12px 14px;
  margin: 8px 0 14px;
}

.forgex-tip {
  border-color: color-mix(in srgb, var(--fx-primary) 18%, var(--fx-border)) !important;
  background: color-mix(in srgb, var(--fx-primary-soft) 48%, var(--fx-surface)) !important;
}

.fx-section {
  margin-top: 4px;
}

.fx-section-title,
.fx-dock-title,
.fx-overview-title,
.fx-cta-title,
.fx-composer-title {
  color: var(--fx-text);
  font-size: 1rem;
  font-weight: 720;
  line-height: 1.25;
  margin-bottom: 5px;
}

.fx-overview-grid,
.fx-lane-grid,
.fx-fixed-grid,
.fx-composer-grid,
.fx-cta-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin: 10px 0 16px;
}

.fx-lane-grid {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.fx-cta-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.fx-composer-grid {
  grid-template-columns: minmax(0, 1.05fr) minmax(0, 1.05fr) minmax(0, .95fr);
}

.fx-overview-card,
.fx-lane-card,
.fx-cta-card,
.fx-fixed-card,
.fx-composer-step,
.fx-composer-summary,
.fx-mini-card {
  min-width: 0;
  padding: 14px;
}

.fx-cta-card.primary {
  border-color: color-mix(in srgb, var(--fx-accent) 32%, var(--fx-border)) !important;
  background: color-mix(in srgb, var(--fx-accent-soft) 56%, var(--fx-surface)) !important;
}

.fx-overview-metrics {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
}

.fx-overview-metrics span {
  display: block;
  min-width: 0;
  padding: 9px 10px;
  border: 1px solid var(--fx-border);
  border-radius: var(--fx-radius-sm);
  background: var(--fx-bg);
}

.fx-overview-metrics b {
  display: block;
  color: var(--fx-text);
  font-size: 1.06rem;
  font-weight: 730;
}

.fx-overview-metrics small {
  color: var(--fx-text-muted);
}

.fx-builder-grid {
  display: grid !important;
  grid-template-columns: minmax(220px, 260px) minmax(0, 1.6fr) minmax(260px, 330px);
  gap: 14px !important;
  align-items: start !important;
}

.fx-builder-col {
  min-width: 0 !important;
}

.fx-stepnav {
  display: grid;
  gap: 6px;
  margin-top: 10px;
}

.fx-stepnav span,
.fx-checklist {
  color: var(--fx-text-muted);
  line-height: 1.45;
}

.fx-property-note,
.fx-neuron-note,
.fx-grid-note {
  margin: 8px 0 12px;
  padding: 10px 12px;
  border: 1px solid var(--fx-border);
  border-radius: var(--fx-radius-sm);
  background: var(--fx-bg);
  color: var(--fx-text-muted);
}

.tabs {
  width: 100%;
  gap: 8px;
}

.tab-nav,
[role="tablist"] {
  display: flex !important;
  align-items: center;
  gap: 6px !important;
  overflow-x: auto !important;
  padding: 4px 0 8px !important;
  border-bottom: 1px solid var(--fx-border) !important;
}

.tab-nav button,
[role="tab"] {
  min-height: 36px !important;
  border: 1px solid transparent !important;
  border-radius: var(--fx-radius-sm) !important;
  background: transparent !important;
  color: var(--fx-text-muted) !important;
  font-weight: 620 !important;
  white-space: nowrap !important;
}

.tab-nav button:hover,
[role="tab"]:hover {
  background: var(--fx-surface-hover) !important;
  color: var(--fx-text) !important;
}

.tab-nav button.selected,
.tab-nav button[aria-selected="true"],
[role="tab"][aria-selected="true"] {
  border-color: var(--fx-border) !important;
  background: var(--fx-surface) !important;
  color: var(--fx-primary) !important;
  box-shadow: var(--fx-shadow) !important;
}

.tab-nav button:focus,
[role="tab"]:focus {
  outline: 2px solid color-mix(in srgb, var(--fx-primary) 18%, transparent) !important;
  outline-offset: 1px !important;
  box-shadow: var(--fx-shadow) !important;
}

.gradio-container .gr-row,
.gradio-container .gap {
  gap: var(--fx-gap) !important;
}

.gradio-container .gr-form,
.gradio-container .gr-box,
.gradio-container .gr-group,
.gradio-container .gr-panel,
.gradio-container .gr-column,
.gradio-container .gr-block,
.gradio-container .block,
.gradio-container .form,
.gradio-container .panel,
.gradio-container .group,
.gradio-container .column,
.gradio-container [data-testid="block-info"] {
  min-width: 0 !important;
  max-width: 100% !important;
}

.gradio-container .block,
.gradio-container .form,
.gradio-container .panel,
.gradio-container .group,
.gradio-container .input-container,
.gradio-container .wrap {
  border-color: var(--fx-border) !important;
  border-radius: var(--fx-radius-sm) !important;
  background: var(--fx-surface) !important;
  color: var(--fx-text) !important;
}

.gradio-container .block,
.gradio-container .form,
.gradio-container .panel,
.gradio-container .group,
.gradio-container .wrap,
.gradio-container .input-container {
  overflow-x: clip !important;
}

.gradio-container .table-wrap,
.gradio-container .dataframe,
.gradio-container .styler {
  overflow-x: auto !important;
}

.gradio-container input,
.gradio-container textarea,
.gradio-container select {
  min-height: var(--fx-control-h) !important;
  border-color: var(--fx-border) !important;
  border-radius: var(--fx-radius-sm) !important;
  background: var(--fx-surface) !important;
  color: var(--fx-text) !important;
  font-family: var(--fx-font) !important;
  font-size: .92rem !important;
  line-height: 1.35 !important;
  max-width: 100% !important;
}

.gradio-container textarea {
  overflow-x: hidden !important;
  white-space: pre-wrap !important;
  overflow-wrap: anywhere !important;
}

.gradio-container input:focus,
.gradio-container textarea:focus,
.gradio-container select:focus {
  border-color: color-mix(in srgb, var(--fx-primary) 62%, var(--fx-border)) !important;
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--fx-primary) 14%, transparent) !important;
  outline: none !important;
}

.gradio-container ::placeholder {
  color: var(--fx-text-muted) !important;
  opacity: .76;
}

.gradio-container label,
.gradio-container .info,
.gradio-container .label-wrap,
.gradio-container .block label,
.gradio-container .block .info,
.gradio-container .block .secondary-wrap {
  color: var(--fx-text-muted) !important;
  font-size: .82rem !important;
  line-height: 1.35 !important;
}

.gradio-container .prose,
.gradio-container .markdown,
.gradio-container [data-testid="markdown"],
.gradio-container p,
.gradio-container span,
.gradio-container small {
  color: inherit !important;
}

.gradio-container h1,
.gradio-container h2,
.gradio-container h3,
.gradio-container h4 {
  color: var(--fx-text) !important;
  letter-spacing: 0 !important;
}

.gradio-container h3 {
  margin-top: 10px !important;
  font-size: 1.05rem !important;
}

.gradio-container hr {
  border-color: var(--fx-border) !important;
}

button,
.gr-button,
.gradio-container button {
  min-height: var(--fx-control-h) !important;
  max-width: 100% !important;
  border: 1px solid var(--fx-border) !important;
  border-radius: var(--fx-radius-sm) !important;
  background: var(--fx-surface) !important;
  color: var(--fx-text-soft) !important;
  box-shadow: none !important;
  font-weight: 650 !important;
  line-height: 1.2 !important;
  white-space: normal !important;
  overflow-wrap: anywhere !important;
  transition: background .14s ease, border-color .14s ease, color .14s ease, box-shadow .14s ease;
}

button:hover,
.gr-button:hover,
.gradio-container button:hover {
  border-color: var(--fx-border-strong) !important;
  background: var(--fx-surface-hover) !important;
  color: var(--fx-text) !important;
}

button.primary,
.gr-button-primary,
.gradio-container button.primary {
  border-color: var(--fx-primary) !important;
  background: var(--fx-primary) !important;
  color: #ffffff !important;
}

button.primary:hover,
.gr-button-primary:hover,
.gradio-container button.primary:hover {
  border-color: var(--fx-primary-hover) !important;
  background: var(--fx-primary-hover) !important;
  color: #ffffff !important;
}

button.secondary,
.gr-button-secondary,
.gradio-container button.secondary {
  background: var(--fx-surface) !important;
  color: var(--fx-text-soft) !important;
}

button.stop,
.gradio-container button.stop,
.gr-button-stop {
  border-color: color-mix(in srgb, var(--fx-danger) 38%, var(--fx-border)) !important;
  background: var(--fx-danger-soft) !important;
  color: var(--fx-danger) !important;
}

button.stop:hover,
.gradio-container button.stop:hover,
.gr-button-stop:hover {
  border-color: var(--fx-danger) !important;
  background: color-mix(in srgb, var(--fx-danger-soft) 70%, var(--fx-surface)) !important;
}

.fx-eq-row,
.fx-dock-grid,
.fx-action-btn,
.fx-neuron-toolbar {
  align-items: end !important;
}

.fx-eq-row > div,
.fx-eq-row > .gr-column,
.fx-eq-row > .gr-block {
  min-width: 0 !important;
  flex: 1 1 220px !important;
}

.fx-eq-row button,
.fx-eq-row .gr-button,
.fx-action-btn button,
.fx-action-btn .gr-button {
  width: 100% !important;
  min-width: 0 !important;
}

.gradio-container .table-wrap,
.gradio-container .dataframe,
.gradio-container .styler,
.gradio-container table,
.gradio-container thead,
.gradio-container tbody,
.gradio-container tr,
.gradio-container th,
.gradio-container td {
  border-color: var(--fx-border) !important;
  background: var(--fx-surface) !important;
  color: var(--fx-text) !important;
}

.gradio-container th {
  background: var(--fx-surface-muted) !important;
  color: var(--fx-text-soft) !important;
  font-weight: 700 !important;
}

.gradio-container tbody tr:hover td {
  background: var(--fx-surface-hover) !important;
}

.gradio-container code,
.fx-panel code,
.fx-section code,
.fx-shell code {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.fx-log-console textarea,
.fx-status-console textarea {
  border-color: var(--fx-border-strong) !important;
  background: #f4f6f8 !important;
  color: #1f2937 !important;
  font-family: var(--fx-mono) !important;
  font-size: .86rem !important;
  line-height: 1.5 !important;
}

html.dark .fx-log-console textarea,
html.dark .fx-status-console textarea {
  background: #171b21 !important;
  color: #d8dee9 !important;
}

.fx-compact-tabs > .tab-nav,
.fx-compact-tabs [role="tablist"] {
  overflow-x: auto;
}

@media (max-width: 1180px) {
  .fx-shell,
  .fx-builder-grid,
  .fx-overview-grid,
  .fx-lane-grid,
  .fx-fixed-grid,
  .fx-composer-grid,
  .fx-cta-grid {
    grid-template-columns: 1fr !important;
  }

  .fx-overview-metrics {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 720px) {
  .gradio-container {
    padding: 0 10px 22px !important;
  }

  .fx-topbar {
    margin: 0 -10px 10px !important;
    padding: 10px !important;
    position: sticky;
    min-height: auto;
    overflow: visible;
    flex-wrap: wrap !important;
  }

  .fx-titlebar,
  .fx-topbar {
    align-items: stretch !important;
    flex-direction: column !important;
  }

  .fx-topbar > div:first-child {
    flex: 0 0 auto !important;
    width: 100% !important;
  }

  .fx-statusline {
    justify-content: flex-start;
    flex-wrap: wrap;
  }

  .fx-topbar .gr-radio,
  .fx-theme-toggle {
    width: 100% !important;
    margin-left: 0 !important;
    flex-basis: auto !important;
  }

  .fx-shell {
    padding: 14px;
  }

  .fx-shell h1 {
    font-size: 1.18rem;
  }

  .fx-step,
  .fx-badge,
  .fx-status-badge {
    width: 100%;
    justify-content: flex-start;
    white-space: normal;
  }

  .fx-overview-metrics {
    grid-template-columns: 1fr;
  }

  button,
  .gr-button,
  .gradio-container button {
    min-height: 42px !important;
  }
}
"""
