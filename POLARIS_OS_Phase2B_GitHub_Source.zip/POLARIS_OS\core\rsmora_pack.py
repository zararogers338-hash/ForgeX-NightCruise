from __future__ import annotations

import json
import os
import re
import shutil
import textwrap
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.config import PROJECT_DIR
from core.logger import log
from core.neuron_system import (
    _extract_model_name_from_label,
    detect_model_kind,
    list_configs as list_neuron_configs,
    load_config as load_neuron_config,
    resolve_model_ref,
)

PACKS_DIR = PROJECT_DIR / "data" / "runtime_packs"
PACKS_DIR.mkdir(parents=True, exist_ok=True)

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SIMPLE_SCOPE_ALIAS_BY_OLD = {
    "01_forgex_runtime": "academic",
    "02_forgex_runtime": "legal",
    "03_forgex_runtime": "medical",
    "04_forgex_runtime": "coding",
}
SIMPLE_SCOPE_FALLBACKS = ["academic", "legal", "medical", "coding"]

_MODEL_IGNORE = shutil.ignore_patterns(
    "__pycache__",
    "*.pyc",
    "*.pyo",
    "*.tmp",
    "*.log",
    ".ipynb_checkpoints",
    "trainer_state.json",
    "optimizer.pt",
    "scheduler.pt",
    "rng_state.pth",
    "events.out.tfevents*",
    "checkpoint-*",
)


def _slugify(name: str) -> str:
    clean = re.sub(r"[^0-9a-zA-Z._-]+", "_", str(name or "").strip())
    clean = clean.strip("._-")
    return clean or "forgex_runtime"


def _safe_name_from_model(model_ref: str) -> str:
    if not model_ref:
        return "model"
    clean = _extract_model_name_from_label(model_ref)
    clean = Path(clean).name if ("/" in clean or "\\" in clean) else clean.split("/")[-1]
    return _slugify(clean)


def _guess_base_model_from_config(config) -> str:
    if not config:
        return ""
    return str(getattr(config, "base_model", "") or "")


def _is_local_dir(ref: str) -> bool:
    try:
        p = Path(ref)
        return bool(ref) and p.exists() and p.is_dir()
    except Exception:
        return False


def _copy_tree(src: str | Path, dst: str | Path):
    src_p, dst_p = Path(src), Path(dst)
    if dst_p.exists():
        shutil.rmtree(dst_p)
    shutil.copytree(src_p, dst_p, ignore=_MODEL_IGNORE)


def _copy_file_if_exists(src: str | Path, dst: str | Path):
    src_p, dst_p = Path(src), Path(dst)
    if src_p.exists():
        dst_p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_p, dst_p)


def _task_log(task, progress: Optional[float], message: str):
    try:
        if task is not None:
            task.update_progress(float(progress or 0), message)
    except Exception:
        pass
    try:
        log(message)
    except Exception:
        pass


def _count_model_weight_files(path: str | Path) -> int:
    p = Path(path)
    if not p.exists() or not p.is_dir():
        return 0
    total = 0
    for pat in ("*.safetensors", "pytorch_model*.bin", "*.gguf", "adapter_model*.safetensors", "adapter_model*.bin"):
        total += len(list(p.glob(pat)))
    return total


def _has_tokenizer_assets(path: str | Path) -> bool:
    p = Path(path)
    if not p.exists() or not p.is_dir():
        return False
    for name in ("tokenizer.model", "tokenizer.json", "tokenizer_config.json", "vocab.json", "merges.txt"):
        if (p / name).exists():
            return True
    return False


def _validate_model_bundle(path: str | Path, kind: str) -> Tuple[bool, str]:
    p = Path(path)
    if not p.exists() or not p.is_dir():
        return False, f"目录不存在: {p}"
    weights = _count_model_weight_files(p)
    if kind == "full":
        if not (p / "config.json").exists():
            return False, f"缺少 config.json: {p}"
        if weights <= 0:
            return False, f"未发现模型权重文件: {p}"
        if not _has_tokenizer_assets(p):
            return False, f"未发现 tokenizer 相关文件: {p}"
        return True, ""
    if kind == "lora":
        if not (p / "adapter_config.json").exists():
            return False, f"缺少 adapter_config.json: {p}"
        if weights <= 0:
            return False, f"未发现 LoRA 权重文件: {p}"
        return True, ""
    if kind == "residual":
        if not (p / "residual_meta.json").exists():
            return False, f"缺少 residual_meta.json: {p}"
        residual_files = list(p.glob("residual*.safetensors"))
        if not residual_files and not (p / "residual.safetensors.index.json").exists():
            return False, f"未发现 residual 权重文件: {p}"
        return True, ""
    return weights > 0, "" if weights > 0 else f"未发现可用资产: {p}"


def _verify_pack_integrity(pack_dir: Path, manifest: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    assets = manifest.get("package_assets", {}) or {}
    bundled = bool(assets.get("bundle_assets"))

    base = manifest.get("base_model", {}) or {}
    base_ref = str(base.get("ref", "") or "")
    base_kind = str(base.get("kind", "") or "")
    if bundled:
        if not base_ref or "://" in base_ref:
            issues.append("主模型引用为空或非法")
        elif not Path(pack_dir / base_ref).exists():
            issues.append(f"主模型未实际打包进包内: {base_ref}")
        else:
            ok, reason = _validate_model_bundle(pack_dir / base_ref, base_kind or "full")
            if not ok:
                issues.append(f"主模型打包不完整: {reason}")

    experts = manifest.get("experts", []) or []
    for idx, expert in enumerate(experts, start=1):
        ref = str(expert.get("ref", "") or "")
        kind = str(expert.get("kind", "") or "")
        if bundled and ref and not ref.startswith(("http://", "https://")) and not ref.startswith("/"):
            exp_path = pack_dir / ref
            if not exp_path.exists():
                issues.append(f"专家 {idx} 未实际打包进包内: {expert.get('name', ref)}")
            else:
                ok, reason = _validate_model_bundle(exp_path, kind or "full")
                if not ok:
                    issues.append(f"专家 {idx} 打包不完整: {reason}")

    knowledge = manifest.get("knowledge", {}) or {}
    if knowledge.get("enabled"):
        mode = str(knowledge.get("mode", "") or "").strip().lower()
        if mode == "simple_scoped":
            required = [
                str(knowledge.get("shared_index", "") or "knowledge/common/index.json"),
                str(knowledge.get("base_index", "") or "knowledge/general/index.json"),
            ]
            for idx_file in required:
                if not idx_file or not (pack_dir / idx_file).exists():
                    issues.append(f"知识库已声明 simple_scoped，但缺少索引: {idx_file or '<empty>'}")
        else:
            idx_file = str(knowledge.get("index_file", "") or "")
            if not idx_file or not (pack_dir / idx_file).exists():
                issues.append("知识库已声明启用，但未发现 knowledge_index.json")

    return {"ok": not issues, "issues": issues}


def _profile_summary(profile: Dict[str, Any]) -> Dict[str, Any]:
    if not profile:
        return {}
    return {
        "name": profile.get("name", ""),
        "description": profile.get("description", ""),
        "author": profile.get("author", ""),
        "tags": list(profile.get("tags", []) or []),
        "use_case": profile.get("use_case", ""),
        "parameters": dict(profile.get("parameters", {}) or {}),
    }


def _load_profile_bundle(model_ref: str) -> Tuple[Dict[str, Any], str, List[Dict[str, Any]]]:
    if not _is_local_dir(model_ref):
        return {}, "", []
    try:
        from core.model_editor import load_profile, generate_system_prompt_with_knowledge
    except Exception:
        return {}, "", []

    profile: Dict[str, Any] = {}
    full_prompt = ""
    knowledge_entries: List[Dict[str, Any]] = []
    try:
        profile = load_profile(model_ref) or {}
    except Exception:
        profile = {}
    try:
        full_prompt = generate_system_prompt_with_knowledge(model_ref) or profile.get("system_prompt", "") or ""
    except Exception:
        full_prompt = profile.get("system_prompt", "") or ""

    kb_dir = Path(model_ref) / "knowledge_base"
    if kb_dir.exists():
        for idx_file in sorted(kb_dir.glob("*_index.json")):
            try:
                data = json.loads(idx_file.read_text(encoding="utf-8"))
                doc_name = data.get("doc_name", idx_file.stem)
                for i, chunk in enumerate(data.get("chunks", []) or []):
                    text = str(chunk or "").strip()
                    if text:
                        knowledge_entries.append({"doc": doc_name, "chunk_idx": i, "text": text})
            except Exception:
                continue
    return profile, full_prompt, knowledge_entries


def _bundle_ref(ref: str, pack_dir: Path, rel_dir: str, bundle_assets: bool) -> Tuple[str, bool]:
    if not ref:
        return "", False
    if not bundle_assets or not _is_local_dir(ref):
        return ref, False
    _copy_tree(ref, pack_dir / rel_dir)
    return rel_dir.replace("\\", "/"), True


def _expert_entry_from_neuron(neuron, base_model_ref: str = "") -> Dict[str, Any]:
    expert_ref = ""
    if getattr(neuron, "lora_path", ""):
        expert_ref = str(neuron.lora_path)
    elif getattr(neuron, "model_path", ""):
        expert_ref = str(neuron.model_path)
    resolved = resolve_model_ref(expert_ref) if expert_ref else ""
    kind = detect_model_kind(resolved) if resolved else "missing"
    entry = {
        "name": neuron.name,
        "domain": neuron.domain,
        "description": neuron.description,
        "keywords": list(neuron.keywords or []),
        "priority": int(getattr(neuron, "priority", 5) or 5),
        "enabled": bool(getattr(neuron, "enabled", True)),
        "ref": resolved or expert_ref,
        "kind": kind,
        "base_model_ref": base_model_ref if kind == "lora" else "",
    }
    if kind == "missing" and getattr(neuron, "lora_path", ""):
        entry["kind"] = "lora"
        entry["ref"] = str(neuron.lora_path)
        entry["base_model_ref"] = base_model_ref
    return entry




def _copy_tokenizer_assets(src: str | Path, dst: str | Path):
    src_p, dst_p = Path(src), Path(dst)
    dst_p.mkdir(parents=True, exist_ok=True)
    for name in [
        "tokenizer.model", "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json",
        "added_tokens.json", "vocab.json", "merges.txt", "generation_config.json",
    ]:
        _copy_file_if_exists(src_p / name, dst_p / name)


def _ensure_json_placeholder(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _touch_keep(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text("", encoding="utf-8")


def _copy_tree_if_exists(src: Path, dst: Path) -> None:
    if not src.exists() or not src.is_dir():
        return
    dst.mkdir(parents=True, exist_ok=True)
    for file_path in src.rglob("*"):
        if not file_path.is_file():
            continue
        rel = file_path.relative_to(src)
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file_path, target)


def _expert_scope_from_entry(entry: Dict[str, Any], idx: int) -> str:
    fallback = SIMPLE_SCOPE_FALLBACKS[idx] if idx < len(SIMPLE_SCOPE_FALLBACKS) else f"expert_{idx+1:02d}"
    raw = " ".join(
        str(entry.get(k, "") or "") for k in ("name", "domain", "description")
    ).lower()
    if any(x in raw for x in ("academic", "学术", "paper", "research", "论文", "研究")):
        return "academic"
    if any(x in raw for x in ("legal", "law", "法律", "合同", "诉讼")):
        return "legal"
    if any(x in raw for x in ("medical", "medicine", "医学", "诊断", "治疗")):
        return "medical"
    if any(x in raw for x in ("coding", "code", "program", "代码", "编程", "bug")):
        return "coding"
    return fallback


def _export_knowledge_tree(model_ref: str, pack_dir: Path, expert_scopes: Optional[List[str]] = None) -> Dict[str, Any]:
    expert_scopes = list(expert_scopes or SIMPLE_SCOPE_FALLBACKS)
    knowledge_root = pack_dir / "knowledge"

    # Legacy placeholders retained for backward compatibility.
    for legacy_scope in ("shared", "base"):
        _touch_keep(knowledge_root / legacy_scope / "entries" / ".keep")
        _touch_keep(knowledge_root / legacy_scope / "sources" / ".keep")
        _ensure_json_placeholder(knowledge_root / legacy_scope / "knowledge_index.json", [])
    for old_name in SIMPLE_SCOPE_ALIAS_BY_OLD:
        _touch_keep(knowledge_root / "experts" / old_name / "entries" / ".keep")
        _touch_keep(knowledge_root / "experts" / old_name / "sources" / ".keep")
        _ensure_json_placeholder(knowledge_root / "experts" / old_name / "knowledge_index.json", [])

    # New simplified scoped layout.
    _touch_keep(knowledge_root / "common" / "files" / ".keep")
    _touch_keep(knowledge_root / "general" / "files" / ".keep")
    _ensure_json_placeholder(knowledge_root / "common" / "index.json", [])
    _ensure_json_placeholder(knowledge_root / "general" / "index.json", [])
    for scope in expert_scopes:
        _touch_keep(knowledge_root / "experts" / scope / "files" / ".keep")
        _ensure_json_placeholder(knowledge_root / "experts" / scope / "index.json", [])

    copied_general = 0
    copied_common = 0
    copied_expert = 0
    if _is_local_dir(model_ref):
        model_root = Path(model_ref)
        # Preferred simple layout from source package/model dir.
        _copy_tree_if_exists(model_root / "knowledge" / "common" / "files", knowledge_root / "common" / "files")
        _copy_tree_if_exists(model_root / "knowledge" / "general" / "files", knowledge_root / "general" / "files")
        for scope in expert_scopes:
            _copy_tree_if_exists(model_root / "knowledge" / "experts" / scope / "files", knowledge_root / "experts" / scope / "files")

        # Legacy pack layout -> new layout.
        _copy_tree_if_exists(model_root / "knowledge" / "shared" / "sources", knowledge_root / "common" / "files")
        _copy_tree_if_exists(model_root / "knowledge" / "base" / "sources", knowledge_root / "general" / "files")
        for old_name, scope in SIMPLE_SCOPE_ALIAS_BY_OLD.items():
            if scope in expert_scopes:
                _copy_tree_if_exists(model_root / "knowledge" / "experts" / old_name / "sources", knowledge_root / "experts" / scope / "files")

        # Fallback from bare knowledge_base folder.
        kb_dir = model_root / "knowledge_base"
        if kb_dir.exists():
            _copy_tree_if_exists(kb_dir, knowledge_root / "general" / "files")

        copied_common = len([p for p in (knowledge_root / "common" / "files").rglob("*") if p.is_file() and p.name != ".keep"])
        copied_general = len([p for p in (knowledge_root / "general" / "files").rglob("*") if p.is_file() and p.name != ".keep"])
        copied_expert = sum(
            len([p for p in (knowledge_root / "experts" / scope / "files").rglob("*") if p.is_file() and p.name != ".keep"])
            for scope in expert_scopes
        )

    return {
        "mode": "simple_scoped",
        "shared_index": "knowledge/common/index.json",
        "base_index": "knowledge/general/index.json",
        "shared_sources_dir": "knowledge/common/files",
        "base_sources_dir": "knowledge/general/files",
        "copied_common_files": copied_common,
        "copied_general_files": copied_general,
        "copied_expert_files": copied_expert,
    }


def _copy_runtime_scaffold(pack_dir: Path) -> None:
    for rel_name in [
        "README_KNOWLEDGE_SCOPES.md",
        "README_START.txt",
        "PATCH_NOTES_SIMPLE_LAYOUT_AUTOMATION.txt",
        "PATCH_NOTES_UI_SEARCH_AUTOMATION_LOGS.txt",
    ]:
        _copy_file_if_exists(PACKAGE_ROOT / rel_name, pack_dir / rel_name)

    for rel_name in [
        "tools/rebuild_knowledge.py",
        "tools/rebuild_knowledge_simple.py",
        "tools/migrate_pack_layout.py",
    ]:
        _copy_file_if_exists(PACKAGE_ROOT / rel_name, pack_dir / rel_name)

    if (PACKAGE_ROOT / "automation").exists():
        _copy_tree(PACKAGE_ROOT / "automation", pack_dir / "automation")
    else:
        _touch_keep(pack_dir / "automation" / "workspace" / "inbox" / ".keep")
        _touch_keep(pack_dir / "automation" / "workspace" / "editing" / ".keep")
        _touch_keep(pack_dir / "automation" / "workspace" / "done" / ".keep")
        _touch_keep(pack_dir / "automation" / "logs" / ".keep")
    _touch_keep(pack_dir / "output" / ".keep")




def _safetensors_weight_map(model_dir: str | Path) -> Dict[str, Path]:
    model_dir = Path(model_dir)
    index_path = model_dir / "model.safetensors.index.json"
    mapping: Dict[str, Path] = {}
    try:
        from safetensors import safe_open
    except Exception as e:
        raise RuntimeError(f"Residual 导出需要 safetensors: {e}")
    if index_path.exists():
        data = json.loads(index_path.read_text(encoding="utf-8"))
        for key, rel in dict(data.get("weight_map") or {}).items():
            mapping[str(key)] = model_dir / str(rel)
        return mapping
    files = sorted(model_dir.glob("*.safetensors"))
    for file_path in files:
        with safe_open(str(file_path), framework="pt", device="cpu") as handle:
            for key in handle.keys():
                mapping[str(key)] = file_path
    return mapping


def _build_residual_bundle(base_ref: str, expert_ref: str, dst_dir: Path, *, base_manifest_ref: str = "", task=None) -> Dict[str, Any]:
    import gc as _gc
    import torch
    try:
        from safetensors import safe_open
        from safetensors.torch import save_file
    except Exception as e:
        raise RuntimeError(f"Residual 导出需要 safetensors: {e}")

    base_dir = Path(base_ref)
    expert_dir = Path(expert_ref)
    if not base_dir.exists() or not expert_dir.exists():
        raise RuntimeError("Residual 导出要求 base/expert 都是本地模型目录")
    base_map = _safetensors_weight_map(base_dir)
    expert_map = _safetensors_weight_map(expert_dir)
    if not base_map or not expert_map:
        raise RuntimeError("Residual 导出当前仅支持 safetensors 完整模型目录")
    common_keys = sorted(set(base_map.keys()) & set(expert_map.keys()))
    if not common_keys:
        raise RuntimeError("Residual 导出失败：base 与 expert 没有公共权重键")

    dst_dir.mkdir(parents=True, exist_ok=True)
    processed = 0
    changed = 0
    weight_map: Dict[str, str] = {}
    expert_shards = []
    for key in common_keys:
        shard = expert_map[key]
        if shard not in expert_shards:
            expert_shards.append(shard)

    for shard_idx, expert_shard in enumerate(expert_shards, start=1):
        keys_in_shard = [k for k in common_keys if expert_map[k] == expert_shard]
        by_base: Dict[Path, List[str]] = {}
        for key in keys_in_shard:
            by_base.setdefault(base_map[key], []).append(key)
        out_name = f"residual-{shard_idx:05d}.safetensors"
        out_path = dst_dir / out_name
        delta_tensors: Dict[str, Any] = {}
        with safe_open(str(expert_shard), framework="pt", device="cpu") as expert_handle:
            for base_shard, group_keys in by_base.items():
                with safe_open(str(base_shard), framework="pt", device="cpu") as base_handle:
                    for key in group_keys:
                        exp_tensor = expert_handle.get_tensor(key)
                        base_tensor = base_handle.get_tensor(key)
                        processed += 1
                        if tuple(exp_tensor.shape) != tuple(base_tensor.shape):
                            raise RuntimeError(f"Residual 导出失败，形状不一致: {key} :: {tuple(exp_tensor.shape)} != {tuple(base_tensor.shape)}")
                        if not torch.is_floating_point(exp_tensor):
                            continue
                        if exp_tensor.dtype != base_tensor.dtype:
                            base_tensor = base_tensor.to(dtype=exp_tensor.dtype)
                        if torch.equal(exp_tensor, base_tensor):
                            continue
                        delta = (exp_tensor - base_tensor).contiguous()
                        delta_tensors[key] = delta
                        weight_map[key] = out_name
                        changed += 1
        if delta_tensors:
            save_file(delta_tensors, str(out_path), metadata={"format": "forgex.residual", "base_model_ref": str(base_manifest_ref or base_ref)})
        _gc.collect()
        _task_log(task, None, f"🧮 Residual 差分进度: {shard_idx}/{len(expert_shards)} · {Path(expert_shard).name}")

    if changed <= 0:
        raise RuntimeError("Residual 导出失败：未发现任何可保存的差分权重")

    meta = {
        "format": "forgex.residual",
        "version": 1,
        "base_model_ref": str(base_manifest_ref or base_ref),
        "source_expert": str(expert_ref),
        "processed_tensors": int(processed),
        "changed_tensors": int(changed),
    }
    (dst_dir / "residual_meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    if len(set(weight_map.values())) > 1:
        (dst_dir / "residual.safetensors.index.json").write_text(
            json.dumps({"metadata": {"format": "forgex.residual"}, "weight_map": weight_map}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    _copy_file_if_exists(expert_dir / "config.json", dst_dir / "config.json")
    return meta

def _runtime_server_template() -> str:
    template_path = Path(__file__).with_name("runtime_server_template.py")
    return template_path.read_text(encoding="utf-8")

def _bat_template(default_port: int = 8714) -> str:
    _ = default_port
    return '@echo off\nsetlocal\ncd /d "%~dp0"\nset "PY="\nfor %%P in ("%~dp0.venv\\Scripts\\python.exe" "%~dp0..\\.venv\\Scripts\\python.exe" "%~dp0..\\..\\.venv\\Scripts\\python.exe" "%~dp0..\\..\\..\\.venv\\Scripts\\python.exe") do (\n  if exist %%~P set "PY=%%~P"\n)\nif not defined PY set "PY=python"\necho [ForgeX Runtime Mini] Using Python: %PY%\necho 访问地址: http://127.0.0.1:8714/\n"%PY%" runtime_server.py\nif errorlevel 1 (\n  echo.\n  echo Runtime 启动失败，请检查 manifest.json / runtime_settings.json / 模型目录 / Python 环境。\n  pause\n)\nendlocal\n'

def _sh_template(default_port: int = 8714) -> str:
    _ = default_port
    return '#!/usr/bin/env bash\nset -e\ncd "$(dirname "$0")"\nPY=""\nfor p in \\\n  ".venv/bin/python" \\\n  ".venv/Scripts/python.exe" \\\n  "../.venv/bin/python" \\\n  "../.venv/Scripts/python.exe" \\\n  "../../.venv/bin/python" \\\n  "../../.venv/Scripts/python.exe" \\\n  "../../../.venv/bin/python" \\\n  "../../../.venv/Scripts/python.exe"\ndo\n  if [ -f "$p" ]; then PY="$p"; break; fi\ndone\nif [ -z "$PY" ]; then PY="python3"; fi\necho "[ForgeX Runtime Mini] Using Python: $PY"\necho "访问地址: http://127.0.0.1:8714/"\n"$PY" runtime_server.py\n'

def _zip_dir_with_progress(pack_dir: Path, zip_path: Path, task=None):
    import zipfile
    files = [p for p in pack_dir.rglob("*") if p.is_file()]
    total_files = max(len(files), 1)
    total_bytes = sum((p.stat().st_size for p in files), 0) or 1
    processed = 0
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True, compresslevel=6) as zf:
        for idx, file_path in enumerate(files, start=1):
            rel = file_path.relative_to(pack_dir)
            arcname = str(Path(pack_dir.name) / rel).replace("\\", "/")
            ext = file_path.suffix.lower()
            compress_type = zipfile.ZIP_STORED if ext in {".safetensors", ".bin", ".gguf", ".pt", ".pth", ".model"} else zipfile.ZIP_DEFLATED
            try:
                zf.write(file_path, arcname=arcname, compress_type=compress_type)
            except TypeError:
                zf.write(file_path, arcname=arcname)
            processed += max(file_path.stat().st_size, 0)
            if idx == 1 or idx == total_files or idx % 20 == 0:
                pct = 92 + 7 * (processed / total_bytes)
                _task_log(task, pct, f"🗜️ 压缩 ZIP: {idx}/{total_files} · {rel}")
    if not zip_path.exists() or zip_path.stat().st_size <= 0:
        raise RuntimeError(f"ZIP 生成失败: {zip_path}")

def _readme_text(manifest: Dict[str, Any]) -> str:
    pkg = manifest.get("package_name", "forgex-rsmora")
    port = manifest.get("runtime", {}).get("port", 8714)
    assets = manifest.get("package_assets", {}) or {}
    kb = manifest.get("knowledge", {}) or {}
    return textwrap.dedent(
        f"""
        ForgeX Runtime Pack
        ==================

        包名: {pkg}

        这个目录不是单一 GGUF，而是一个可点击启动的 ForgeX 动态模型包。
        外部软件不需要理解内部结构，只要请求本地 API 即可。

        启动方式
        --------
        Windows: 双击 start_api.bat
        Linux/macOS: 运行 ./start_api.sh

        访问方式
        --------
        本地管理界面: http://127.0.0.1:{port}/
        OpenAI 兼容:   http://127.0.0.1:{port}/v1/chat/completions
        Responses:    http://127.0.0.1:{port}/v1/responses
        Ollama 兼容:  http://127.0.0.1:{port}/api/chat
        文本生成:     http://127.0.0.1:{port}/api/generate
        健康检查:     http://127.0.0.1:{port}/health

        当前包内容
        ----------
        - 已打包主模型文件: {'是' if assets.get('bundled_base_model') else '否'}
        - 已带入内置知识库: {int(kb.get('doc_count', 0) or 0)} 个文档
        - 已写入统一身份提示词 / 系统提示词
        - 已内置一个带流式对话的简易 GUI，可直接测试聊天、查看状态、调 API 参数
        - GUI 可切换 GPU/CPU 偏好，并在 GPU 出错后显示回退状态
        - 专家将按需启用，并通过 API 返回结果
        - 支持 full / LoRA / residual 专家目录格式（residual 需由新版主软件导出）
        """
    ).strip() + "\n"

def create_runtime_pack(
    base_model: str,
    package_name: str,
    neuron_config_name: str = "",
    api_port: int = 8714,
    system_prompt: str = "",
    compression_mode: str = "off",
    use_4bit: bool = False,
    bundle_assets: bool = True,
    include_profile_assets: bool = True,
    include_knowledge: bool = True,
    task=None,
) -> Dict[str, Any]:
    _task_log(task, 1, "🧩 开始准备 ForgeX Runtime 模型包")
    base_resolved = resolve_model_ref(base_model)
    cfg = load_neuron_config(neuron_config_name) if neuron_config_name else None
    if not base_resolved and cfg:
        base_resolved = resolve_model_ref(_guess_base_model_from_config(cfg))
    if not base_resolved:
        raise ValueError("请先提供主模型路径或 HF 模型 ID")

    _task_log(task, 5, f"📁 主模型已解析: {base_resolved}")
    if cfg:
        _task_log(task, 8, f"🧠 已加载神经元/蜂群配置: {neuron_config_name}")
    else:
        _task_log(task, 8, "ℹ️ 未选择神经元/蜂群配置，仅导出主模型 Runtime 包")

    safe_pkg = _slugify(package_name or f"rsmora_{_safe_name_from_model(base_resolved)}")
    pack_dir = PACKS_DIR / f"{safe_pkg}.fxpack"
    zip_path = PACKS_DIR / f"{safe_pkg}.zip"
    if pack_dir.exists():
        _task_log(task, 10, f"♻️ 清理旧包目录: {pack_dir}")
        shutil.rmtree(pack_dir)
    pack_dir.mkdir(parents=True, exist_ok=True)
    _task_log(task, 12, f"📦 创建包目录: {pack_dir}")

    bundled_count = 0
    profile, profile_system, kb_entries = _load_profile_bundle(base_resolved) if include_profile_assets else ({}, "", [])
    if include_profile_assets:
        _task_log(task, 18, f"🪪 已收集模型档案/身份提示词，知识块: {len(kb_entries)}")
    default_system = str(system_prompt or "").strip() or str(profile_system or "").strip() or str((profile or {}).get("system_prompt", "") or "").strip()

    if include_profile_assets and _is_local_dir(base_resolved):
        _task_log(task, 22, "📝 打包模型档案、系统提示词与附加元数据")
        profile_dir = pack_dir / "profile"
        profile_dir.mkdir(parents=True, exist_ok=True)
        for rel_name in ["forgex_model_profile.json", "system_prompt.txt", "Modelfile", "forgex_bake_meta.json"]:
            _copy_file_if_exists(Path(base_resolved) / rel_name, profile_dir / rel_name)
        if include_knowledge and (Path(base_resolved) / "knowledge_base").exists():
            _copy_tree(Path(base_resolved) / "knowledge_base", pack_dir / "knowledge" / "source")

    _task_log(task, 28, "📦 复制主模型资产")
    base_manifest_ref, base_bundled = _bundle_ref(base_resolved, pack_dir, "models/base_model", bundle_assets)
    bundled_count += int(base_bundled)
    if bundle_assets and _is_local_dir(base_resolved):
        if not base_bundled:
            raise RuntimeError("主模型要求打包进包内，但复制未执行")
        ok, reason = _validate_model_bundle(pack_dir / (base_manifest_ref or "models/base_model"), "full")
        if not ok:
            raise RuntimeError(f"主模型打包失败或不完整：{reason}")

    experts: List[Dict[str, Any]] = []
    unsupported: List[str] = []
    residual_fallbacks: List[str] = []
    if cfg:
        _task_log(task, 40, f"🧩 开始处理 {len(cfg.neurons)} 个专家条目")
        for idx, neuron in enumerate(cfg.neurons):
            entry = _expert_entry_from_neuron(neuron, base_model_ref=base_manifest_ref or base_resolved)
            if entry["kind"] not in ("full", "lora", "residual"):
                unsupported.append(f"{entry['name']} ({entry['kind']})")
                continue
            rel_name = f"experts/{idx+1:02d}_{_slugify(entry['name'])}"
            if entry["kind"] == "full":
                rel_name = f"models/{rel_name}"
            _task_log(task, 40 + min(30, (idx + 1) * max(1, int(30 / max(len(cfg.neurons), 1)))), f"🔧 处理专家 {idx+1}/{len(cfg.neurons)}: {entry['name']} ({entry['kind']})")
            original_ref = str(entry.get("ref", "") or "")
            can_make_residual = (
                str(compression_mode or "off").lower() == "residual"
                and entry["kind"] == "full"
                and bundle_assets
                and _is_local_dir(base_resolved)
                and _is_local_dir(original_ref)
            )
            if can_make_residual:
                residual_rel = rel_name
                residual_dir = pack_dir / residual_rel
                try:
                    _task_log(task, None, f"🧮 生成 Residual 专家: {entry['name']}")
                    _build_residual_bundle(base_resolved, original_ref, residual_dir, base_manifest_ref=base_manifest_ref or base_resolved, task=task)
                    entry["ref"] = residual_rel.replace("\\", "/")
                    entry["kind"] = "residual"
                    entry["base_model_ref"] = base_manifest_ref or base_resolved
                    entry["tokenizer_ref"] = base_manifest_ref or base_resolved
                    scope = _expert_scope_from_entry(entry, idx)
                    entry["knowledge_scope"] = scope
                    entry["knowledge_index"] = f"knowledge/experts/{scope}/index.json"
                    entry["knowledge_entries_dir"] = ""
                    entry["knowledge_sources_dir"] = f"knowledge/experts/{scope}/files"
                    bundled_count += 1
                    experts.append(entry)
                    continue
                except Exception as residual_exc:
                    residual_fallbacks.append(f"{entry['name']}: {residual_exc}")
                    _task_log(task, None, f"⚠️ Residual 生成失败，已回退 full: {entry['name']} :: {residual_exc}")
            bundled_ref, was_bundled = _bundle_ref(original_ref, pack_dir, rel_name, bundle_assets)
            if was_bundled:
                entry["ref"] = bundled_ref
                bundled_count += 1
                bundled_path = pack_dir / bundled_ref
                ok, reason = _validate_model_bundle(bundled_path, entry["kind"])
                if not ok:
                    raise RuntimeError(f"专家 {entry['name']} 打包失败或不完整：{reason}")
            elif bundle_assets and _is_local_dir(original_ref):
                raise RuntimeError(f"专家 {entry['name']} 要求打包进包内，但复制未执行")
            if entry["kind"] == "lora":
                base_ref = entry.get("base_model_ref") or base_resolved
                if base_ref == base_resolved and (base_manifest_ref or base_resolved):
                    entry["base_model_ref"] = base_manifest_ref or base_resolved
                else:
                    rel_base = f"models/lora_bases/{_slugify(entry['name'])}"
                    bundled_base_ref, bundled_base = _bundle_ref(base_ref, pack_dir, rel_base, bundle_assets)
                    if bundled_base:
                        entry["base_model_ref"] = bundled_base_ref
                        bundled_count += 1
            elif entry["kind"] == "full":
                entry["base_model_ref"] = base_manifest_ref or base_resolved
                entry["tokenizer_ref"] = base_manifest_ref or base_resolved
            scope = _expert_scope_from_entry(entry, idx)
            entry["knowledge_scope"] = scope
            entry["knowledge_index"] = f"knowledge/experts/{scope}/index.json"
            entry["knowledge_entries_dir"] = ""
            entry["knowledge_sources_dir"] = f"knowledge/experts/{scope}/files"
            experts.append(entry)

    expert_scopes = [str(x.get("knowledge_scope") or _expert_scope_from_entry(x, i)).strip() for i, x in enumerate(experts)]
    kb_tree = _export_knowledge_tree(base_resolved if include_knowledge else "", pack_dir, expert_scopes=expert_scopes)
    knowledge_meta = {
        "enabled": bool(include_knowledge),
        "mode": "simple_scoped",
        "shared_index": "knowledge/common/index.json",
        "base_index": "knowledge/general/index.json",
        "shared_entries_dir": "",
        "shared_sources_dir": "knowledge/common/files",
        "base_entries_dir": "",
        "base_sources_dir": "knowledge/general/files",
        "doc_count": len({x.get('doc', '') for x in kb_entries}) if include_knowledge else 0,
        "chunk_count": len(kb_entries) if include_knowledge else 0,
        "retrieval_top_k": 4,
        "max_context_chars": 1800,
        "chunk_size": 500,
        "chunk_overlap": 50,
    }
    if include_knowledge:
        _task_log(task, 74, f"📚 对齐 simple-scoped 知识目录，块数: {len(kb_entries)}")
        general_index = pack_dir / "knowledge" / "general" / "index.json"
        if kb_entries:
            general_index.write_text(json.dumps(kb_entries, indent=2, ensure_ascii=False), encoding="utf-8")
        else:
            _ensure_json_placeholder(general_index, [])
        _ensure_json_placeholder(pack_dir / "knowledge" / "common" / "index.json", [])
        for scope in expert_scopes:
            _ensure_json_placeholder(pack_dir / "knowledge" / "experts" / scope / "index.json", [])



    params = dict((profile or {}).get("parameters", {}) or {})


    params = dict((profile or {}).get("parameters", {}) or {})
    generation = {
        "temperature": float(params.get("temperature", 0.7) or 0.7),
        "top_p": float(params.get("top_p", 0.9) or 0.9),
        "repeat_penalty": float(params.get("repeat_penalty", 1.1) or 1.1),
        "max_new_tokens": int(params.get("max_tokens", 512) or 512),
    }

    manifest = {
        "format": "forgex.rsmora",
        "version": "0.3",
        "package_name": safe_pkg,
        "display_name": package_name or safe_pkg,
        "created_from": {
            "base_model": base_resolved,
            "neuron_config": neuron_config_name or "",
        },
        "package_assets": {
            "bundle_assets": bool(bundle_assets),
            "bundled_base_model": bool(base_bundled),
            "bundled_asset_count": bundled_count,
            "include_profile_assets": bool(include_profile_assets),
            "include_knowledge": bool(include_knowledge),
        },
        "base_model": {
            "ref": base_manifest_ref or base_resolved,
            "kind": detect_model_kind(base_resolved),
        },
        "profile": _profile_summary(profile),
        "route": {
            "mode": "keyword_on_demand",
            "activation_threshold": 1.5,
        },
        "knowledge": knowledge_meta,
        "runtime": {
            "host": "127.0.0.1",
            "port": int(api_port or 8714),
            "system_prompt": default_system,
            "max_cached_experts": 2,
            "use_4bit": bool(use_4bit),
            "prefer_gpu": True,
            "backend_mode": "auto",
            "cpu_fallback_on_error": True,
            "enable_experts": True,
            "auto_open_browser": True,
            "compression_mode": compression_mode,
            "expert_backend_mode": "auto",
            "gpu_dtype": "auto",
            "expert_tokenizer_strategy": "auto",
            "swarm_mode": "single",
            "consult_note_max_new_tokens": 256,
            "consult_synth_max_new_tokens": 768,
            "consult_note_temperature": 0.2,
            "consult_max_experts": 2,
            "consult_secondary_ratio": 0.65,
            "consult_force_forced_expert": False,
            "forced_route": "auto",
            "route_sticky_turns": 4,
            "route_sticky_score_bonus": 0.75,
            "route_sticky_ttl_sec": 900,
            "cached_route_bonus": 0.15,
            "short_query_base_chars": 12,
            "thinking_transparency": "structured",
            "expert_worklog_max_new_tokens": 192,
            "expert_worklog_temperature": 0.15,
            "expert_vram_queue_on_oom": True,
            "expert_vram_queue_max_cached_experts": 1,
            "expert_vram_queue_release_after_reply": False,
            "consult_dispatch_mode": "auto",
            "consult_parallel_allow_gpu": False,
            "consult_queue_release_between_experts": True,
            "generation": {**generation, "renormalize_logits": True, "remove_invalid_values": True},
        },
        "compat_profiles": {
            "openai": {"path": "/v1/chat/completions"},
            "ollama": {"path": "/api/chat"},
        },
        "experts": experts,
        "notes": {"unsupported_experts": unsupported, "residual_fallbacks": residual_fallbacks},
        "layout_version": "simple-runtime-v1",
        "automation": {
            "enabled": True,
            "workspace_root": "automation/workspace",
            "tools_root": "automation/tools",
            "workflows_root": "automation/workflows",
            "logs_root": "automation/logs",
            "allow_local_file_edit": True,
            "safe_edit_copy_only": True,
            "max_split_chunk_chars": 2500,
            "default_overlap_chars": 200,
        },
        "search": {
            "enabled": False,
            "allow_web_fetch": True,
            "engine": "duckduckgo_lite",
            "timeout_sec": 15,
            "max_results": 5,
            "logs_root": "automation/logs",
        },
    }

    _task_log(task, 82, "🧾 生成 manifest 与运行时脚本")
    (pack_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    (pack_dir / "runtime_server.py").write_text(_runtime_server_template(), encoding="utf-8")
    (pack_dir / "start_api.bat").write_text(_bat_template(api_port), encoding="utf-8")
    sh_path = pack_dir / "start_api.sh"
    sh_path.write_text(_sh_template(api_port), encoding="utf-8")
    try:
        os.chmod(sh_path, 0o755)
    except Exception:
        pass
    (pack_dir / "README_RUNTIME.txt").write_text(_readme_text(manifest), encoding="utf-8")
    (pack_dir / "runtime_settings.json").write_text(
        json.dumps({
            "host": manifest["runtime"]["host"],
            "port": manifest["runtime"]["port"],
            "system_prompt": manifest["runtime"].get("system_prompt", ""),
            "temperature": manifest["runtime"]["generation"]["temperature"],
            "top_p": manifest["runtime"]["generation"]["top_p"],
            "repeat_penalty": manifest["runtime"]["generation"]["repeat_penalty"],
            "max_new_tokens": manifest["runtime"]["generation"]["max_new_tokens"],
            "activation_threshold": manifest["route"].get("activation_threshold", 1.5),
            "max_cached_experts": manifest["runtime"].get("max_cached_experts", 1),
            "use_4bit": manifest["runtime"].get("use_4bit", False),
            "backend_mode": manifest["runtime"].get("backend_mode", "gpu"),
            "prefer_gpu": manifest["runtime"].get("prefer_gpu", True),
            "cpu_fallback_on_error": manifest["runtime"].get("cpu_fallback_on_error", True),
            "enable_experts": manifest["runtime"].get("enable_experts", True),
            "expert_backend_mode": manifest["runtime"].get("expert_backend_mode", "auto"),
            "gpu_dtype": manifest["runtime"].get("gpu_dtype", "auto"),
            "expert_tokenizer_strategy": manifest["runtime"].get("expert_tokenizer_strategy", "auto"),
            "swarm_mode": manifest["runtime"].get("swarm_mode", "single"),
            "consult_max_experts": manifest["runtime"].get("consult_max_experts", 2),
            "consult_secondary_ratio": manifest["runtime"].get("consult_secondary_ratio", 0.65),
            "consult_force_forced_expert": manifest["runtime"].get("consult_force_forced_expert", False),
            "consult_note_max_new_tokens": manifest["runtime"].get("consult_note_max_new_tokens", 256),
            "consult_synth_max_new_tokens": manifest["runtime"].get("consult_synth_max_new_tokens", 768),
            "consult_note_temperature": manifest["runtime"].get("consult_note_temperature", 0.2),
            "route_sticky_turns": manifest["runtime"].get("route_sticky_turns", 4),
            "route_sticky_score_bonus": manifest["runtime"].get("route_sticky_score_bonus", 0.75),
            "route_sticky_ttl_sec": manifest["runtime"].get("route_sticky_ttl_sec", 900),
            "cached_route_bonus": manifest["runtime"].get("cached_route_bonus", 0.15),
            "short_query_base_chars": manifest["runtime"].get("short_query_base_chars", 12),
            "thinking_transparency": manifest["runtime"].get("thinking_transparency", "structured"),
            "expert_worklog_max_new_tokens": manifest["runtime"].get("expert_worklog_max_new_tokens", 192),
            "expert_worklog_temperature": manifest["runtime"].get("expert_worklog_temperature", 0.15),
            "expert_vram_queue_on_oom": manifest["runtime"].get("expert_vram_queue_on_oom", True),
            "expert_vram_queue_max_cached_experts": manifest["runtime"].get("expert_vram_queue_max_cached_experts", 1),
            "expert_vram_queue_release_after_reply": manifest["runtime"].get("expert_vram_queue_release_after_reply", False),
            "consult_dispatch_mode": manifest["runtime"].get("consult_dispatch_mode", "auto"),
            "consult_parallel_allow_gpu": manifest["runtime"].get("consult_parallel_allow_gpu", False),
            "consult_queue_release_between_experts": manifest["runtime"].get("consult_queue_release_between_experts", True),
            "forced_route": manifest["runtime"].get("forced_route", "auto"),
            "auto_open_browser": manifest["runtime"].get("auto_open_browser", True),
            "knowledge_mode": manifest["knowledge"].get("mode", "simple_scoped"),
            "knowledge_paths": {
                "common": manifest["knowledge"].get("shared_index", "knowledge/common/index.json"),
                "general": manifest["knowledge"].get("base_index", "knowledge/general/index.json"),
                "experts": "knowledge/experts",
            },
            "automation": {
                "enabled": manifest.get("automation", {}).get("enabled", True),
                "workspace_root": manifest.get("automation", {}).get("workspace_root", "automation/workspace"),
                "allow_local_file_edit": manifest.get("automation", {}).get("allow_local_file_edit", True),
                "safe_edit_copy_only": manifest.get("automation", {}).get("safe_edit_copy_only", True),
                "max_split_chunk_chars": manifest.get("automation", {}).get("max_split_chunk_chars", 2500),
                "default_overlap_chars": manifest.get("automation", {}).get("default_overlap_chars", 200),
            },
            "search": {
                "enabled": manifest.get("search", {}).get("enabled", False),
                "allow_web_fetch": manifest.get("search", {}).get("allow_web_fetch", True),
                "engine": manifest.get("search", {}).get("engine", "duckduckgo_lite"),
                "timeout_sec": manifest.get("search", {}).get("timeout_sec", 15),
                "max_results": manifest.get("search", {}).get("max_results", 5),
                "logs_root": manifest.get("search", {}).get("logs_root", "automation/logs"),
            },
        }, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    (pack_dir / "openai_profile.json").write_text(
        json.dumps({"base_url": f"http://127.0.0.1:{int(api_port or 8714)}/v1", "model": safe_pkg}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    (pack_dir / "ollama_profile.json").write_text(
        json.dumps({"base_url": f"http://127.0.0.1:{int(api_port or 8714)}", "model": safe_pkg}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    _task_log(task, 86, "🗂️ 同步 simple-runtime-v1 布局与自动化脚手架")
    _copy_runtime_scaffold(pack_dir)

    integrity = _verify_pack_integrity(pack_dir, manifest)
    if not integrity.get("ok"):
        raise RuntimeError("Runtime 包完整性校验失败：\n- " + "\n- ".join(integrity.get("issues") or []))

    _task_log(task, 92, "🧪 包内完整性校验通过，开始生成 ZIP")
    if zip_path.exists():
        zip_path.unlink()
    _zip_dir_with_progress(pack_dir, zip_path, task=task)

    _task_log(task, 100, f"✅ Runtime 包导出完成\n目录: {pack_dir}\nZIP: {zip_path}\n专家数: {len(experts)}\n已打包资产: {bundled_count}")
    log(f"📦 ForgeX Runtime 包已导出: {pack_dir}")
    return {
        "pack_dir": str(pack_dir),
        "zip_path": str(zip_path),
        "package_name": safe_pkg,
        "expert_count": len(experts),
        "unsupported": unsupported,
        "knowledge_docs": knowledge_meta["doc_count"],
        "bundled_assets": bundled_count,
        "manifest": manifest,
        "integrity": integrity,
    }


__all__ = ["PACKS_DIR", "create_runtime_pack", "list_neuron_configs"]
