from __future__ import annotations
import argparse
import shutil
from pathlib import Path

ALIASES = {
    "01_forgex_runtime": "academic",
    "02_forgex_runtime": "legal",
    "03_forgex_runtime": "medical",
    "04_forgex_runtime": "coding",
}

def copy_tree(src: Path, dst: Path):
    if not src.exists():
        return
    dst.mkdir(parents=True, exist_ok=True)
    for f in src.rglob("*"):
        if f.is_file():
            rel = f.relative_to(src)
            target = dst / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, target)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pack", default=".")
    args = parser.parse_args()
    root = Path(args.pack).resolve()

    copy_tree(root / "knowledge" / "shared" / "sources", root / "knowledge" / "common" / "files")
    copy_tree(root / "knowledge" / "base" / "sources", root / "knowledge" / "general" / "files")
    for old, new in ALIASES.items():
        copy_tree(root / "knowledge" / "experts" / old / "sources", root / "knowledge" / "experts" / new / "files")
    print("[ok] 已把旧知识目录复制到简化目录。")
    print("下一步请执行: python tools/rebuild_knowledge_simple.py")

if __name__ == "__main__":
    main()
