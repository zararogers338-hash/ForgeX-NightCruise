# POLARIS OS Phase 2B VIP Package

This source package is prepared for GitHub upload.

## Included

- POLARIS OS Gradio local AI Studio source
- Training, export, runtime, launcher, installer, scripts, and test modules
- GitHub-ready README, ignore rules, attributes, smoke workflow, and docs
- Empty runtime data folders with `.gitkeep`

## Excluded

- Python virtual environment
- Model weights
- LoRA checkpoints
- GGUF files
- Training datasets
- Logs and caches
- Build output and wheelhouse

## Recent Stability Fixes

- Default label smoothing changed to 0.
- Validation/eval disabled by default for low-VRAM stability.
- Eval path uses loss-only settings to reduce logits memory spikes.
- RTX 5080 Laptop defaults are conservative: batch 1, seq 2048.
- OOM errors are reported separately from device-side assert errors.
