#!/usr/bin/env bash
# Historical compatibility wrapper.

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "[INFO] install_forgex.sh 是历史入口，已切换到北极星 / POLARIS OS 安装脚本。"
exec bash "$SCRIPT_DIR/install.sh" "$@"
