# POLARIS OS Windows 安装器说明

## 技术选择

本工程采用 `.NET Framework WinForms + Python scripts`：

- `POLARIS_OS_Setup.exe`：WinForms 向导式安装器，源码 zip 嵌入 EXE。
- `POLARIS_OS_Launcher.exe`：WinForms 桌面启动器，无杂乱命令行窗口。
- `scripts/bootstrap_env.py`：Python 3.11 / venv / GPU 后端 / 依赖安装 / 断点状态。
- `scripts/healthcheck.py`：安装后自检。

选择理由：当前机器已有 .NET Framework `csc.exe`，不需要 Inno/NSIS/WiX/Electron/Tauri 工具链；EXE 可以原生支持中文路径、实时日志、后台进程和快捷方式。

## 目录结构

- `installer/`：安装器 UI 和构建脚本。
- `launcher/`：桌面启动器 UI。
- `scripts/bootstrap_env.py`：环境安装和恢复。
- `scripts/healthcheck.py`：自检。
- `scripts/launch_polaris.py`：Python fallback 启动器。
- `wheelhouse/`：离线/预下载 wheel 放置目录。
- `install_manifest.json`：安装器 manifest。
- `data/install_state.json`：安装状态，安装后自动生成。

## 构建

在项目根目录运行：

```powershell
py -3.11 installer\build_windows.py
```

产物会生成到：

- `outputs\POLARIS_OS_Setup.exe`
- `outputs\POLARIS_OS_Portable.zip`
- `outputs\POLARIS_OS_Installer_Report.md`

## Dry-run

```powershell
py -3.11 scripts\bootstrap_env.py --dry-run --backend cpu
```

已有 Python 3.11 复用分支：

```powershell
py -3.11 scripts\bootstrap_env.py --dry-run --backend auto
```

模拟没有 Python 3.11：

```powershell
py -3.11 scripts\bootstrap_env.py --dry-run --simulate-no-python
```

## 自检

```powershell
.venv\Scripts\python.exe scripts\healthcheck.py --project-dir .
```

实际启动 `main.py` 并验证服务响应：

```powershell
.venv\Scripts\python.exe scripts\healthcheck.py --project-dir . --start-main --port 7860
```

## 用户安装流程

1. 运行 `POLARIS_OS_Setup.exe`。
2. 选择安装位置。
3. 检测 Python 3.11；缺失时点击“一键安装 Python 3.11”。
4. 检测 GPU。
5. 选择 `auto` / `cuda` / `cpu` 后端。
6. 点击依赖安装，等待日志完成。
7. 设置模型和缓存目录。
8. 运行服务自检。
9. 创建桌面和开始菜单快捷方式，启动 POLARIS OS。

## 日志

启动器日志默认保存到：

```text
%LOCALAPPDATA%\POLARIS OS\logs
```

也可以由 `data/install_state.json` 中的 `paths.logs` 覆盖。

## 断点续装

安装状态写入：

```text
data\install_state.json
```

再次运行安装器时会复用已有 `.venv` 和已满足依赖；`wheelhouse/` 内如果有 wheel，会优先作为 `pip --find-links` 来源。

## 端口策略

启动器默认尝试 `127.0.0.1:7860`。如果被占用：

- 日志显示占用 PID。
- 自动切换到后续空闲端口。
- 可点击“结束旧进程”关闭旧 POLARIS `main.py` 进程。

## 训练稳定性修复

`core/trainer.py` 已加入：

- 训练前读取 `model.config` 最大上下文长度。
- UI 传入的 `max_seq_len` 超过模型上限时自动降级并写入任务日志。
- tokenized/packed batch 预检。
- `input_ids` 不得超过 vocab size。
- `seq_len` 不得超过模型 position 上限。
- `attention_mask` / `labels` 长度一致。
- CUDA device-side assert 触发后给出中文说明并提示必须重启服务。
