from __future__ import annotations

import argparse
import gc
import json
import re
import threading
import time
import html
from concurrent.futures import ThreadPoolExecutor, as_completed
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse, quote_plus
from urllib.request import Request, urlopen

PACKAGE_DIR = Path(__file__).resolve().parent
MANIFEST_PATH = PACKAGE_DIR / "manifest.json"
SETTINGS_PATH = PACKAGE_DIR / "runtime_settings.json"


def _load_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, data: Any):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _runtime_log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def _append_jsonl_log(path: Path, record: Dict[str, Any]):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _read_recent_jsonl(path: Path, limit: int = 50) -> List[Dict[str, Any]]:
    try:
        if not path.exists():
            return []
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()[-max(1, int(limit)):]
        out = []
        for line in lines:
            try:
                out.append(json.loads(line))
            except Exception:
                out.append({"raw": line})
        return out
    except Exception:
        return []


def _search_cfg() -> Dict[str, Any]:
    cfg = dict((MANIFEST.get("search") or {}))
    s = _settings_snapshot().get("search") or {}
    if isinstance(s, dict):
        cfg.update(s)
    cfg.setdefault("enabled", False)
    cfg.setdefault("allow_web_fetch", True)
    cfg.setdefault("engine", "duckduckgo_lite")
    cfg.setdefault("timeout_sec", 15)
    cfg.setdefault("max_results", 5)
    cfg.setdefault("user_agent", "POLARIS-Runtime/1.0")
    cfg.setdefault("logs_root", "automation/logs")
    return cfg


def _tooling_log(event: str, **payload):
    cfg = _automation_cfg()
    root = PACKAGE_DIR / str(cfg.get("logs_root") or "automation/logs")
    _append_jsonl_log(root / "tooling.jsonl", {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "event": event,
        **payload,
    })


MANIFEST = _load_json(MANIFEST_PATH, {}) or {}


def _normalize_path(path: str) -> str:
    try:
        parsed = urlparse(path)
        return parsed.path.rstrip("/") or "/"
    except Exception:
        return path.rstrip("/") or "/"


def _json_response(handler, code: int, payload: Dict[str, Any]):
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    handler.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    handler.end_headers()
    handler.wfile.write(data)


def _text_response(handler, code: int, text: str, content_type: str = "text/html; charset=utf-8"):
    data = text.encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()
    handler.wfile.write(data)


def _read_json_body(handler) -> Dict[str, Any]:
    length = int(handler.headers.get("Content-Length", "0") or 0)
    raw = handler.rfile.read(length) if length > 0 else b"{}"
    if not raw:
        return {}
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return {}

def _settings_snapshot() -> Dict[str, Any]:
    return _load_json(SETTINGS_PATH, {}) or {}


def _automation_cfg() -> Dict[str, Any]:
    cfg = dict((MANIFEST.get("automation") or {}))
    s = _settings_snapshot().get("automation") or {}
    if isinstance(s, dict):
        cfg.update(s)
    cfg.setdefault("enabled", True)
    cfg.setdefault("workspace_root", "automation/workspace")
    cfg.setdefault("tools_root", "automation/tools")
    cfg.setdefault("workflows_root", "automation/workflows")
    cfg.setdefault("logs_root", "automation/logs")
    cfg.setdefault("allow_local_file_edit", True)
    cfg.setdefault("safe_edit_copy_only", True)
    cfg.setdefault("max_split_chunk_chars", 2500)
    cfg.setdefault("default_overlap_chars", 200)
    return cfg


def _resolve_local_fs_path(raw: str) -> Path:
    p = Path(str(raw or "")).expanduser()
    if not p.is_absolute():
        p = (PACKAGE_DIR / p).resolve()
    else:
        p = p.resolve()
    return p


def _workspace_path(*parts: str) -> Path:
    root = PACKAGE_DIR / str(_automation_cfg().get("workspace_root") or "automation/workspace")
    return (root.joinpath(*parts)).resolve()


def _strip_html_text(raw: str) -> str:
    text = re.sub(r"<script[\s\S]*?</script>", " ", raw, flags=re.I)
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _tool_web_fetch(args: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _search_cfg()
    if not bool(cfg.get("enabled", False)) or not bool(cfg.get("allow_web_fetch", True)):
        return {"ok": False, "error": "search_disabled"}
    url = str(args.get("url") or "").strip()
    if not url.startswith(("http://", "https://")):
        return {"ok": False, "error": "bad_url", "url": url}
    timeout = max(3, min(int(args.get("timeout_sec") or cfg.get("timeout_sec") or 15), 60))
    max_chars = max(500, min(int(args.get("max_chars") or 12000), 50000))
    req = Request(url, headers={"User-Agent": str(cfg.get("user_agent") or "POLARIS-Runtime/1.0")})
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            ctype = str(resp.headers.get("Content-Type") or "")
        text = raw.decode("utf-8", errors="ignore")
        body = _strip_html_text(text) if ("html" in ctype.lower() or "<html" in text.lower()) else text
        body = body[:max_chars]
        out = {"ok": True, "tool": "web_fetch", "url": url, "content_type": ctype, "text": body, "chars": len(body)}
        _tooling_log("web_fetch", ok=True, url=url, chars=len(body))
        return out
    except Exception as e:
        _tooling_log("web_fetch", ok=False, url=url, error=str(e))
        return {"ok": False, "tool": "web_fetch", "url": url, "error": str(e)}


def _tool_web_search(args: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _search_cfg()
    if not bool(cfg.get("enabled", False)):
        return {"ok": False, "error": "search_disabled"}
    query = str(args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "missing_query"}
    timeout = max(3, min(int(args.get("timeout_sec") or cfg.get("timeout_sec") or 15), 60))
    max_results = max(1, min(int(args.get("max_results") or cfg.get("max_results") or 5), 10))
    url = f"https://lite.duckduckgo.com/lite/?q={quote_plus(query)}"
    req = Request(url, headers={"User-Agent": str(cfg.get("user_agent") or "POLARIS-Runtime/1.0")})
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="ignore")
        results = []
        for href, title in re.findall(r"<a[^>]+href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>", raw, flags=re.I|re.S):
            title = _strip_html_text(title)
            if not title:
                continue
            if href.startswith("/") and "duckduckgo.com" not in href:
                continue
            results.append({"title": title[:300], "url": href})
            if len(results) >= max_results:
                break
        out = {"ok": True, "tool": "web_search", "engine": str(cfg.get("engine") or "duckduckgo_lite"), "query": query, "results": results}
        _tooling_log("web_search", ok=True, query=query, result_count=len(results))
        return out
    except Exception as e:
        _tooling_log("web_search", ok=False, query=query, error=str(e))
        return {"ok": False, "tool": "web_search", "query": query, "error": str(e)}


def _tool_file_read(args: Dict[str, Any]) -> Dict[str, Any]:
    path = _resolve_local_fs_path(str(args.get("path") or ""))
    if not path.exists() or not path.is_file():
        return {"ok": False, "error": "file_not_found", "path": str(path)}
    encoding = str(args.get("encoding") or "utf-8")
    max_chars = int(args.get("max_chars") or 200000)
    text = path.read_text(encoding=encoding, errors="ignore")
    return {"ok": True, "tool": "file_read", "path": str(path), "text": text[:max_chars], "truncated": len(text) > max_chars, "chars": len(text)}


def _tool_file_write(args: Dict[str, Any]) -> Dict[str, Any]:
    path = _resolve_local_fs_path(str(args.get("path") or ""))
    content = str(args.get("content") or "")
    encoding = str(args.get("encoding") or "utf-8")
    append = bool(args.get("append", False))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a" if append else "w", encoding=encoding) as f:
        f.write(content)
    return {"ok": True, "tool": "file_write", "path": str(path), "append": append, "chars_written": len(content)}


def _tool_text_replace(args: Dict[str, Any]) -> Dict[str, Any]:
    text = str(args.get("text") or "")
    old_text = str(args.get("old_text") or "")
    new_text = str(args.get("new_text") or "")
    count = int(args.get("count") or 0)
    if not old_text:
        return {"ok": False, "error": "old_text_empty"}
    if count > 0:
        replaced = text.replace(old_text, new_text, count)
    else:
        replaced = text.replace(old_text, new_text)
    return {"ok": True, "tool": "text_replace", "text": replaced, "changed": replaced != text}


def _tool_file_edit(args: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _automation_cfg()
    path = _resolve_local_fs_path(str(args.get("path") or ""))
    if not path.exists() or not path.is_file():
        return {"ok": False, "error": "file_not_found", "path": str(path)}
    encoding = str(args.get("encoding") or "utf-8")
    old_text = str(args.get("old_text") or "")
    new_text = str(args.get("new_text") or "")
    copy_only = bool(args.get("copy_only", cfg.get("safe_edit_copy_only", True)))
    raw = path.read_text(encoding=encoding, errors="ignore")
    if old_text and old_text not in raw:
        return {"ok": False, "error": "old_text_not_found", "path": str(path)}
    updated = raw.replace(old_text, new_text, 1) if old_text else (raw + new_text)
    explicit_output = str(args.get("output_path") or "").strip()
    if explicit_output:
        target = _resolve_local_fs_path(explicit_output)
    elif copy_only:
        stamp = time.strftime("%Y%m%d_%H%M%S")
        target = _workspace_path("editing", f"{path.stem}.edited_{stamp}{path.suffix}")
    else:
        backup = _workspace_path("editing", f"{path.stem}.backup_{time.strftime('%Y%m%d_%H%M%S')}{path.suffix}")
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_text(raw, encoding=encoding)
        target = path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(updated, encoding=encoding)
    return {"ok": True, "tool": "file_edit", "path": str(path), "output_path": str(target), "copy_only": copy_only, "changed": updated != raw}


def _split_text_chunks(text: str, chunk_chars: int, overlap_chars: int) -> List[str]:
    text = str(text or "")
    chunk_chars = max(200, int(chunk_chars or 2500))
    overlap_chars = max(0, min(int(overlap_chars or 200), chunk_chars // 2))
    chunks: List[str] = []
    i = 0
    n = len(text)
    while i < n:
        j = min(n, i + chunk_chars)
        if j < n:
            cut = text.rfind("\n\n", i, j)
            if cut > i + chunk_chars // 3:
                j = cut
        chunks.append(text[i:j])
        if j >= n:
            break
        i = max(j - overlap_chars, i + 1)
    return [x for x in chunks if x]


def _tool_file_split(args: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _automation_cfg()
    path_val = str(args.get("path") or "").strip()
    encoding = str(args.get("encoding") or "utf-8")
    chunk_chars = int(args.get("chunk_chars") or cfg.get("max_split_chunk_chars", 2500) or 2500)
    overlap_chars = int(args.get("overlap_chars") or cfg.get("default_overlap_chars", 200) or 200)
    emit_files = bool(args.get("emit_files", False))
    if path_val:
        path = _resolve_local_fs_path(path_val)
        if not path.exists() or not path.is_file():
            return {"ok": False, "error": "file_not_found", "path": str(path)}
        raw = path.read_text(encoding=encoding, errors="ignore")
        base_name = path.stem
    else:
        raw = str(args.get("text") or "")
        path = None
        base_name = "split"
    chunks = _split_text_chunks(raw, chunk_chars, overlap_chars)
    written = []
    if emit_files:
        out_dir_raw = str(args.get("output_dir") or "").strip()
        out_dir = _resolve_local_fs_path(out_dir_raw) if out_dir_raw else _workspace_path("editing", f"{base_name}_parts")
        out_dir.mkdir(parents=True, exist_ok=True)
        for idx, chunk in enumerate(chunks):
            target = out_dir / f"{base_name}_{idx:03d}.txt"
            target.write_text(chunk, encoding="utf-8")
            written.append(str(target))
    return {"ok": True, "tool": "file_split", "path": str(path) if path else "", "chunk_count": len(chunks), "chunks": [{"idx": i, "chars": len(c), "preview": c[:200]} for i, c in enumerate(chunks)], "written_files": written}


def _tool_catalog() -> List[Dict[str, Any]]:
    items = [
        {"name": "file_read", "description": "读取本地文件"},
        {"name": "file_write", "description": "写入本地文件"},
        {"name": "file_edit", "description": "安全编辑本地文件，默认生成副本"},
        {"name": "file_split", "description": "拆分长文件，支持生成分片文件"},
        {"name": "text_replace", "description": "纯文本替换"},
    ]
    scfg = _search_cfg()
    if bool(scfg.get("enabled", False)):
        items.extend([
            {"name": "web_search", "description": "联网搜索（DuckDuckGo Lite）"},
            {"name": "web_fetch", "description": "抓取网页正文"},
        ])
    return items


def _run_automation_tool(payload: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _automation_cfg()
    tool = str(payload.get("tool") or "").strip().lower()
    args = payload.get("args") or {}
    if not isinstance(args, dict):
        args = {}
    if tool in ("web_search", "web_fetch"):
        out = _tool_web_search(args) if tool == "web_search" else _tool_web_fetch(args)
        _tooling_log("tool_run", tool=tool, ok=bool(out.get("ok")), mode="search")
        return out
    if not bool(cfg.get("enabled", True)):
        return {"ok": False, "error": "automation_disabled"}
    if tool == "file_read":
        out = _tool_file_read(args)
    elif tool == "file_write":
        out = _tool_file_write(args)
    elif tool == "file_edit":
        out = _tool_file_edit(args)
    elif tool == "file_split":
        out = _tool_file_split(args)
    elif tool == "text_replace":
        out = _tool_text_replace(args)
    else:
        out = {"ok": False, "error": "unknown_tool", "tool": tool}
    _tooling_log("tool_run", tool=tool, ok=bool(out.get("ok")), mode="automation")
    return out


def _plain_chat_prompt(messages: List[Dict[str, str]]) -> str:
    system_lines = [m.get("content", "") for m in messages if m.get("role") == "system" and m.get("content")]
    chat_lines = []
    for m in messages:
        role = str(m.get("role", "user") or "user").strip().lower()
        if role == "system":
            continue
        tag = "User" if role == "user" else "Assistant"
        chat_lines.append(f"{tag}: {m.get('content', '')}")
    prefix = "\n".join(f"System: {x}" for x in system_lines if x)
    body = "\n".join(chat_lines)
    if prefix:
        body = prefix + "\n\n" + body
    return body + "\nAssistant: "


def _safe_chat_prompt(tokenizer, messages: List[Dict[str, str]]) -> str:
    try:
        return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    except Exception:
        return _plain_chat_prompt(messages)


def _is_expert_prompt_compat_error(exc: Exception) -> bool:
    msg = str(exc or "").strip().lower()
    hints = (
        "tokenizer_model_mismatch",
        "conversation roles must alternate",
        "apply_chat_template",
        "chat template",
        "chat_template",
        "template error",
        "special token",
        "token id",
    )
    return any(h in msg for h in hints)


def _maybe_bnb(enabled: bool, allow_gpu: bool):
    if not enabled or not allow_gpu:
        return None
    try:
        import torch
        if not torch.cuda.is_available():
            return None
        from transformers import BitsAndBytesConfig
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_quant_type="nf4",
        )
    except Exception:
        return None


def _is_gpu_generation_error(exc: Exception) -> bool:
    msg = str(exc or "").lower()
    hints = (
        "device-side assert triggered",
        "cudaerrorassert",
        "indexselectlargeindex",
        "index out of range",
        "assertion `input[0] != 0` failed",
        "tensorcompare.cu",
        "cuda error",
        "cublas",
        "illegal memory access",
        "out of memory",
        "tokenizer_model_mismatch",
    )
    return any(h in msg for h in hints)


def _friendly_gpu_error(exc: Exception) -> str:
    raw = str(exc or "").strip()
    raw_low = raw.lower()
    if "device-side assert triggered" in raw_low or "cudaerrorassert" in raw_low:
        return "GPU 推理触发 CUDA 断言，常见原因是 tokenizer 与模型不匹配、输入越界，或某个专家模型在当前 GPU 路径下不稳定。POLARIS Runtime 已停用 GPU，本轮将改走 CPU。"
    if "index out of range" in raw_low or "indexselectlargeindex" in raw_low:
        return "GPU 推理出现 token 索引越界，通常是 tokenizer / 模型词表不匹配。POLARIS Runtime 已停用 GPU，本轮将改走 CPU。"
    return raw[:400] if raw else "GPU 推理异常，POLARIS Runtime 已停用 GPU，本轮将改走 CPU。"


def _safe_model_max_length(tok) -> int:
    try:
        value = int(getattr(tok, "model_max_length", 0) or 0)
        if value <= 0 or value >= 1000000:
            return 0
        return value
    except Exception:
        return 0


def _flatten_message_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                if isinstance(item.get("text"), str):
                    parts.append(item.get("text") or "")
                elif item.get("type") == "text" and isinstance(item.get("content"), str):
                    parts.append(item.get("content") or "")
                elif isinstance(item.get("content"), str):
                    parts.append(item.get("content") or "")
        return "\n".join(x for x in parts if x)
    if isinstance(content, dict):
        if isinstance(content.get("text"), str):
            return content.get("text") or ""
        if isinstance(content.get("content"), str):
            return content.get("content") or ""
    return str(content or "")


def _normalize_messages_for_template(messages: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    normalized: List[Dict[str, str]] = []
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        role = str(msg.get("role") or "user").strip().lower()
        if role == "developer":
            role = "system"
        elif role not in {"system", "user", "assistant", "tool"}:
            role = "user"
        normalized.append({"role": role, "content": _flatten_message_content(msg.get("content", ""))})
    return normalized


def _coalesce_messages_for_template(messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        role = str(msg.get("role") or "user").strip().lower() or "user"
        content = str(msg.get("content") or "").strip()
        if not content:
            continue
        if out and str(out[-1].get("role") or "").strip().lower() == role:
            prev = str(out[-1].get("content") or "").strip()
            out[-1]["content"] = (prev + "\n\n" + content).strip() if prev else content
        else:
            out.append({"role": role, "content": content})
    return out


def _append_user_prompt_safely(messages: List[Dict[str, str]], prompt: str) -> List[Dict[str, str]]:
    msgs = [dict(m) for m in (messages or []) if isinstance(m, dict)]
    prompt = str(prompt or "").strip()
    if not prompt:
        return msgs
    if msgs and str(msgs[-1].get("role") or "").strip().lower() == "user":
        prev = str(msgs[-1].get("content") or "").strip()
        msgs[-1]["content"] = (prev + "\n\n" + prompt).strip() if prev else prompt
        return msgs
    msgs.append({"role": "user", "content": prompt})
    return msgs


def _tokenizer_namespace_size(tok) -> int:
    try:
        vocab = tok.get_vocab()
        if isinstance(vocab, dict) and vocab:
            return int(max(vocab.values())) + 1
    except Exception:
        pass
    try:
        base = int(getattr(tok, "vocab_size", 0) or 0)
    except Exception:
        base = 0
    try:
        added = len(tok.get_added_vocab() or {})
    except Exception:
        added = 0
    if base > 0:
        return base + max(0, added)
    try:
        return int(len(tok))
    except Exception:
        return 0


def _looks_garbled_text(text: str) -> bool:
    s = str(text or "").strip()
    if not s:
        return True
    compact = "".join(ch for ch in s if not ch.isspace())
    if not compact:
        return True
    if compact.replace("�", "") == "":
        return True
    bad = compact.count("�")
    if bad and len(compact) <= 4:
        return True
    if bad / max(len(compact), 1) >= 0.30:
        return True
    symbols = sum(1 for ch in compact if not (ch.isalnum() or ('一' <= ch <= '鿿')))
    if len(compact) <= 3 and symbols == len(compact):
        return True
    return False


def _is_oom_error(exc: Exception) -> bool:
    msg = str(exc or "").strip().lower()
    hints = (
        "out of memory",
        "cuda out of memory",
        "cudnn_status_alloc_failed",
        "cuda error: out of memory",
        "memory allocation",
        "insufficient memory",
        "hip out of memory",
        "allocator",
    )
    return any(h in msg for h in hints)


class RuntimeCore:
    def __init__(self, manifest: Dict[str, Any]):
        self.manifest = manifest
        self.package_name = str(manifest.get("package_name") or "polaris-runtime-model")
        self.base_model_ref = self._resolve_ref(str((manifest.get("base_model") or {}).get("ref") or ""))
        self.experts = [e for e in (manifest.get("experts") or []) if isinstance(e, dict) and e.get("enabled", True)]
        self._knowledge_cfg = dict(manifest.get("knowledge") or {})
        self._knowledge_cfg.setdefault("retrieval_top_k", 4)
        self._knowledge_cfg.setdefault("max_context_chars", 1800)
        self._knowledge_shared_entries, self._knowledge_base_entries, self._knowledge_expert_entries = self._load_knowledge_scopes()
        self._settings = self._load_settings()
        self._lock = threading.Lock()
        self._base_model = None
        self._base_tok = None
        self._cpu_base_model = None
        self._cpu_base_tok = None
        self._expert_cache: Dict[str, Tuple[Any, Any]] = {}
        self._expert_order: List[str] = []
        self._bad_experts: Dict[str, str] = {}
        self._gpu_disabled = False
        self._gpu_disable_reason = ""
        self._gpu_probe_done = False
        self._gpu_available_cached: Optional[bool] = None
        self._gpu_device_name = ""
        self._gpu_probe_error = ""
        self._last_error = ""
        self._last_route = "base"
        self._request_count = 0
        self._session_routes: Dict[str, Dict[str, Any]] = {}
        self._expert_queue_mode = False
        self._expert_queue_reason = ""
        self._expert_queue_reserved = ""
        self._expert_input_overrides: Dict[str, Dict[str, Any]] = {}
        self._expert_health_status: Dict[str, Dict[str, Any]] = {}

    def _sanitize_messages(self, messages: Optional[List[Dict[str, Any]]]) -> List[Dict[str, str]]:
        sanitized: List[Dict[str, str]] = []
        for m in messages or []:
            if not isinstance(m, dict):
                continue
            role = str(m.get("role") or "user")
            content = m.get("content")
            if isinstance(content, list):
                parts: List[str] = []
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        parts.append(str(part.get("text") or ""))
                    elif isinstance(part, str):
                        parts.append(part)
                content = "\n".join(x for x in parts if x)
            elif isinstance(content, dict):
                content = str(content.get("text") or content.get("content") or "")
            sanitized.append({"role": role, "content": str(content or "")})
        return sanitized

    def _resolve_ref(self, ref: str) -> str:
        if not ref:
            return ""
        p = Path(ref)
        if p.exists():
            return str(p)
        rel = (PACKAGE_DIR / ref).resolve()
        if rel.exists():
            return str(rel)
        return ref

    def _default_settings(self) -> Dict[str, Any]:
        runtime = self.manifest.get("runtime") or {}
        generation = runtime.get("generation") or {}
        return {
            "host": str(runtime.get("host") or "127.0.0.1"),
            "port": int(runtime.get("port") or 8714),
            "system_prompt": str(runtime.get("system_prompt") or ""),
            "temperature": float(generation.get("temperature") or 0.7),
            "top_p": float(generation.get("top_p") or 0.9),
            "repeat_penalty": float(generation.get("repeat_penalty") or 1.1),
            "max_new_tokens": int(generation.get("max_new_tokens") or 512),
            "activation_threshold": float((self.manifest.get("route") or {}).get("activation_threshold") or 1.5),
            "max_cached_experts": int(runtime.get("max_cached_experts") or 2),
            "expert_vram_queue_on_oom": bool(runtime.get("expert_vram_queue_on_oom", True)),
            "expert_vram_queue_max_cached_experts": int(runtime.get("expert_vram_queue_max_cached_experts") or 1),
            "expert_vram_queue_release_after_reply": bool(runtime.get("expert_vram_queue_release_after_reply", False)),
            "route_sticky_turns": int(runtime.get("route_sticky_turns") or 4),
            "route_sticky_score_bonus": float(runtime.get("route_sticky_score_bonus") or 0.75),
            "route_sticky_ttl_sec": int(runtime.get("route_sticky_ttl_sec") or 900),
            "cached_route_bonus": float(runtime.get("cached_route_bonus") or 0.15),
            "short_query_base_chars": int(runtime.get("short_query_base_chars") or 12),
            "use_4bit": bool(runtime.get("use_4bit", False)),
            "backend_mode": str(runtime.get("backend_mode") or "auto").lower(),
            "gate_backend_mode": str(runtime.get("gate_backend_mode") or runtime.get("backend_mode") or "auto").lower(),
            "prefer_gpu": bool(runtime.get("prefer_gpu", True)),
            "cpu_fallback_on_error": bool(runtime.get("cpu_fallback_on_error", True)),
            "enable_experts": bool(runtime.get("enable_experts", True)),
            "expert_backend_mode": str(runtime.get("expert_backend_mode") or "auto"),
            "gpu_dtype": str(runtime.get("gpu_dtype") or "auto"),
            "expert_tokenizer_strategy": str(runtime.get("expert_tokenizer_strategy") or "auto"),
            "gate_chat_template_mode": str(runtime.get("gate_chat_template_mode") or "auto").lower(),
            "expert_chat_template_mode": str(runtime.get("expert_chat_template_mode") or "auto_fallback").lower(),
            "expert_fallback_allow_base_tokenizer": bool(runtime.get("expert_fallback_allow_base_tokenizer", True)),
            "expert_fallback_plain_prompt": bool(runtime.get("expert_fallback_plain_prompt", True)),
            "gpt_oss_official_compat": bool(runtime.get("gpt_oss_official_compat", True)),
            "gpt_oss_plain_prompt_fallback": bool(runtime.get("gpt_oss_plain_prompt_fallback", True)),
            "swarm_mode": str(runtime.get("swarm_mode") or "single"),
            "consult_max_experts": int(runtime.get("consult_max_experts") or 2),
            "consult_secondary_ratio": float(runtime.get("consult_secondary_ratio") or 0.65),
            "consult_force_forced_expert": bool(runtime.get("consult_force_forced_expert", False)),
            "consult_note_max_new_tokens": int(runtime.get("consult_note_max_new_tokens") or 256),
            "consult_synth_max_new_tokens": int(runtime.get("consult_synth_max_new_tokens") or 768),
            "consult_note_temperature": float(runtime.get("consult_note_temperature") or 0.2),
            "consult_dispatch_mode": str(runtime.get("consult_dispatch_mode") or "auto"),
            "consult_parallel_allow_gpu": bool(runtime.get("consult_parallel_allow_gpu", False)),
            "consult_queue_release_between_experts": bool(runtime.get("consult_queue_release_between_experts", True)),
            "thinking_transparency": str(runtime.get("thinking_transparency") or "structured"),
            "expert_worklog_max_new_tokens": int(runtime.get("expert_worklog_max_new_tokens") or 192),
            "expert_worklog_temperature": float(runtime.get("expert_worklog_temperature") or 0.15),
            "forced_route": str(runtime.get("forced_route") or "auto"),
            "auto_open_browser": bool(runtime.get("auto_open_browser", True)),
        }

    def _load_settings(self) -> Dict[str, Any]:
        merged = self._default_settings()
        disk = _load_json(SETTINGS_PATH, {}) or {}
        if isinstance(disk, dict):
            for k, v in disk.items():
                if v is not None:
                    merged[k] = v
        gate_mode = str(merged.get("gate_backend_mode") or merged.get("backend_mode") or "auto").lower()
        if gate_mode not in ("auto", "gpu", "cpu"):
            gate_mode = "auto"
        merged["gate_backend_mode"] = gate_mode
        merged["backend_mode"] = gate_mode
        expert_mode = str(merged.get("expert_backend_mode") or "auto").lower()
        if expert_mode not in ("auto", "gpu", "cpu"):
            expert_mode = "auto"
        merged["expert_backend_mode"] = expert_mode
        strategy = str(merged.get("expert_tokenizer_strategy") or "auto").lower()
        if strategy not in ("auto", "self", "base", "base_for_full", "prefer_base", "shared"):
            strategy = "auto"
        merged["expert_tokenizer_strategy"] = strategy
        expert_template_mode = str(merged.get("expert_chat_template_mode") or "auto_fallback").strip().lower()
        if expert_template_mode not in ("native", "plain", "auto_fallback"):
            expert_template_mode = "auto_fallback"
        merged["expert_chat_template_mode"] = expert_template_mode
        merged["expert_fallback_allow_base_tokenizer"] = bool(merged.get("expert_fallback_allow_base_tokenizer", True))
        merged["expert_fallback_plain_prompt"] = bool(merged.get("expert_fallback_plain_prompt", True))
        merged["prefer_gpu"] = gate_mode != "cpu"
        _write_json(SETTINGS_PATH, merged)
        return merged

    def _backend_mode(self) -> str:
        mode = str(self._settings.get("gate_backend_mode") or self._settings.get("backend_mode") or "").lower()
        if mode not in ("auto", "gpu", "cpu"):
            mode = "gpu" if bool(self._settings.get("prefer_gpu", True)) else "cpu"
        self._settings["gate_backend_mode"] = mode
        self._settings["backend_mode"] = mode
        return mode

    def _probe_cuda_once(self, force: bool = False) -> bool:
        if self._gpu_probe_done and not force:
            return bool(self._gpu_available_cached)
        self._gpu_probe_done = True
        self._gpu_available_cached = False
        self._gpu_device_name = ""
        self._gpu_probe_error = ""
        try:
            import torch
            ok = bool(torch.cuda.is_available())
            self._gpu_available_cached = ok
            if ok:
                try:
                    self._gpu_device_name = str(torch.cuda.get_device_name(0) or "")
                except Exception:
                    self._gpu_device_name = ""
                try:
                    t = torch.tensor([1], device="cuda")
                    del t
                    torch.cuda.synchronize()
                except Exception as e:
                    self._gpu_probe_error = str(e)[:400]
                    self._gpu_available_cached = False
                    return False
            return ok
        except Exception as e:
            self._gpu_probe_error = str(e)[:400]
            self._gpu_available_cached = False
            return False

    def _gpu_dtype(self):
        import torch
        raw = str(self._settings.get("gpu_dtype") or "auto").strip().lower()
        if raw in ("bf16", "bfloat16"):
            return torch.bfloat16
        if raw in ("fp16", "float16", "half"):
            return torch.float16
        try:
            if torch.cuda.is_available() and hasattr(torch.cuda, "is_bf16_supported") and torch.cuda.is_bf16_supported():
                return torch.bfloat16
        except Exception:
            pass
        return torch.float16

    def _profile_for_mode(self, mode: Optional[str], allow_probe: bool = False) -> Dict[str, Any]:
        import torch
        raw = str(mode or "auto").strip().lower()
        if raw not in ("auto", "gpu", "cpu"):
            raw = "auto"
        use_gpu = False
        if raw != "cpu" and not self._gpu_disabled:
            if allow_probe:
                use_gpu = self._probe_cuda_once(force=False)
            else:
                use_gpu = bool(self._gpu_available_cached) if self._gpu_probe_done else False
        return {
            "cuda": use_gpu,
            "dtype": self._gpu_dtype() if use_gpu else torch.float32,
            "device_map": "auto" if use_gpu else None,
        }

    def _current_profile(self, allow_probe: bool = False) -> Dict[str, Any]:
        return self._profile_for_mode(self._backend_mode(), allow_probe=allow_probe)

    def _clear_gpu_objects(self):
        self._base_model = None
        self._base_tok = None
        self._expert_cache.clear()
        self._expert_order.clear()
        self._expert_health_status.clear()
        self._session_routes.clear()
        self._expert_queue_reserved = ""
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass

    def _mark_gpu_failed(self, reason: str):
        self._gpu_disabled = True
        self._gpu_disable_reason = str(reason or "GPU 推理异常")[:400]
        self._last_error = self._gpu_disable_reason
        _runtime_log(f"GPU 已停用，后续将走 CPU: {self._gpu_disable_reason}")
        self._clear_gpu_objects()

    def _mark_expert_failed(self, expert_name: str, reason: str):
        if expert_name:
            self._bad_experts[expert_name] = str(reason or "专家 GPU 推理异常")[:240]
            self._expert_cache.pop(expert_name, None)
            try:
                if expert_name in self._expert_order:
                    self._expert_order.remove(expert_name)
            except Exception:
                pass
            _runtime_log(f"专家已停用，本轮改走主模型 GPU: {expert_name} :: {self._bad_experts[expert_name]}")


    def get_runtime_status(self) -> Dict[str, Any]:
        profile = self._current_profile(allow_probe=False)
        mode = self._backend_mode()
        return {
            "ok": True,
            "package_name": self.package_name,
            "base_model": self.base_model_ref,
            "expert_count": len(self.experts),
            "expert_names": [str((e.get("name") or e.get("domain") or e.get("ref") or "expert")).strip() for e in self.experts],
            "cached_experts": list(self._expert_cache.keys()),
            "disabled_experts": dict(self._bad_experts),
            "expert_health_status": dict(self._expert_health_status),
            "expert_queue_mode": bool(self._expert_queue_mode),
            "expert_queue_reason": self._expert_queue_reason,
            "expert_queue_reserved": self._expert_queue_reserved,
            "knowledge_chunks": len(self._knowledge_shared_entries) + len(self._knowledge_base_entries) + sum(len(v) for v in self._knowledge_expert_entries.values()),
            "swarm_mode": str(self._settings.get("swarm_mode") or "single"),
            "consult_max_experts": int(self._settings.get("consult_max_experts") or 2),
            "consult_dispatch_mode": str(self._settings.get("consult_dispatch_mode") or "auto"),
            "consult_parallel_allow_gpu": bool(self._settings.get("consult_parallel_allow_gpu", False)),
            "route_sticky_turns": int(self._settings.get("route_sticky_turns") or 0),
            "short_query_base_chars": int(self._settings.get("short_query_base_chars") or 0),
            "backend_mode": mode,
            "gate_backend_mode": str(self._settings.get("gate_backend_mode") or mode),
            "expert_backend_mode": str(self._settings.get("expert_backend_mode") or "auto"),
            "prefer_gpu": mode != "cpu",
            "gpu_probe_done": bool(self._gpu_probe_done),
            "gpu_available": self._gpu_available_cached if self._gpu_probe_done else None,
            "gpu_device_name": self._gpu_device_name,
            "gpu_probe_error": self._gpu_probe_error,
            "gpu_enabled": bool(profile["cuda"]),
            "gpu_disabled": bool(self._gpu_disabled),
            "gpu_disabled_reason": self._gpu_disable_reason,
            "base_loaded": self._base_model is not None,
            "cpu_base_loaded": self._cpu_base_model is not None,
            "last_route": self._last_route,
            "last_error": self._last_error,
            "request_count": self._request_count,
        }

    def get_settings(self) -> Dict[str, Any]:
        s = dict(self._settings)
        s.update({
            "package_name": self.package_name,
            "base_model": self.base_model_ref,
            "openai_base_url": f"http://{s['host']}:{s['port']}/v1",
            "ollama_base_url": f"http://{s['host']}:{s['port']}",
            "runtime_status": self.get_runtime_status(),
            "automation_enabled": bool(_automation_cfg().get("enabled", True)),
            "allow_local_file_edit": bool(_automation_cfg().get("allow_local_file_edit", True)),
            "safe_edit_copy_only": bool(_automation_cfg().get("safe_edit_copy_only", True)),
            "search_enabled": bool(_search_cfg().get("enabled", False)),
            "allow_web_fetch": bool(_search_cfg().get("allow_web_fetch", True)),
            "automation": _automation_cfg(),
            "search": _search_cfg(),
        })
        return s

    def update_settings(self, updates: Dict[str, Any]) -> Dict[str, Any]:
        changed = {}
        schema = {
            "host": str,
            "port": int,
            "system_prompt": str,
            "temperature": float,
            "top_p": float,
            "repeat_penalty": float,
            "max_new_tokens": int,
            "activation_threshold": float,
            "max_cached_experts": int,
            "route_sticky_turns": int,
            "route_sticky_score_bonus": float,
            "route_sticky_ttl_sec": int,
            "cached_route_bonus": float,
            "short_query_base_chars": int,
            "use_4bit": bool,
            "backend_mode": str,
            "gate_backend_mode": str,
            "prefer_gpu": bool,
            "cpu_fallback_on_error": bool,
            "enable_experts": bool,
            "expert_backend_mode": str,
            "expert_tokenizer_strategy": str,
            "expert_chat_template_mode": str,
            "expert_fallback_allow_base_tokenizer": bool,
            "expert_fallback_plain_prompt": bool,
            "swarm_mode": str,
            "consult_max_experts": int,
            "consult_secondary_ratio": float,
            "consult_force_forced_expert": bool,
            "consult_note_max_new_tokens": int,
            "consult_synth_max_new_tokens": int,
            "consult_note_temperature": float,
            "consult_dispatch_mode": str,
            "consult_parallel_allow_gpu": bool,
            "thinking_transparency": str,
            "expert_worklog_max_new_tokens": int,
            "expert_worklog_temperature": float,
            "forced_route": str,
            "auto_open_browser": bool,
            "automation_enabled": bool,
            "allow_local_file_edit": bool,
            "safe_edit_copy_only": bool,
            "search_enabled": bool,
            "allow_web_fetch": bool,
        }
        for k, caster in schema.items():
            if k not in updates:
                continue
            try:
                v = updates[k]
                if caster is bool:
                    v = bool(v)
                else:
                    v = caster(v)
                if k in ("backend_mode", "gate_backend_mode", "expert_backend_mode"):
                    v = str(v).lower()
                    if v not in ("auto", "gpu", "cpu"):
                        continue
                    if k in ("backend_mode", "gate_backend_mode"):
                        self._settings["prefer_gpu"] = v != "cpu"
                if k == "expert_tokenizer_strategy":
                    v = str(v).lower().strip()
                    if v not in ("auto", "self", "base", "base_for_full", "prefer_base", "shared"):
                        continue
                if k == "expert_chat_template_mode":
                    v = str(v).lower().strip()
                    if v not in ("native", "plain", "auto_fallback"):
                        continue
                if k in ("temperature", "top_p"):
                    v = max(0.0, min(float(v), 2.0))
                if k == "repeat_penalty":
                    v = max(0.8, min(float(v), 2.0))
                if k == "max_new_tokens":
                    v = max(16, min(int(v), 8192))
                if k == "activation_threshold":
                    v = max(0.0, min(float(v), 10.0))
                if k == "max_cached_experts":
                    v = max(0, min(int(v), 8))
                if k == "swarm_mode":
                    v = str(v).lower().strip()
                    if v not in ("single", "consult", "consult_always"):
                        continue
                if k == "consult_max_experts":
                    v = max(1, min(int(v), 4))
                if k == "consult_secondary_ratio":
                    v = max(0.2, min(float(v), 1.2))
                if k == "route_sticky_turns":
                    v = max(0, min(int(v), 12))
                if k == "route_sticky_ttl_sec":
                    v = max(30, min(int(v), 86400))
                if k in ("route_sticky_score_bonus", "cached_route_bonus"):
                    v = max(0.0, min(float(v), 3.0))
                if k == "short_query_base_chars":
                    v = max(0, min(int(v), 64))
                if k in ("consult_note_max_new_tokens", "consult_synth_max_new_tokens"):
                    v = max(32, min(int(v), 4096))
                if k == "consult_note_temperature":
                    v = max(0.0, min(float(v), 2.0))
                if k == "consult_dispatch_mode":
                    v = str(v).lower().strip()
                    if v not in ("auto", "manual_queue", "parallel"):
                        continue
                if k == "consult_parallel_allow_gpu":
                    v = bool(v)
                if k == "thinking_transparency":
                    v = str(v).lower().strip()
                    if v not in ("off", "structured"):
                        continue
                if k == "expert_worklog_max_new_tokens":
                    v = max(64, min(int(v), 1024))
                if k == "expert_worklog_temperature":
                    v = max(0.0, min(float(v), 2.0))
                if k in ("automation_enabled", "allow_local_file_edit", "safe_edit_copy_only"):
                    self._settings.setdefault("automation", {})
                    key_map = {"automation_enabled": "enabled", "allow_local_file_edit": "allow_local_file_edit", "safe_edit_copy_only": "safe_edit_copy_only"}
                    self._settings["automation"][key_map[k]] = v
                    changed[k] = v
                    continue
                if k in ("search_enabled", "allow_web_fetch"):
                    self._settings.setdefault("search", {})
                    key_map = {"search_enabled": "enabled", "allow_web_fetch": "allow_web_fetch"}
                    self._settings["search"][key_map[k]] = v
                    changed[k] = v
                    continue
                self._settings[k] = v
                if k == "backend_mode":
                    self._settings["gate_backend_mode"] = v
                    changed["gate_backend_mode"] = v
                elif k == "gate_backend_mode":
                    self._settings["backend_mode"] = v
                    changed["backend_mode"] = v
                changed[k] = v
            except Exception:
                continue
        if "prefer_gpu" in changed and "backend_mode" not in changed and "gate_backend_mode" not in changed:
            forced_mode = "gpu" if bool(self._settings.get("prefer_gpu", True)) else "cpu"
            self._settings["backend_mode"] = forced_mode
            self._settings["gate_backend_mode"] = forced_mode
            changed["backend_mode"] = forced_mode
            changed["gate_backend_mode"] = forced_mode
        _write_json(SETTINGS_PATH, self._settings)
        if any(k in changed for k in ("backend_mode", "gate_backend_mode", "prefer_gpu", "use_4bit", "max_cached_experts", "expert_backend_mode", "expert_tokenizer_strategy", "expert_chat_template_mode", "expert_fallback_allow_base_tokenizer", "expert_fallback_plain_prompt")):
            self._clear_gpu_objects()
            self._gpu_probe_done = False
            self._gpu_available_cached = None
            self._gpu_device_name = ""
            self._gpu_probe_error = ""
            if self._backend_mode() != "cpu":
                self._gpu_disabled = False
                self._gpu_disable_reason = ""
        return {"ok": True, "changed": changed, "requires_restart": any(k in changed for k in ("host", "port")), "settings": self.get_settings()}

    def clear_caches(self) -> Dict[str, Any]:
        self._base_model = None
        self._base_tok = None
        self._cpu_base_model = None
        self._cpu_base_tok = None
        self._expert_cache.clear()
        self._expert_order.clear()
        self._expert_health_status.clear()
        self._session_routes.clear()
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass
        return self.get_runtime_status()

    def recover_gpu(self) -> Dict[str, Any]:
        self._gpu_disabled = False
        self._gpu_disable_reason = ""
        self._gpu_probe_done = False
        self._gpu_available_cached = None
        self._gpu_device_name = ""
        self._gpu_probe_error = ""
        self._clear_gpu_objects()
        return self.get_runtime_status()


    def _load_index_entries(self, index_file: str) -> List[Dict[str, Any]]:
        if not index_file:
            return []
        path = (PACKAGE_DIR / index_file).resolve()
        data = _load_json(path, []) or []
        if isinstance(data, dict):
            data = data.get("entries") or data.get("chunks") or []
        if not isinstance(data, list):
            return []
        return [x for x in data if isinstance(x, dict) and str(x.get("text", "")).strip()]

    def _load_entries_dir(self, root: Path) -> List[Dict[str, Any]]:
        entries: List[Dict[str, Any]] = []
        if root.exists() and root.is_dir():
            for f in sorted(root.rglob("*.json")):
                data = _load_json(f, []) or []
                if isinstance(data, dict):
                    data = data.get("entries") or data.get("chunks") or []
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and item.get("text"):
                            item = dict(item)
                            item.setdefault("doc", f.stem)
                            entries.append(item)
        return entries

    def _normalize_knowledge_entries(self, entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        dedup: List[Dict[str, Any]] = []
        seen = set()
        for item in entries:
            body = str(item.get("text", "")).strip()
            if not body:
                continue
            key = (str(item.get("doc") or "doc"), int(item.get("chunk_idx") or 0), body)
            if key in seen:
                continue
            seen.add(key)
            item = dict(item)
            item["text"] = body
            item.setdefault("doc", "doc")
            item.setdefault("chunk_idx", len(dedup))
            dedup.append(item)
        return dedup

    def _expert_scope_key(self, expert: Optional[Dict[str, Any]]) -> str:
        if not expert:
            return ""
        explicit = str(expert.get("knowledge_scope") or expert.get("knowledge_key") or "").strip()
        if explicit:
            return explicit
        ref = str(expert.get("ref") or "").strip()
        if ref:
            return Path(ref).name
        return str(expert.get("name") or expert.get("domain") or "").strip()

    def _load_scope_bundle(self, *, index_file: str = "", entries_dir: str = "", sources_dir: str = "") -> List[Dict[str, Any]]:
        entries: List[Dict[str, Any]] = []
        if index_file:
            entries.extend(self._load_index_entries(index_file))
        if entries_dir:
            root = (PACKAGE_DIR / entries_dir).resolve()
            entries.extend(self._load_entries_dir(root))
        if sources_dir:
            root = (PACKAGE_DIR / sources_dir).resolve()
            if root.exists() and root.is_dir():
                entries.extend(self._load_knowledge_source_dir(root))
        return self._normalize_knowledge_entries(entries)

    def _load_knowledge_scopes(self) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, List[Dict[str, Any]]]]:
        if not bool(self._knowledge_cfg.get("enabled", False)):
            return [], [], {}
        mode = str(self._knowledge_cfg.get("mode") or "legacy").strip().lower()
        shared_entries = self._load_scope_bundle(
            index_file=str(self._knowledge_cfg.get("shared_index") or ""),
            entries_dir=str(self._knowledge_cfg.get("shared_entries_dir") or ("knowledge/shared/entries" if mode == "scoped" else "")),
            sources_dir=str(self._knowledge_cfg.get("shared_sources_dir") or ("knowledge/shared/sources" if mode == "scoped" else "")),
        )
        base_entries = self._load_scope_bundle(
            index_file=str(self._knowledge_cfg.get("base_index") or self._knowledge_cfg.get("index_file") or ""),
            entries_dir=str(self._knowledge_cfg.get("base_entries_dir") or self._knowledge_cfg.get("entries_dir") or ("knowledge/base/entries" if mode == "scoped" else "")),
            sources_dir=str(self._knowledge_cfg.get("base_sources_dir") or self._knowledge_cfg.get("sources_dir") or self._knowledge_cfg.get("docs_dir") or ("knowledge/base/sources" if mode == "scoped" else "")),
        )
        expert_entries: Dict[str, List[Dict[str, Any]]] = {}
        for expert in self.experts:
            key = self._expert_scope_key(expert)
            idx = str(expert.get("knowledge_index") or (f"knowledge/experts/{key}/knowledge_index.json" if mode == "scoped" and key else ""))
            edir = str(expert.get("knowledge_entries_dir") or (f"knowledge/experts/{key}/entries" if mode == "scoped" and key else ""))
            sdir = str(expert.get("knowledge_sources_dir") or (f"knowledge/experts/{key}/sources" if mode == "scoped" and key else ""))
            expert_entries[key] = self._load_scope_bundle(index_file=idx, entries_dir=edir, sources_dir=sdir)
        return shared_entries, base_entries, expert_entries

    def _knowledge_entries_for(self, expert: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        entries: List[Dict[str, Any]] = []
        if self._knowledge_shared_entries:
            entries.extend([dict(x, _scope="shared") for x in self._knowledge_shared_entries])
        if expert is None:
            if self._knowledge_base_entries:
                entries.extend([dict(x, _scope="base") for x in self._knowledge_base_entries])
            return entries
        key = self._expert_scope_key(expert)
        scoped = self._knowledge_expert_entries.get(key) or []
        if scoped:
            entries.extend([dict(x, _scope=f"expert:{key}") for x in scoped])
        if self._knowledge_base_entries:
            entries.extend([dict(x, _scope="base") for x in self._knowledge_base_entries])
        return entries

    def _load_knowledge_source_dir(self, root: Path) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        exts = {".txt", ".md", ".markdown", ".csv", ".json", ".jsonl", ".pdf", ".docx"}
        for f in sorted(root.rglob("*")):
            if not f.is_file() or f.suffix.lower() not in exts:
                continue
            try:
                raw_text = self._read_knowledge_source_text(f)
            except Exception as e:
                _runtime_log(f"知识源读取失败，已跳过: {f.name} :: {e}")
                continue
            for item in self._chunk_knowledge_text(f, raw_text):
                out.append(item)
        return out

    def _read_knowledge_source_text(self, path: Path) -> str:
        suffix = path.suffix.lower()
        if suffix in (".txt", ".md", ".markdown", ".csv"):
            for enc in ("utf-8", "utf-8-sig", "gb18030", "gbk"):
                try:
                    return path.read_text(encoding=enc, errors="ignore")
                except Exception:
                    pass
            return path.read_text(errors="ignore")
        if suffix in (".json", ".jsonl"):
            if suffix == ".jsonl":
                texts = []
                for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        item = json.loads(line)
                    except Exception:
                        continue
                    if isinstance(item, dict):
                        if item.get("text"):
                            texts.append(str(item.get("text")))
                        elif isinstance(item.get("messages"), list):
                            for msg in item.get("messages") or []:
                                if isinstance(msg, dict) and msg.get("role") == "assistant" and msg.get("content"):
                                    texts.append(str(msg.get("content")))
                    elif isinstance(item, (str, int, float)):
                        texts.append(str(item))
                return "\n\n".join(t for t in texts if t)
            data = _load_json(path, None)
            if isinstance(data, list):
                texts = []
                for item in data:
                    if isinstance(item, dict):
                        if item.get("text"):
                            texts.append(str(item.get("text")))
                        elif isinstance(item.get("messages"), list):
                            for msg in item.get("messages") or []:
                                if isinstance(msg, dict) and msg.get("role") == "assistant" and msg.get("content"):
                                    texts.append(str(msg.get("content")))
                    elif isinstance(item, (str, int, float)):
                        texts.append(str(item))
                return "\n\n".join(t for t in texts if t)
            if isinstance(data, dict):
                if data.get("text"):
                    return str(data.get("text"))
                return json.dumps(data, ensure_ascii=False, indent=2)
            return path.read_text(encoding="utf-8", errors="ignore")
        if suffix == ".pdf":
            try:
                from pypdf import PdfReader  # type: ignore
            except Exception:
                from PyPDF2 import PdfReader  # type: ignore
            reader = PdfReader(str(path))
            pages = []
            for page in reader.pages:
                try:
                    pages.append(page.extract_text() or "")
                except Exception:
                    continue
            return "\n\n".join(x for x in pages if x)
        if suffix == ".docx":
            from docx import Document  # type: ignore
            doc = Document(str(path))
            return "\n".join(p.text for p in doc.paragraphs if p.text)
        return ""

    def _chunk_knowledge_text(self, source_path: Path, text: str) -> List[Dict[str, Any]]:
        raw = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
        raw = re.sub(r"\n{3,}", "\n\n", raw)
        raw = raw.strip()
        if not raw:
            return []
        size = max(120, int(self._knowledge_cfg.get("chunk_size", 500) or 500))
        overlap = max(0, min(int(self._knowledge_cfg.get("chunk_overlap", 50) or 50), size // 2))
        step = max(1, size - overlap)
        chunks: List[Dict[str, Any]] = []
        idx = 0
        pos = 0
        doc_name = source_path.name
        while pos < len(raw):
            piece = raw[pos:pos + size].strip()
            if piece:
                chunks.append({
                    "doc": doc_name,
                    "chunk_idx": idx,
                    "text": piece,
                    "source_path": str(source_path).replace("\\", "/"),
                    "source_type": source_path.suffix.lower().lstrip('.'),
                })
                idx += 1
            pos += step
        return chunks

    def _retrieve_knowledge(self, query: str, expert: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        entries = self._knowledge_entries_for(expert)
        if not query or not entries:
            return []
        top_k = int(self._knowledge_cfg.get("retrieval_top_k", 4) or 4)
        q = query.lower()
        q_words = [w for w in re.split(r"\s+", q) if w]
        q_chars = set(q)
        scored = []
        for item in entries:
            text = str(item.get("text", "")).strip()
            if not text:
                continue
            chunk = text.lower()
            score = 0.0
            for word in q_words:
                if word in chunk:
                    score += 1.0
            if q_chars:
                score += len(q_chars & set(chunk)) / max(len(q_chars), 1) * 0.5
            scope = str(item.get("_scope") or "")
            if scope.startswith("expert:"):
                score += 0.35
            elif scope == "shared":
                score += 0.15
            if score > 0:
                scored.append((score, item))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [dict(x[1], score=x[0]) for x in scored[:top_k]]

    def _knowledge_context(self, query: str, expert: Optional[Dict[str, Any]] = None) -> str:
        hits = self._retrieve_knowledge(query, expert)
        if not hits:
            return ""
        max_chars = int(self._knowledge_cfg.get("max_context_chars", 1800) or 1800)
        parts, total = [], 0
        for hit in hits:
            scope = str(hit.get("_scope") or "")
            scope_label = "共享" if scope == "shared" else ("主模型" if scope == "base" else "专家")
            block = f"[{scope_label}::{hit.get('doc', 'doc')}] {hit.get('text', '')}"
            if total + len(block) > max_chars:
                break
            parts.append(block)
            total += len(block)
        return "【内置知识库参考】\n" + "\n---\n".join(parts) if parts else ""

    def _model_token_limit(self, model) -> int:
        try:
            emb = model.get_input_embeddings()
            if emb is not None and getattr(emb, "num_embeddings", None):
                return int(emb.num_embeddings)
        except Exception:
            pass
        try:
            vocab_size = getattr(getattr(model, "config", None), "vocab_size", None)
            if vocab_size:
                return int(vocab_size)
        except Exception:
            pass
        return 0

    def _ensure_tokenizer_compat(self, model, tok, label: str):
        limit = self._model_token_limit(model)
        if limit <= 0:
            return
        for attr in ("pad_token_id", "bos_token_id", "eos_token_id", "unk_token_id"):
            try:
                value = getattr(tok, attr, None)
                if value is not None and int(value) >= limit:
                    raise RuntimeError(f"TOKENIZER_MODEL_MISMATCH::{label} {attr}={int(value)} 超过模型词表上限 {limit - 1}")
            except RuntimeError:
                raise
            except Exception:
                pass
        tok_size = _tokenizer_namespace_size(tok)
        if tok_size and tok_size > limit + 8:
            _runtime_log(f"Tokenizer namespace larger than embeddings but probe passed: {label} :: tokenizer={tok_size}, model={limit}. 继续运行，并以实际编码 token id 检查为准。")

    def _prepare_inputs(self, model, tok, messages: List[Dict[str, str]], label: str, move_to_device: bool = True, template_mode: Optional[str] = None):
        normalized_messages = _coalesce_messages_for_template(_normalize_messages_for_template(messages))
        model_type = str(getattr(getattr(model, "config", None), "model_type", "") or "").strip().lower()
        try:
            device = next(model.parameters()).device
        except Exception:
            device = "cpu"

        def _finalize_inputs(inputs):
            if "input_ids" not in inputs or getattr(inputs["input_ids"], "numel", lambda: 0)() <= 0:
                raise RuntimeError(f"EMPTY_PROMPT::{label} prompt 编码后为空")
            if "attention_mask" not in inputs or inputs.get("attention_mask") is None:
                try:
                    import torch
                    inputs["attention_mask"] = torch.ones_like(inputs["input_ids"])
                except Exception:
                    pass
            if "attention_mask" in inputs:
                try:
                    if int(inputs["attention_mask"].sum().item()) <= 0:
                        import torch
                        inputs["attention_mask"] = torch.ones_like(inputs["input_ids"])
                except Exception:
                    pass
            limit = self._model_token_limit(model)
            try:
                max_id = int(inputs["input_ids"].max().item())
            except Exception:
                max_id = -1
            try:
                min_id = int(inputs["input_ids"].min().item())
            except Exception:
                min_id = 0
            if min_id < 0:
                raise RuntimeError(f"TOKENIZER_MODEL_MISMATCH::{label} token id 出现负值 {min_id}")
            if limit > 0 and max_id >= limit:
                raise RuntimeError(f"TOKENIZER_MODEL_MISMATCH::{label} token id {max_id} 超过模型词表上限 {limit - 1}")
            if not move_to_device:
                return inputs
            return {k: v.to(device) if hasattr(v, "to") else v for k, v in inputs.items()}

        def _encode_prompt(prompt_text: str):
            if not str(prompt_text or "").strip():
                PROMPT_SENTINEL
            tok_kwargs = {"return_tensors": "pt"}
            max_len = _safe_model_max_length(tok)
            if max_len > 8:
                tok_kwargs["truncation"] = True
                tok_kwargs["max_length"] = max_len
            else:
                tok_kwargs["truncation"] = False
            return tok(prompt_text, **tok_kwargs)

        mode = str(template_mode or "").strip().lower()
        compat_enabled = bool(self._settings.get("gpt_oss_official_compat", True))
        allow_plain_fallback = bool(self._settings.get("gpt_oss_plain_prompt_fallback", True))
        if model_type in ("gpt_oss", "gpt-oss"):
            if mode not in ("native", "plain", "auto", "auto_fallback"):
                mode = str(self._settings.get("gate_chat_template_mode") or ("auto" if compat_enabled else "native")).strip().lower()
                if mode not in ("native", "plain", "auto", "auto_fallback"):
                    mode = "auto" if compat_enabled else "native"
            native_error = None
            if mode != "plain" and hasattr(tok, "apply_chat_template"):
                try:
                    native_inputs = tok.apply_chat_template(
                        normalized_messages,
                        add_generation_prompt=True,
                        return_tensors="pt",
                        return_dict=True,
                    )
                    return _finalize_inputs(native_inputs)
                except Exception as e:
                    native_error = e
                    if mode == "native" or not allow_plain_fallback:
                        raise
                    _runtime_log(f"gpt-oss 官方兼容回退: {label} · native -> plain :: {str(e)[:180]}")
            if mode == "native" and native_error is not None:
                raise native_error
            plain_inputs = _encode_prompt(_plain_chat_prompt(normalized_messages))
            return _finalize_inputs(plain_inputs)

        if mode == "plain":
            inputs = _encode_prompt(_plain_chat_prompt(normalized_messages))
        else:
            inputs = _encode_prompt(_safe_chat_prompt(tok, normalized_messages))
        return _finalize_inputs(inputs)

    def _load_model_and_tok(self, ref: str, force_cpu: bool = False, tokenizer_ref: Optional[str] = None, allow_4bit: Optional[bool] = None, backend_mode: Optional[str] = None):
        from transformers import AutoModelForCausalLM, AutoTokenizer
        profile = self._profile_for_mode(backend_mode or self._backend_mode(), allow_probe=not force_cpu)
        use_gpu = bool(profile["cuda"]) and not force_cpu
        tok_ref = self._resolve_ref(str(tokenizer_ref or ref))
        kw: Dict[str, Any] = {"trust_remote_code": True}
        use_bnb = False
        if use_gpu:
            want_4bit = bool(self._settings.get("use_4bit", False)) if allow_4bit is None else bool(allow_4bit)
            bnb = _maybe_bnb(want_4bit, allow_gpu=True)
            if bnb is not None:
                kw["quantization_config"] = bnb
                kw["device_map"] = "auto"
                kw["low_cpu_mem_usage"] = True
                use_bnb = True
            else:
                kw["dtype"] = profile["dtype"]
                kw["low_cpu_mem_usage"] = True
        else:
            kw["low_cpu_mem_usage"] = True
        tok = AutoTokenizer.from_pretrained(tok_ref, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(ref, **kw)
        if use_gpu and not use_bnb:
            try:
                model = model.to("cuda")
            except Exception:
                try:
                    del model
                except Exception:
                    pass
                raise
        try:
            if getattr(tok, "pad_token_id", None) is None:
                tok.pad_token = tok.eos_token or tok.unk_token
            if getattr(model.config, "pad_token_id", None) is None:
                model.config.pad_token_id = getattr(tok, "pad_token_id", None)
        except Exception:
            pass
        self._ensure_tokenizer_compat(model, tok, ref)
        model.eval()
        return model, tok

    def _load_tokenizer_only(self, ref: str):
        from transformers import AutoTokenizer
        tok_ref = self._resolve_ref(str(ref or ""))
        tok = AutoTokenizer.from_pretrained(tok_ref, trust_remote_code=True)
        return tok

    def _load_residual_meta(self, ref: str) -> Dict[str, Any]:
        p = Path(ref) / "residual_meta.json"
        data = _load_json(p, {}) or {}
        if not isinstance(data, dict):
            raise RuntimeError(f"RESIDUAL_META_INVALID::{ref}")
        return data

    def _iter_residual_files(self, ref: str) -> List[Path]:
        root = Path(ref)
        idx = root / "residual.safetensors.index.json"
        files: List[Path] = []
        if idx.exists():
            data = _load_json(idx, {}) or {}
            weight_map = dict(data.get("weight_map") or {})
            seen = []
            for rel in weight_map.values():
                p = (root / str(rel)).resolve()
                if p not in seen:
                    seen.append(p)
            files = [p for p in seen if p.exists()]
        if not files:
            files = sorted(root.glob("residual*.safetensors"))
        if not files:
            raise RuntimeError(f"RESIDUAL_FILES_MISSING::{ref}")
        return files

    def _apply_residual_to_model(self, model, residual_ref: str, label: str):
        import torch
        try:
            from safetensors.torch import load_file
        except Exception as e:
            raise RuntimeError(f"RESIDUAL_BACKEND_MISSING::{e}")
        param_map = dict(model.named_parameters())
        buffer_map = dict(model.named_buffers())
        applied = 0
        with torch.no_grad():
            for residual_file in self._iter_residual_files(residual_ref):
                shard = load_file(str(residual_file), device="cpu")
                for key, delta in shard.items():
                    target = param_map.get(key)
                    if target is None:
                        target = buffer_map.get(key)
                    if target is None:
                        continue
                    if tuple(target.shape) != tuple(delta.shape):
                        raise RuntimeError(f"RESIDUAL_SHAPE_MISMATCH::{label}::{key}::{tuple(delta.shape)}!={tuple(target.shape)}")
                    if target.device.type != "cpu" or target.dtype != delta.dtype:
                        delta = delta.to(device=target.device, dtype=target.dtype)
                    target.add_(delta)
                    applied += 1
                try:
                    del shard
                except Exception:
                    pass
        if applied <= 0:
            raise RuntimeError(f"RESIDUAL_EMPTY::{label}")
        _runtime_log(f"Residual 已应用: {label} · tensors={applied}")

    def _load_base_cpu(self):
        if self._cpu_base_model is not None:
            return self._cpu_base_model, self._cpu_base_tok
        _runtime_log(f"加载 CPU 主模型: {self.base_model_ref}")
        model, tok = self._load_model_and_tok(self.base_model_ref, force_cpu=True)
        self._cpu_base_model, self._cpu_base_tok = model, tok
        return model, tok

    def _load_base(self):
        profile = self._current_profile(allow_probe=True)
        if not profile["cuda"]:
            return self._load_base_cpu()
        if self._base_model is not None:
            return self._base_model, self._base_tok
        _runtime_log(f"加载主模型: {self.base_model_ref} · backend={'cuda' if profile['cuda'] else 'cpu'}")
        try:
            model, tok = self._load_model_and_tok(self.base_model_ref, force_cpu=False)
        except Exception as e:
            if _is_gpu_generation_error(e) or 'meta device' in str(e).lower() or 'offloaded' in str(e).lower():
                self._mark_gpu_failed(str(e))
                return self._load_base_cpu()
            raise
        self._base_model, self._base_tok = model, tok
        return model, tok

    def _expert_cache_limit(self) -> int:
        base_limit = self._expert_cache_limit()
        if bool(self._settings.get("expert_vram_queue_on_oom", True)) and self._expert_queue_mode:
            queue_limit = max(1, int(self._settings.get("expert_vram_queue_max_cached_experts", 1) or 1))
            return min(base_limit, queue_limit) if base_limit > 0 else queue_limit
        return max(1, base_limit)

    def _drop_cached_expert(self, name: str):
        obj = self._expert_cache.pop(name, None)
        try:
            if name in self._expert_order:
                self._expert_order.remove(name)
        except Exception:
            pass
        if obj is not None:
            try:
                del obj
            except Exception:
                pass
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass

    def _drop_expert_cache_except(self, keep: Optional[List[str]] = None):
        keep_set = {str(x) for x in (keep or []) if str(x)}
        for name in list(self._expert_cache.keys()):
            if name in keep_set:
                continue
            self._drop_cached_expert(name)
            _runtime_log(f"淘汰专家缓存: {name}")

    def _enter_expert_queue_mode(self, reason: str, reserve_name: str = ""):
        if not bool(self._settings.get("expert_vram_queue_on_oom", True)):
            return False
        self._expert_queue_mode = True
        self._expert_queue_reason = str(reason or "显存不足")[:240]
        if reserve_name:
            self._expert_queue_reserved = str(reserve_name)[:120]
        _runtime_log(f"检测到专家显存不足，已切换到单专家预留显存排队模式: 保留专家={self._expert_queue_reserved or '自动'} :: {self._expert_queue_reason}")
        self._drop_expert_cache_except([self._expert_queue_reserved] if self._expert_queue_reserved else [])
        return True

    def _prepare_expert_queue_slot(self, name: str):
        if not self._expert_queue_mode:
            return
        if self._expert_queue_reserved and self._expert_queue_reserved != name:
            self._drop_expert_cache_except([])
        self._expert_queue_reserved = name
        self._evict()

    def _maybe_release_expert_after_reply(self, expert_name: str = ""):
        if not self._expert_queue_mode:
            return
        if not bool(self._settings.get("expert_vram_queue_release_after_reply", False)):
            return
        if expert_name:
            self._drop_cached_expert(expert_name)
        else:
            self._drop_expert_cache_except([])
        self._expert_queue_reserved = ""

    def _release_queue_expert_between_turns(self, expert_name: str = ""):
        if not self._expert_queue_mode:
            return
        if not bool(self._settings.get("consult_queue_release_between_experts", True)):
            return
        if expert_name:
            self._drop_cached_expert(expert_name)
            _runtime_log(f"排队会诊: 已释放上一位专家显存槽位: {expert_name}")
        else:
            self._drop_expert_cache_except([])
            _runtime_log("排队会诊: 已清空专家缓存，为下一位专家腾出显存。")
        self._expert_queue_reserved = ""

    def _queue_retry_hint(self) -> str:
        if not self._expert_queue_mode:
            return ""
        name = self._expert_queue_reserved or "当前专家"
        return f"显存保护: 已进入单专家预留显存排队模式，当前按顺序仅保留 {name} 的 GPU 专家位。"

    def _evict(self):
        limit = int(self._settings.get("max_cached_experts", 1) or 1)
        while len(self._expert_cache) > limit:
            old = self._expert_order.pop(0)
            obj = self._expert_cache.pop(old, None)
            if obj is not None:
                del obj
                gc.collect()
                try:
                    import torch
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                except Exception:
                    pass
                _runtime_log(f"淘汰专家缓存: {old}")

    def _expert_backend_mode(self, expert: Optional[Dict[str, Any]] = None) -> str:
        raw = str(self._settings.get("expert_backend_mode") or "auto").strip().lower()
        if raw in ("cpu", "cpu_safe", "safe"):
            return "cpu"
        if raw in ("gpu", "force_gpu"):
            return "gpu"
        profile = self._profile_for_mode("auto", allow_probe=True)
        return "gpu" if profile["cuda"] else "cpu"

    def _probe_expert_inputs(self, model, tok, messages: List[Dict[str, str]], label: str, template_mode: Optional[str] = None):
        try:
            self._prepare_inputs(model, tok, messages, label, move_to_device=False, template_mode=template_mode)
        except Exception as e:
            raise RuntimeError(f"EXPERT_INPUT_PROBE_FAILED::{label}::{e}")

    def _expert_input_override(self, expert_name: str) -> Dict[str, Any]:
        data = self._expert_input_overrides.get(str(expert_name or "").strip(), {}) or {}
        if not isinstance(data, dict):
            return {}
        return dict(data)

    def _set_expert_input_override(self, expert_name: str, override: Optional[Dict[str, Any]] = None):
        name = str(expert_name or "").strip()
        if not name:
            return
        data = dict(override or {})
        self._expert_input_overrides[name] = data

    def _record_expert_health(self, expert_name: str, stage: str, ok: bool, detail: str = "", override: Optional[Dict[str, Any]] = None):
        name = str(expert_name or "").strip()
        if not name:
            return
        self._expert_health_status[name] = {
            "ok": bool(ok),
            "stage": str(stage or "probe")[:80],
            "detail": str(detail or "")[:240],
            "override": dict(override or {}),
            "ts": _now_iso(),
        }

    def _expert_backend_profile(self, expert: Optional[Dict[str, Any]] = None, allow_probe: bool = False) -> Tuple[str, Dict[str, Any]]:
        mode = self._expert_backend_mode(expert)
        return mode, self._profile_for_mode(mode, allow_probe=allow_probe)

    def _try_expert_runtime_fallback(self, expert: Dict[str, Any], model, tok, messages: List[Dict[str, str]], label: str, current_override: Optional[Dict[str, Any]] = None):
        name = str(expert.get("name") or expert.get("domain") or "expert")
        mode = str(self._settings.get("expert_chat_template_mode") or "auto_fallback").strip().lower()
        if mode == "auto":
            mode = "auto_fallback"
        if mode not in ("native", "plain", "auto_fallback"):
            mode = "auto_fallback"
        if mode != "auto_fallback":
            raise RuntimeError(f"EXPERT_RUNTIME_FALLBACK_DISABLED::{label}")

        current = dict(current_override or self._expert_input_override(name) or {})
        allow_plain = bool(self._settings.get("expert_fallback_plain_prompt", True))
        allow_base = bool(self._settings.get("expert_fallback_allow_base_tokenizer", True))
        kind = str(expert.get("kind") or "full").lower()
        ref = self._resolve_ref(str(expert.get("ref") or ""))
        base_ref = self._resolve_ref(str(expert.get("base_model_ref") or self.base_model_ref or ""))
        current_template = str(current.get("template_mode") or "native").strip().lower() or "native"
        current_tok_ref = self._resolve_ref(str(current.get("tokenizer_ref") or self._expert_tokenizer_ref(expert, kind, ref) or ref))

        attempts: List[Tuple[str, Any, Dict[str, Any]]] = []
        if allow_plain and current_template != "plain":
            attempts.append((
                "self_plain",
                tok,
                {
                    **current,
                    "template_mode": "plain",
                    "tokenizer_ref": current_tok_ref,
                    "fallback": "self_plain_runtime",
                },
            ))

        if allow_base and base_ref:
            resolved_base = self._resolve_ref(base_ref)
            same_as_current = False
            try:
                same_as_current = os.path.normcase(resolved_base) == os.path.normcase(current_tok_ref)
            except Exception:
                same_as_current = resolved_base == current_tok_ref
            if not same_as_current or current_template != "plain":
                alt_tok = self._load_tokenizer_only(resolved_base)
                try:
                    if getattr(alt_tok, "pad_token_id", None) is None:
                        alt_tok.pad_token = alt_tok.eos_token or alt_tok.unk_token
                except Exception:
                    pass
                self._ensure_tokenizer_compat(model, alt_tok, f"{label}:base_tokenizer")
                attempts.append((
                    "base_plain",
                    alt_tok,
                    {
                        **current,
                        "template_mode": "plain",
                        "tokenizer_ref": resolved_base,
                        "fallback": "base_plain_runtime",
                    },
                ))

        last_exc: Optional[Exception] = None
        for stage, alt_tok, override in attempts:
            try:
                self._prepare_inputs(model, alt_tok, messages, label, move_to_device=False, template_mode=override.get("template_mode"))
                self._set_expert_input_override(name, override)
                self._record_expert_health(name, stage, True, detail=f"runtime fallback via {stage}", override=override)
                try:
                    self._expert_cache[name] = (model, alt_tok)
                    if name in self._expert_order:
                        self._expert_order.remove(name)
                    self._expert_order.append(name)
                except Exception:
                    pass
                _runtime_log(f"专家输入运行期回退成功: {name} · {stage} · tokenizer={override.get('tokenizer_ref')}")
                return alt_tok, override
            except Exception as e_attempt:
                last_exc = e_attempt
                self._record_expert_health(name, stage, False, detail=str(e_attempt), override=override)
                continue
        raise last_exc or RuntimeError(f"EXPERT_RUNTIME_FALLBACK_FAILED::{label}")

    def _probe_expert_with_fallback(self, expert: Dict[str, Any], model, tok, messages: List[Dict[str, str]], label: str, kind: str, ref: str, base_ref: str, tokenizer_ref: str):
        name = str(expert.get("name") or expert.get("domain") or "expert")
        mode = str(self._settings.get("expert_chat_template_mode") or "auto_fallback").strip().lower()
        if mode == "auto":
            mode = "auto_fallback"
        if mode not in ("native", "plain", "auto_fallback"):
            mode = "auto_fallback"
        allow_plain = bool(self._settings.get("expert_fallback_plain_prompt", True))
        allow_base = bool(self._settings.get("expert_fallback_allow_base_tokenizer", True))
        if mode == "plain":
            self._probe_expert_inputs(model, tok, messages, label, template_mode="plain")
            override = {"template_mode": "plain", "tokenizer_ref": tokenizer_ref, "fallback": "forced_plain"}
            self._record_expert_health(name, "probe:forced_plain", True, detail="forced plain probe ok", override=override)
            return tok, override
        try:
            self._probe_expert_inputs(model, tok, messages, label, template_mode="native")
            override = {"template_mode": "native", "tokenizer_ref": tokenizer_ref}
            self._record_expert_health(name, "probe:native", True, detail="native probe ok", override=override)
            return tok, override
        except Exception as e_native:
            if mode != "auto_fallback" or not _is_expert_prompt_compat_error(e_native):
                raise
            last_exc = e_native
            if allow_plain:
                try:
                    self._probe_expert_inputs(model, tok, messages, label, template_mode="plain")
                    _runtime_log(f"专家输入兼容回退: {name} · self/native -> self/plain :: {str(e_native)[:160]}")
                    override = {"template_mode": "plain", "tokenizer_ref": tokenizer_ref, "fallback": "self_plain", "fallback_reason": str(e_native)[:240]}
                    self._record_expert_health(name, "probe:self_plain", True, detail=str(e_native), override=override)
                    return tok, override
                except Exception as e_plain:
                    last_exc = e_plain
            if allow_base and base_ref:
                resolved_base = self._resolve_ref(base_ref)
                resolved_tok = self._resolve_ref(tokenizer_ref)
                same_as_base = False
                try:
                    same_as_base = os.path.normcase(resolved_base) == os.path.normcase(resolved_tok)
                except Exception:
                    same_as_base = resolved_base == resolved_tok
                if not same_as_base:
                    try:
                        alt_tok = self._load_tokenizer_only(base_ref)
                        try:
                            if getattr(alt_tok, "pad_token_id", None) is None:
                                alt_tok.pad_token = alt_tok.eos_token or alt_tok.unk_token
                        except Exception:
                            pass
                        self._ensure_tokenizer_compat(model, alt_tok, f"{label}:base_tokenizer")
                        self._probe_expert_inputs(model, alt_tok, messages, label, template_mode="plain")
                        _runtime_log(f"专家输入兼容回退: {name} · self/native -> base/plain :: {str(last_exc)[:160]}")
                        override = {"template_mode": "plain", "tokenizer_ref": resolved_base, "fallback": "base_plain", "fallback_reason": str(last_exc)[:240]}
                        self._record_expert_health(name, "probe:base_plain", True, detail=str(last_exc), override=override)
                        return alt_tok, override
                    except Exception as e_base:
                        last_exc = e_base
            self._record_expert_health(name, "probe:failed", False, detail=str(last_exc))
            raise last_exc

    def _expert_tokenizer_ref(self, expert: Dict[str, Any], kind: str, ref: str) -> str:
        explicit = self._resolve_ref(str(expert.get("tokenizer_ref") or expert.get("tokenizer") or ""))
        base_ref = self._resolve_ref(str(expert.get("base_model_ref") or self.base_model_ref or ""))
        strategy = str(self._settings.get("expert_tokenizer_strategy") or "auto").strip().lower()
        if kind == "lora":
            return explicit or base_ref or ref
        if kind == "residual":
            if explicit:
                return explicit
            if strategy in ("base", "base_for_full", "prefer_base", "shared") and base_ref:
                return base_ref
            return ref
        if kind == "full":
            if strategy in ("base", "base_for_full", "prefer_base", "shared") and base_ref:
                return base_ref
            if explicit and base_ref:
                try:
                    if os.path.normcase(explicit) == os.path.normcase(base_ref):
                        explicit = ""
                except Exception:
                    pass
            return explicit or ref
        return explicit or ref




    def _load_expert(self, expert: Dict[str, Any], probe_messages: Optional[List[Dict[str, str]]] = None):
        name = str(expert.get("name") or expert.get("ref") or "expert")
        if name in self._expert_cache:
            if name in self._expert_order:
                self._expert_order.remove(name)
            self._expert_order.append(name)
            return self._expert_cache[name]
        if name in self._bad_experts:
            raise RuntimeError(f"专家 {name} 已被暂时停用: {self._bad_experts[name]}")
        kind = str(expert.get("kind") or "missing").lower()
        ref = self._resolve_ref(str(expert.get("ref") or ""))
        if kind not in ("full", "lora", "residual"):
            raise RuntimeError(f"当前仅支持 full/lora/residual 专家，收到: {kind}")
        base_ref = self._resolve_ref(str(expert.get("base_model_ref") or self.base_model_ref or ""))
        tried_queue = False
        while True:
            expert_mode, profile = self._expert_backend_profile(expert, allow_probe=True)
            use_gpu = bool(profile["cuda"]) and expert_mode == "gpu"
            if not use_gpu and expert_mode != "cpu":
                raise RuntimeError("当前为 CPU 模式，专家未启用")
            if use_gpu:
                self._prepare_expert_queue_slot(name)
            try:
                if kind == "full":
                    tok_ref = self._expert_tokenizer_ref(expert, kind, ref)
                    _runtime_log(f"按需加载完整专家: {name} · backend={'cuda' if use_gpu else 'cpu'} · tokenizer={tok_ref}")
                    model, tok = self._load_model_and_tok(ref, force_cpu=not use_gpu, tokenizer_ref=tok_ref, allow_4bit=True, backend_mode=expert_mode)
                elif kind == "lora":
                    base_ref = self._resolve_ref(str(expert.get("base_model_ref") or base_ref or self.base_model_ref))
                    if not base_ref:
                        raise RuntimeError(f"LoRA 专家缺少 base_model_ref: {name}")
                    tok_ref = self._expert_tokenizer_ref(expert, kind, ref) or base_ref
                    _runtime_log(f"按需加载 LoRA 专家: {name} · backend={'cuda' if use_gpu else 'cpu'} · tokenizer={tok_ref}")
                    model, tok = self._load_model_and_tok(base_ref, force_cpu=not use_gpu, tokenizer_ref=tok_ref, allow_4bit=True, backend_mode=expert_mode)
                    from peft import PeftModel
                    model = PeftModel.from_pretrained(model, ref)
                else:
                    meta = self._load_residual_meta(ref)
                    base_ref = self._resolve_ref(str(expert.get("base_model_ref") or meta.get("base_model_ref") or base_ref or self.base_model_ref))
                    if not base_ref:
                        raise RuntimeError(f"Residual 专家缺少 base_model_ref: {name}")
                    merged_meta = dict(meta)
                    merged_meta.update(expert)
                    tok_ref = self._expert_tokenizer_ref(merged_meta, kind, ref) or base_ref
                    if use_gpu and bool(self._settings.get("use_4bit", False)):
                        _runtime_log(f"Residual 专家暂不支持 4bit 直接加残差，已改用非量化加载: {name}")
                    _runtime_log(f"按需加载 Residual 专家: {name} · backend={'cuda' if use_gpu else 'cpu'} · tokenizer={tok_ref}")
                    model, tok = self._load_model_and_tok(base_ref, force_cpu=not use_gpu, tokenizer_ref=tok_ref, allow_4bit=False, backend_mode=expert_mode)
                    self._apply_residual_to_model(model, ref, f"expert:{name}")
                try:
                    if getattr(tok, "pad_token_id", None) is None:
                        tok.pad_token = tok.eos_token or tok.unk_token
                    if getattr(model.config, "pad_token_id", None) is None:
                        model.config.pad_token_id = getattr(tok, "pad_token_id", None)
                except Exception:
                    pass
                self._ensure_tokenizer_compat(model, tok, f"expert:{name}")
                input_override = {"template_mode": "native", "tokenizer_ref": tok_ref}
                if probe_messages:
                    tok, input_override = self._probe_expert_with_fallback(expert, model, tok, probe_messages, f"expert:{name}", kind=kind, ref=ref, base_ref=base_ref, tokenizer_ref=tok_ref)
                self._set_expert_input_override(name, input_override)
                model.eval()
                self._expert_cache[name] = (model, tok)
                self._expert_order.append(name)
                self._evict()
                return model, tok
            except Exception as e:
                if use_gpu and _is_oom_error(e) and not tried_queue and self._enter_expert_queue_mode(str(e), reserve_name=name):
                    tried_queue = True
                    try:
                        self._drop_expert_cache_except([])
                    except Exception:
                        pass
                    continue
                self._bad_experts[name] = str(e)[:240]
                raise

    def _resolve_forced_route(self, forced_route: Optional[str]) -> Tuple[str, Optional[Dict[str, Any]], str, bool]:
        raw = str(forced_route or self._settings.get("forced_route") or "auto").strip()
        if not raw:
            raw = "auto"
        low = raw.lower()
        if low in ("auto", "default", "自动", "默认"):
            return "auto", None, "", False
        if low in ("consult", "swarm", "meeting", "会诊", "会议", "多专家"):
            return "auto", None, "强制会诊模式", True
        if low in ("base", "main", "gateway", "gate", "主模型", "门控", "仅门控", "仅门控/主模型回答", "仅主模型"):
            return "base", None, "仅门控/主模型回答", False
        force_consult = False
        wanted = raw
        if low.startswith(("expert:", "consult:", "swarm:", "meeting:")):
            head, tail = raw.split(":", 1)
            wanted = tail.strip()
            if head.lower() in ("consult", "swarm", "meeting"):
                force_consult = True
        wanted_low = wanted.lower()
        exact = None
        partial = None
        for expert in self.experts:
            name = str(expert.get("name") or expert.get("domain") or expert.get("ref") or "expert").strip()
            if not name:
                continue
            nlow = name.lower()
            if wanted_low == nlow:
                exact = dict(expert)
                break
            if wanted_low in nlow or nlow in wanted_low:
                partial = dict(expert)
        chosen = exact or partial
        if chosen is not None:
            chosen.setdefault("route_score", 999.0)
            note = f"强制专家={str(chosen.get('name') or chosen.get('domain') or chosen.get('ref') or wanted)}"
            if force_consult:
                note += " · 强制会诊"
            return "expert", chosen, note, force_consult
        if force_consult:
            return "auto", None, f"指定会诊专家不存在({wanted})，改为自动会诊", True
        return "base", None, f"指定专家不存在({wanted})，已回退主模型", False

    def _conversation_key(self, conversation_id: Optional[str] = None) -> str:
        raw = str(conversation_id or "").strip()
        return raw[:128] if raw else "__global__"

    def _sticky_state(self, conversation_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        key = self._conversation_key(conversation_id)
        state = self._session_routes.get(key)
        if not state:
            return None
        ttl = max(30, int(self._settings.get("route_sticky_ttl_sec") or 900))
        if time.time() - float(state.get("ts") or 0.0) > ttl:
            self._session_routes.pop(key, None)
            return None
        turns_left = int(state.get("turns_left") or 0)
        if turns_left <= 0:
            self._session_routes.pop(key, None)
            return None
        return state

    def _remember_route(self, conversation_id: Optional[str], expert: Optional[Dict[str, Any]]):
        if expert is None:
            return
        turns = max(0, int(self._settings.get("route_sticky_turns") or 0))
        if turns <= 0:
            return
        key = self._conversation_key(conversation_id)
        self._session_routes[key] = {
            "name": str(expert.get("name") or expert.get("domain") or expert.get("ref") or "expert"),
            "domain": str(expert.get("domain") or ""),
            "ts": time.time(),
            "turns_left": turns,
        }

    def _consume_route_memory(self, conversation_id: Optional[str], used_expert: bool):
        key = self._conversation_key(conversation_id)
        state = self._session_routes.get(key)
        if not state:
            return
        if used_expert:
            state["turns_left"] = max(0, int(state.get("turns_left") or 0) - 1)
            state["ts"] = time.time()
            if int(state.get("turns_left") or 0) <= 0:
                self._session_routes.pop(key, None)
        else:
            self._session_routes.pop(key, None)

    def _is_short_base_query(self, query: str, conversation_id: Optional[str] = None) -> bool:
        q = str(query or "").strip()
        if not q:
            return True
        sticky = self._sticky_state(conversation_id)
        if sticky and q in ("继续", "接着", "然后", "细说", "展开", "再说说"):
            return False
        max_chars = max(0, int(self._settings.get("short_query_base_chars") or 0))
        if max_chars <= 0 or len(q) > max_chars:
            return False
        q_low = q.lower()
        greeting_patterns = (
            r"^(你好|您好|嗨|hi|hello|hey|在吗|在不在|早上好|晚上好|谢谢|谢了|收到|嗯|好的|ok|好的谢谢|继续)$",
        )
        if any(re.match(pat, q_low, flags=re.IGNORECASE) for pat in greeting_patterns):
            return True
        return False

    def _sticky_route_hint(self, conversation_id: Optional[str]) -> str:
        state = self._sticky_state(conversation_id)
        if not state:
            return ""
        return str(state.get("name") or "")

    def _route_candidates(self, query: str, conversation_id: Optional[str] = None) -> List[Dict[str, Any]]:
        if not bool(self._settings.get("enable_experts", True)):
            return []
        if self._is_short_base_query(query, conversation_id=conversation_id):
            return []
        sticky_name = self._sticky_route_hint(conversation_id)
        sticky_bonus = max(0.0, float(self._settings.get("route_sticky_score_bonus") or 0.0))
        cached_bonus = max(0.0, float(self._settings.get("cached_route_bonus") or 0.0))
        q = (query or "").lower()
        ranked: List[Dict[str, Any]] = []
        for expert in self.experts:
            score = float(expert.get("priority", 5) or 5) * 0.05
            matches = 0
            matched_keywords: List[str] = []
            for kw in expert.get("keywords") or []:
                kw_text = str(kw or "").strip()
                if kw_text and kw_text.lower() in q:
                    score += 2.0
                    matches += 1
                    matched_keywords.append(kw_text)
            if matches == 0:
                domain = str(expert.get("domain") or "")
                if domain and domain != "通用" and domain.lower() in q:
                    score += 0.8
            name = str(expert.get("name") or expert.get("domain") or expert.get("ref") or "expert")
            if sticky_name and name == sticky_name and matches == 0:
                cont_markers = {"继续", "接着", "然后", "展开", "细说", "再说说", "详细点", "具体点", "还有呢"}
                if (query or "").strip() in cont_markers:
                    score += max(sticky_bonus, float(self._settings.get("activation_threshold") or 1.5) + 0.2)
                else:
                    score += sticky_bonus
            if name in self._expert_cache:
                score += cached_bonus
            item = dict(expert)
            item["route_score"] = score
            item["matched_keywords"] = matched_keywords[:8]
            item["match_count"] = matches
            ranked.append(item)
        ranked.sort(key=lambda x: float(x.get("route_score") or 0.0), reverse=True)
        return ranked

    def route(self, query: str, conversation_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        threshold = float(self._settings.get("activation_threshold", 1.5) or 1.5)
        ranked = self._route_candidates(query, conversation_id=conversation_id)
        if not ranked:
            return None
        best = ranked[0]
        if float(best.get("route_score") or 0.0) < threshold:
            return None
        return dict(best)
    def _merge_messages(self, messages: List[Dict[str, str]], expert: Optional[Dict[str, Any]], user_text: str) -> List[Dict[str, str]]:
        system_parts: List[str] = []
        default_system = str(self._settings.get("system_prompt") or "").strip()
        if default_system:
            system_parts.append(default_system)
        caller_system = [str(m.get("content", "")).strip() for m in (messages or []) if m.get("role") == "system" and m.get("content")]
        if caller_system:
            system_parts.append("\n".join(caller_system))
        if expert is not None:
            desc = str(expert.get("description") or "").strip()
            if desc:
                system_parts.append(f"【专家模式】{desc}")
        kb = self._knowledge_context(user_text, expert)
        if kb:
            system_parts.append(kb)
        merged: List[Dict[str, str]] = []
        system_text = "\n\n".join([x for x in system_parts if x])
        if system_text:
            merged.append({"role": "system", "content": system_text})
        merged.extend([m for m in (messages or []) if m.get("role") != "system"])
        return merged


    def _consult_strategy(self) -> str:
        raw = str(self._settings.get("consult_strategy") or "dispute_driven").strip().lower()
        return raw if raw in {"classic", "dispute_driven"} else "dispute_driven"

    def _consult_enable_challenger(self) -> bool:
        return bool(self._settings.get("consult_enable_challenger", True))

    def _consult_risk_markers(self) -> Tuple[str, ...]:
        return (
            "起诉", "赔偿", "判刑", "合同", "侵权", "违法", "合规", "诊断", "处方", "用药", "手术", "死亡", "并发症", "数据泄露", "漏洞", "安全事故"
        )

    def _consult_conflict_markers(self) -> Tuple[str, ...]:
        return (
            "对比", "冲突", "争议", "是否", "能不能", "该不该", "利弊", "取舍", "风险", "边界", "例外", "矛盾", "反驳", "复核"
        )

    def _parse_structured_note(self, text: str) -> Dict[str, str]:
        out: Dict[str, str] = {}
        current = ""
        for raw in str(text or "").splitlines():
            line = str(raw).rstrip()
            m = re.match(r"^\s*【([^】]+)】\s*(.*)$", line)
            if m:
                current = str(m.group(1) or "").strip()
                out[current] = str(m.group(2) or "").strip()
                continue
            if current and line.strip():
                prev = out.get(current, "")
                out[current] = (prev + "\n" + line.strip()).strip() if prev else line.strip()
        return out

    def _format_structured_note_block(self, item: Dict[str, Any]) -> str:
        name = str(item.get("name") or item.get("domain") or item.get("role") or "专家")
        status = str(item.get("status") or "ok")
        if status != "ok":
            return f"### {name}\n[未成功参与] {item.get('error') or '未知原因'}"
        note = str(item.get("note") or "").strip()
        fields = self._parse_structured_note(note)
        if not fields:
            return f"### {name}\n{note or '无'}"
        lines = [f"### {name}"]
        for key in ("专业结论", "证据与规则", "不确定性", "反对意见", "建议其他专家补充", "挑战结论", "潜在冲突", "证据缺口", "主持人收束建议"):
            val = str(fields.get(key) or "").strip()
            if val:
                lines.append(f"- {key}: {val}")
        if len(lines) == 1:
            lines.append(note or "无")
        return "\n".join(lines)

    def _should_run_challenger(self, query: str, participants: List[Dict[str, Any]], consult_notes: List[Dict[str, Any]]) -> bool:
        if not self._consult_enable_challenger():
            return False
        ok_notes = [x for x in (consult_notes or []) if str((x or {}).get("status") or "") == "ok" and str((x or {}).get("role") or "") != "challenger"]
        if len(ok_notes) >= 2:
            return True
        query_text = str(query or "")
        if any(marker in query_text for marker in self._consult_conflict_markers()):
            return True
        if any(marker in query_text for marker in self._consult_risk_markers()) and len(participants or []) >= 1:
            return True
        return False

    def _build_challenger_messages(self, messages: List[Dict[str, str]], user_text: str, participants: List[Dict[str, Any]], consult_notes: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        merged = self._merge_messages(messages, None, user_text)
        roster = "、".join(str(x.get("name") or x.get("domain") or "专家") for x in participants) or "无"
        notes_text = "\n\n".join(self._format_structured_note_block(x) for x in consult_notes if str((x or {}).get("role") or "") != "challenger").strip() or "无有效专家意见。"
        prompt = (
            "你现在扮演挑战者/审核者，不直接给最终答案，而是检查专家会诊里是否存在冲突、证据缺口、越界推断或需要保守表述的地方。\n"
            "输出格式固定为：\n"
            "【挑战结论】一句话总体判断\n"
            "【潜在冲突】2-4条\n"
            "【证据缺口】2-4条\n"
            "【主持人收束建议】一句话\n"
            f"参会专家：{roster}\n\n"
            f"原始问题：{user_text}\n\n"
            f"专家意见：\n{notes_text}"
        )
        return _append_user_prompt_safely(merged, prompt)

    def _maybe_run_consult_challenger_sync(self, base_model, base_tok, messages: List[Dict[str, str]], user_text: str, participants: List[Dict[str, Any]], consult_notes: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if not self._should_run_challenger(user_text, participants, consult_notes):
            return None
        challenger_messages = self._build_challenger_messages(messages, user_text, participants, consult_notes)
        note = self._generate(base_model, base_tok, challenger_messages, label="consult:challenger", overrides=self._consult_note_overrides())
        return {
            "name": "挑战者审查",
            "domain": "审查",
            "role": "challenger",
            "status": "ok",
            "note": note,
            "visible": False,
        }

    def _consult_trigger_markers(self) -> Tuple[str, ...]:
        return (
            "同时", "并且", "结合", "综合", "多角度", "多视角", "交叉", "会诊", "会议", "讨论", "互补", "分别", "对比", "权衡", "兼顾"
        )

    def _should_consult(self, query: str, primary: Optional[Dict[str, Any]], ranked: List[Dict[str, Any]], force_mode: str, force_consult: bool = False) -> Tuple[bool, str]:
        mode = str(self._settings.get("swarm_mode") or "single").strip().lower()
        strategy = self._consult_strategy()
        if force_consult:
            return True, "手动强制会诊"
        if mode == "single":
            return False, "swarm_mode=single"
        if primary is None:
            return False, "未命中主专家"
        if mode == "consult_always":
            return True, "swarm_mode=consult_always"
        query_text = str(query or "")
        query_low = query_text.lower()
        if any(marker in query_text for marker in self._consult_trigger_markers()):
            return True, "问题含跨域/会诊信号"
        domains = []
        for item in ranked[: min(4, len(ranked))]:
            domain = str(item.get("domain") or "").strip()
            if not domain:
                continue
            if domain in query_text or domain.lower() in query_low:
                domains.append(domain)
        if len(set(domains)) >= 2:
            return True, "问题显式提及多个领域"
        threshold = float(self._settings.get("activation_threshold", 1.5) or 1.5)
        primary_score = float(primary.get("route_score") or 0.0)
        secondary_ratio = float(self._settings.get("consult_secondary_ratio") or 0.65)
        margin_max = max(0.02, min(float(self._settings.get("consult_primary_margin_max") or 0.18), 1.0))
        secondary_best = 0.0
        for item in ranked:
            if str(item.get("name") or "") == str(primary.get("name") or ""):
                continue
            score = float(item.get("route_score") or 0.0)
            secondary_best = max(secondary_best, score)
            if score >= threshold and score >= max(primary_score * secondary_ratio, threshold):
                return True, "存在高分辅专家"
        if strategy == "dispute_driven":
            if primary_score > 0 and secondary_best > 0 and (primary_score - secondary_best) <= margin_max:
                return True, "主辅专家分差较小，适合争议驱动会诊"
            if any(marker in query_text for marker in self._consult_conflict_markers()):
                return True, "问题含争议/取舍信号"
            if any(marker in query_text for marker in self._consult_risk_markers()) and primary_score < threshold * 1.4:
                return True, "高风险问题且主专家优势不足"
            if force_mode == "expert" and bool(self._settings.get("consult_force_forced_expert", False)):
                return True, "强制专家时允许辅专家会诊"
            return False, "争议驱动模式下未发现必须会诊信号"
        if force_mode == "expert" and bool(self._settings.get("consult_force_forced_expert", False)):
            return True, "强制专家时允许辅专家会诊"
        return False, "主专家置信度足够高"

    def _pick_consult_experts(self, query: str, primary: Optional[Dict[str, Any]], ranked: List[Dict[str, Any]], force_mode: str, force_consult: bool = False) -> Tuple[List[Dict[str, Any]], List[str]]:
        notes: List[str] = []
        if primary is None and ranked:
            primary = dict(ranked[0])
            notes.append("会诊判定: 未给出主专家，已使用最高分候选作为主专家。")
        if primary is None:
            return [], ["会诊判定: 无主专家，跳过会诊。"]
        should, reason = self._should_consult(query, primary, ranked, force_mode, force_consult=force_consult)
        notes.append(f"会诊判定: {'启用' if should else '关闭'} · {reason}")
        if not should:
            return [dict(primary)], notes
        limit = max(1, min(int(self._settings.get("consult_max_experts") or 2), 4))
        threshold = float(self._settings.get("activation_threshold", 1.5) or 1.5)
        primary_name = str(primary.get("name") or primary.get("domain") or "expert")
        participants: List[Dict[str, Any]] = [dict(primary)]
        for item in ranked:
            name = str(item.get("name") or item.get("domain") or "expert")
            if name == primary_name:
                continue
            score = float(item.get("route_score") or 0.0)
            domain = str(item.get("domain") or "").strip()
            domain_hit = bool(domain and domain in (query or ""))
            allow = False
            if force_consult:
                allow = True
            elif score >= threshold * 0.8 or domain_hit or bool(item.get("matched_keywords")):
                allow = True
            if allow:
                participants.append(dict(item))
            if len(participants) >= limit:
                break
        dedup: List[Dict[str, Any]] = []
        seen = set()
        for item in participants:
            name = str(item.get("name") or item.get("domain") or item.get("ref") or "expert")
            if name in seen:
                continue
            seen.add(name)
            dedup.append(item)
        notes.append("参会专家: " + " / ".join(str(x.get("name") or x.get("domain") or "expert") for x in dedup))
        return dedup, notes

    def _build_expert_consult_messages(self, messages: List[Dict[str, str]], expert: Dict[str, Any], user_text: str, participants: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        merged = self._merge_messages(messages, expert, user_text)
        domain = str(expert.get("domain") or "通用")
        name = str(expert.get("name") or domain or "专家")
        peers = [str(x.get("name") or x.get("domain") or "专家") for x in participants if str(x.get("name") or x.get("domain") or "专家") != name]
        prompt = (
            f"你正在参加多专家会诊。你的身份是{name}，领域为{domain}。\n"
            "请只从你的专业角度提交一份可审计的专家合同，不要代替主持人做总判断。\n"
            "输出格式固定为：\n"
            "【专业结论】一句话结论\n"
            "【证据与规则】2-4条\n"
            "【不确定性】2-4条\n"
            "【反对意见】1-3条，指出你最担心的反例/例外\n"
            "【建议其他专家补充】一句话\n"
            f"其他参会专家：{('、'.join(peers) if peers else '无')}\n"
            f"原始问题：{user_text}"
        )
        return _append_user_prompt_safely(merged, prompt)

    def _build_synthesis_messages(self, messages: List[Dict[str, str]], user_text: str, participants: List[Dict[str, Any]], expert_notes: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        merged = self._merge_messages(messages, None, user_text)
        roster = "、".join(str(x.get("name") or x.get("domain") or "专家") for x in participants) or "无"
        challenger = next((x for x in (expert_notes or []) if str((x or {}).get("role") or "") == "challenger"), None)
        expert_blocks = [self._format_structured_note_block(item) for item in (expert_notes or []) if str((item or {}).get("role") or "") != "challenger"]
        notes_text = "\n\n".join([x for x in expert_blocks if x]).strip() or "无有效专家意见。"
        challenger_text = self._format_structured_note_block(challenger) if challenger else "无挑战者审查。"
        prompt = (
            "你是门控协调模型/会议主持人。下面给出用户原始问题、专家合同式意见以及挑战者审查。\n"
            "请输出最终答案，并把多专家观点互补融合，而不是逐条复述。\n"
            "要求：\n"
            "1. 先给直接结论；\n"
            "2. 再写【专家互补要点】；\n"
            "3. 若挑战者指出冲突/缺口，必须在【风险与边界】中吸收；\n"
            "4. 不要伪造不存在的专家意见；\n"
            "5. 若证据不足，明确保守表达。\n"
            f"参会专家：{roster}\n\n"
            f"原始问题：{user_text}\n\n"
            f"专家合同：\n{notes_text}\n\n"
            f"挑战者审查：\n{challenger_text}"
        )
        return _append_user_prompt_safely(merged, prompt)

    def _consult_dispatch_mode(self, participants: Optional[List[Dict[str, Any]]] = None) -> Tuple[str, str]:
        raw = str(self._settings.get("consult_dispatch_mode") or "auto").strip().lower()
        participants = participants or []
        count = len(participants)
        if count <= 1:
            return "manual_queue", "单专家无需并行，会诊按顺序执行"
        profile = self._current_profile(allow_probe=False)
        if raw == "manual_queue":
            return "manual_queue", "手动切换为排队模式"
        if raw == "parallel":
            if bool(profile.get("cuda")) and not bool(self._settings.get("consult_parallel_allow_gpu", False)):
                return "manual_queue", "同时讨论模式在单卡/同 GPU 环境下风险较高，已自动降级为排队模式"
            return "parallel", "已启用同时讨论模式"
        # auto
        if bool(profile.get("cuda")):
            return "manual_queue", "auto: GPU 环境默认排队，优先避免显存争抢"
        return "parallel", "auto: CPU/安全后端下启用同时讨论"

    def _maybe_enable_manual_queue_for_consult(self, participants: List[Dict[str, Any]], reason: str = "") -> None:
        mode, _ = self._consult_dispatch_mode(participants)
        if mode != "manual_queue":
            return
        profile = self._current_profile(allow_probe=False)
        if not bool(profile.get("cuda")):
            return
        reserve = str((participants[0] or {}).get("name") or (participants[0] or {}).get("domain") or "") if participants else ""
        self._expert_queue_mode = True
        self._expert_queue_reason = (reason or "手动切换为排队模式")[:240]
        self._expert_queue_reserved = reserve[:120]
        keep = [reserve] if reserve else []
        self._drop_expert_cache_except(keep)

    def _consult_parallel_worker(self, expert: Dict[str, Any], model, tok, consult_messages: List[Dict[str, str]]) -> Dict[str, Any]:
        name = str(expert.get("name") or expert.get("domain") or "expert")
        note = self._generate_expert_sync(expert, model, tok, consult_messages, label=f"consult:{name}", overrides=self._consult_note_overrides())
        return {"name": name, "domain": str(expert.get("domain") or ""), "status": "ok", "note": note, "visible": True}

    def _run_consultation_sync_parallel(self, base_model, base_tok, messages: List[Dict[str, str]], user_text: str, participants: List[Dict[str, Any]], route_trace: List[str]) -> Tuple[str, str, float, List[Dict[str, Any]], bool, str]:
        consult_notes: List[Dict[str, Any]] = []
        fallback_reason = ""
        loaded: List[Tuple[Dict[str, Any], Any, Any, List[Dict[str, str]]]] = []
        route_trace.append("会诊调度: 已启用同时讨论模式。")
        for expert in participants:
            name = str(expert.get("name") or expert.get("domain") or "expert")
            route_trace.append(f"会诊流程: 正在预加载 {name}。")
            try:
                consult_messages = self._build_expert_consult_messages(messages, expert, user_text, participants)
                model, tok = self._load_expert(expert, probe_messages=consult_messages)
                loaded.append((expert, model, tok, consult_messages))
            except Exception as e:
                msg = str(e)
                if _is_gpu_generation_error(e):
                    self._mark_expert_failed(name, msg)
                consult_notes.append({"name": name, "domain": str(expert.get("domain") or ""), "status": "error", "error": msg})
                route_trace.append(f"会诊流程: {name} 预加载失败，已跳过。原因: {msg[:160]}")
        if loaded:
            max_workers = max(1, min(len(loaded), 4))
            futures = {}
            with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="consult") as pool:
                for expert, model, tok, consult_messages in loaded:
                    futures[pool.submit(self._consult_parallel_worker, expert, model, tok, consult_messages)] = expert
                results_map: Dict[str, Dict[str, Any]] = {}
                for fut in as_completed(futures):
                    expert = futures[fut]
                    name = str(expert.get("name") or expert.get("domain") or "expert")
                    try:
                        item = fut.result()
                        results_map[name] = item
                        route_trace.append(f"会诊流程: {name} 已提交意见。")
                    except Exception as e:
                        msg = str(e)
                        if _is_gpu_generation_error(e):
                            self._mark_expert_failed(name, msg)
                        results_map[name] = {"name": name, "domain": str(expert.get("domain") or ""), "status": "error", "error": msg}
                        route_trace.append(f"会诊流程: {name} 参与失败，已跳过。原因: {msg[:160]}")
            ordered_names = [str((expert or {}).get("name") or (expert or {}).get("domain") or "expert") for expert, _, _, _ in loaded]
            for name in ordered_names:
                if name in results_map:
                    consult_notes.append(results_map[name])
        ok_notes = [x for x in consult_notes if x.get("status") == "ok"]
        if not ok_notes:
            answer = self._generate(base_model, base_tok, self._merge_messages(messages, None, user_text), label="base:consult-empty")
            route_trace.append("会诊流程: 所有专家意见均失败，已回退主模型直接作答。")
            return answer, "base:consult-empty", 0.0, consult_notes, False, fallback_reason
        challenger_item = None
        try:
            challenger_item = self._maybe_run_consult_challenger_sync(base_model, base_tok, messages, user_text, participants, consult_notes)
        except Exception as e:
            route_trace.append(f"挑战者审查: 运行失败，已忽略。原因: {str(e)[:160]}")
        if challenger_item:
            consult_notes.append(challenger_item)
            route_trace.append("挑战者审查: 已完成对专家意见的冲突/缺口检查。")
        synth_messages = self._build_synthesis_messages(messages, user_text, participants, consult_notes)
        try:
            answer = self._generate(base_model, base_tok, synth_messages, label="consult:synth", overrides=self._consult_synth_overrides())
            route_name = "consult:" + "+".join(str(x.get("name") or x.get("domain") or "expert") for x in participants)
            route_score = max(float(x.get("route_score") or 0.0) for x in participants)
            route_trace.append("会诊流程: 主持模型已完成综合。")
            for item in participants:
                self._maybe_release_expert_after_reply(str(item.get("name") or item.get("domain") or "expert"))
            return answer, route_name, route_score, consult_notes, False, fallback_reason
        except Exception as e:
            fallback_reason = str(e)
            used_cpu = False
            if _is_gpu_generation_error(e):
                answer, route_name, route_score = self._safe_cpu_fallback(e, messages, user_text)
                used_cpu = True
                route_trace.append("会诊流程: 综合阶段 GPU 失败，已回退 CPU 主模型完成回答。")
                return answer, route_name, route_score, consult_notes, used_cpu, fallback_reason
            raise

    def _run_consultation_stream_parallel(self, base_model, base_tok, messages: List[Dict[str, str]], user_text: str, participants: List[Dict[str, Any]], route_trace: List[str]) -> Generator[Dict[str, Any], None, Tuple[str, str, float, List[Dict[str, Any]], bool, str]]:
        consult_notes: List[Dict[str, Any]] = []
        fallback_reason = ""
        loaded: List[Tuple[Dict[str, Any], Any, Any, List[Dict[str, str]]]] = []
        yield {"event": "meeting", "text": "会诊调度: 已启用同时讨论模式。"}
        yield {"event": "trace", "stage": "consult_dispatch", "text": "会诊调度: 已启用同时讨论模式。流式界面将按专家完成顺序展示纪要。"}
        for expert in participants:
            name = str(expert.get("name") or expert.get("domain") or "expert")
            yield {"event": "status", "text": f"正在预加载专家 {name}..."}
            yield {"event": "trace", "stage": "consult", "text": f"会诊流程: 正在预加载 {name}。"}
            try:
                consult_messages = self._build_expert_consult_messages(messages, expert, user_text, participants)
                model, tok = self._load_expert(expert, probe_messages=consult_messages)
                loaded.append((expert, model, tok, consult_messages))
                if self._show_expert_logs():
                    yield {"event": "expert_log_begin", "expert": name, "domain": str(expert.get("domain") or ""), "mode": "consult_parallel", "text": f"{name} 已进入同时讨论。"}
            except Exception as e:
                msg = str(e)
                if _is_gpu_generation_error(e):
                    self._mark_expert_failed(name, msg)
                consult_notes.append({"name": name, "domain": str(expert.get("domain") or ""), "status": "error", "error": msg})
                yield {"event": "trace", "stage": "consult", "text": f"会诊流程: {name} 预加载失败，已跳过。原因: {msg[:160]}"}
        if loaded:
            max_workers = max(1, min(len(loaded), 4))
            futures = {}
            with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="consult") as pool:
                for expert, model, tok, consult_messages in loaded:
                    futures[pool.submit(self._consult_parallel_worker, expert, model, tok, consult_messages)] = expert
                results_map: Dict[str, Dict[str, Any]] = {}
                for fut in as_completed(futures):
                    expert = futures[fut]
                    name = str(expert.get("name") or expert.get("domain") or "expert")
                    try:
                        item = fut.result()
                        results_map[name] = item
                        note = str(item.get("note") or "")
                        if self._show_expert_logs():
                            if note:
                                yield {"event": "expert_log_delta", "expert": name, "domain": str(expert.get("domain") or ""), "mode": "consult_parallel", "text": note}
                            yield {"event": "expert_log_done", "expert": name, "domain": str(expert.get("domain") or ""), "mode": "consult_parallel", "text": note}
                        yield {"event": "meeting", "text": f"{name} 已提交会诊意见。"}
                        yield {"event": "trace", "stage": "consult", "text": f"会诊流程: {name} 已提交意见。"}
                    except Exception as e:
                        msg = str(e)
                        if _is_gpu_generation_error(e):
                            self._mark_expert_failed(name, msg)
                        results_map[name] = {"name": name, "domain": str(expert.get("domain") or ""), "status": "error", "error": msg}
                        yield {"event": "trace", "stage": "consult", "text": f"会诊流程: {name} 参与失败，已跳过。原因: {msg[:160]}"}
            ordered_names = [str((expert or {}).get("name") or (expert or {}).get("domain") or "expert") for expert, _, _, _ in loaded]
            for name in ordered_names:
                if name in results_map:
                    consult_notes.append(results_map[name])
        ok_notes = [x for x in consult_notes if x.get("status") == "ok"]
        if not ok_notes:
            yield {"event": "trace", "stage": "consult", "text": "会诊流程: 所有专家意见均失败，已回退主模型直接作答。"}
            full_text = ""
            for piece in self._generate_stream(base_model, base_tok, self._merge_messages(messages, None, user_text), label="base:consult-empty"):
                full_text += piece
                yield {"event": "delta", "text": piece, "route": "base:consult-empty"}
            return full_text, "base:consult-empty", 0.0, consult_notes, False, fallback_reason
        try:
            challenger_item = self._maybe_run_consult_challenger_sync(base_model, base_tok, messages, user_text, participants, consult_notes)
        except Exception as e:
            challenger_item = None
            yield {"event": "trace", "stage": "challenger", "text": f"挑战者审查失败，已忽略。原因: {str(e)[:160]}"}
        if challenger_item:
            consult_notes.append(challenger_item)
            yield {"event": "trace", "stage": "challenger", "text": "挑战者审查已完成，将把冲突与证据缺口并入最终整合。"}
        yield {"event": "status", "text": "正在综合多位专家意见..."}
        yield {"event": "synthesis", "text": "主持模型正在综合各专家合同与挑战者审查。"}
        synth_messages = self._build_synthesis_messages(messages, user_text, participants, consult_notes)
        full_text = ""
        try:
            for piece in self._generate_stream(base_model, base_tok, synth_messages, label="consult:synth", overrides=self._consult_synth_overrides()):
                full_text += piece
                yield {"event": "delta", "text": piece, "route": "consult"}
            route_name = "consult:" + "+".join(str(x.get("name") or x.get("domain") or "expert") for x in participants)
            route_score = max(float(x.get("route_score") or 0.0) for x in participants)
            for item in participants:
                self._maybe_release_expert_after_reply(str(item.get("name") or item.get("domain") or "expert"))
            return full_text, route_name, route_score, consult_notes, False, fallback_reason
        except Exception as e:
            fallback_reason = str(e)
            if _is_gpu_generation_error(e):
                yield {"event": "trace", "stage": "consult", "text": "会诊流程: 综合阶段 GPU 失败，已回退 CPU 主模型完成回答。"}
                answer, route_name, route_score = self._safe_cpu_fallback(e, messages, user_text)
                yield {"event": "delta", "text": answer, "route": route_name}
                return answer, route_name, route_score, consult_notes, True, fallback_reason
            raise

    def _thinking_transparency(self) -> str:
        mode = str(self._settings.get("thinking_transparency") or "structured").strip().lower()
        return mode if mode in ("off", "structured") else "structured"

    def _show_expert_logs(self) -> bool:
        return self._thinking_transparency() != "off"

    def _expert_worklog_overrides(self) -> Dict[str, Any]:
        temp = max(0.0, min(float(self._settings.get("expert_worklog_temperature") or 0.15), 2.0))
        return {
            "max_new_tokens": int(self._settings.get("expert_worklog_max_new_tokens") or 192),
            "do_sample": temp > 1e-5,
            "temperature": max(temp, 1e-5),
            "top_p": 0.95 if temp > 1e-5 else 1.0,
            "repetition_penalty": 1.0,
        }

    def _build_expert_worklog_messages(self, messages: List[Dict[str, str]], expert: Dict[str, Any], user_text: str) -> List[Dict[str, str]]:
        merged = self._merge_messages(messages, expert, user_text)
        domain = str(expert.get("domain") or "通用")
        name = str(expert.get("name") or domain or "专家")
        prompt = (
            f"你现在不是直接给最终答案，而是在前台公开展示你的工作日志。你的身份是{name}，领域为{domain}。\n"
            "请输出一份简洁、可审计、可公开展示的专家工作日志，不要泄露无结构的内心独白。\n"
            "输出格式固定为：\n"
            "【当前任务】一句话\n"
            "【已发现要点】2-4条\n"
            "【依据与线索】2-4条\n"
            "【当前置信度】低/中/高\n"
            "【阶段性结论】一句话\n"
            "要求：\n"
            "1. 只展示对用户有帮助的分析步骤；\n"
            "2. 简洁、清楚、可验证；\n"
            "3. 不要直接给最终完整答案；\n"
            f"原始问题：{user_text}"
        )
        return _append_user_prompt_safely(merged, prompt)

    def _run_consultation_sync(self, base_model, base_tok, messages: List[Dict[str, str]], user_text: str, participants: List[Dict[str, Any]], route_trace: List[str]) -> Tuple[str, str, float, List[Dict[str, Any]], bool, str]:
        dispatch_mode, dispatch_reason = self._consult_dispatch_mode(participants)
        route_trace.append(f"会诊调度: 模式={dispatch_mode} · {dispatch_reason}")
        if dispatch_mode == "manual_queue":
            self._maybe_enable_manual_queue_for_consult(participants, reason=dispatch_reason)
        else:
            return self._run_consultation_sync_parallel(base_model, base_tok, messages, user_text, participants, route_trace)
        consult_notes: List[Dict[str, Any]] = []
        fallback_reason = ""
        for expert in participants:
            name = str(expert.get("name") or expert.get("domain") or "expert")
            route_trace.append(f"会诊流程: 正在征询 {name}。")
            model = None
            tok = None
            consult_messages = None
            try:
                consult_messages = self._build_expert_consult_messages(messages, expert, user_text, participants)
                model, tok = self._load_expert(expert, probe_messages=consult_messages)
                note = self._generate_expert_sync(expert, model, tok, consult_messages, label=f"consult:{name}", overrides=self._consult_note_overrides())
                consult_notes.append({"name": name, "domain": str(expert.get("domain") or ""), "status": "ok", "note": note, "visible": True})
                route_trace.append(f"会诊流程: {name} 已提交意见。")
            except Exception as e:
                msg = str(e)
                if _is_gpu_generation_error(e):
                    self._mark_expert_failed(name, msg)
                consult_notes.append({"name": name, "domain": str(expert.get("domain") or ""), "status": "error", "error": msg})
                route_trace.append(f"会诊流程: {name} 参与失败，已跳过。原因: {msg[:160]}")
            finally:
                if dispatch_mode == "manual_queue":
                    try:
                        del model
                    except Exception:
                        pass
                    try:
                        del tok
                    except Exception:
                        pass
                    try:
                        del consult_messages
                    except Exception:
                        pass
                    gc.collect()
                    try:
                        import torch
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()
                    except Exception:
                        pass
                    self._release_queue_expert_between_turns(name)
                    route_trace.append(f"会诊流程: 已释放 {name} 的显存占用，准备下一位专家。")
        ok_notes = [x for x in consult_notes if x.get("status") == "ok"]
        if not ok_notes:
            answer = self._generate(base_model, base_tok, self._merge_messages(messages, None, user_text), label="base:consult-empty")
            route_trace.append("会诊流程: 所有专家意见均失败，已回退主模型直接作答。")
            return answer, "base:consult-empty", 0.0, consult_notes, False, fallback_reason
        challenger_item = None
        try:
            challenger_item = self._maybe_run_consult_challenger_sync(base_model, base_tok, messages, user_text, participants, consult_notes)
        except Exception as e:
            route_trace.append(f"挑战者审查: 运行失败，已忽略。原因: {str(e)[:160]}")
        if challenger_item:
            consult_notes.append(challenger_item)
            route_trace.append("挑战者审查: 已完成对专家意见的冲突/缺口检查。")
        synth_messages = self._build_synthesis_messages(messages, user_text, participants, consult_notes)
        try:
            answer = self._generate(base_model, base_tok, synth_messages, label="consult:synth", overrides=self._consult_synth_overrides())
            route_name = "consult:" + "+".join(str(x.get("name") or x.get("domain") or "expert") for x in participants)
            route_score = max(float(x.get("route_score") or 0.0) for x in participants)
            route_trace.append("会诊流程: 主持模型已完成综合。")
            for item in participants:
                self._maybe_release_expert_after_reply(str(item.get("name") or item.get("domain") or "expert"))
            return answer, route_name, route_score, consult_notes, False, fallback_reason
        except Exception as e:
            fallback_reason = str(e)
            used_cpu = False
            if _is_gpu_generation_error(e):
                answer, route_name, route_score = self._safe_cpu_fallback(e, messages, user_text)
                used_cpu = True
                route_trace.append("会诊流程: 综合阶段 GPU 失败，已回退 CPU 主模型完成回答。")
                return answer, route_name, route_score, consult_notes, used_cpu, fallback_reason
            raise

    def _run_consultation_stream(self, base_model, base_tok, messages: List[Dict[str, str]], user_text: str, participants: List[Dict[str, Any]], route_trace: List[str]) -> Generator[Dict[str, Any], None, Tuple[str, str, float, List[Dict[str, Any]], bool, str]]:
        dispatch_mode, dispatch_reason = self._consult_dispatch_mode(participants)
        route_trace.append(f"会诊调度: 模式={dispatch_mode} · {dispatch_reason}")
        yield {"event": "trace", "stage": "consult_dispatch", "text": f"会诊调度: 模式={dispatch_mode} · {dispatch_reason}"}
        if dispatch_mode == "manual_queue":
            self._maybe_enable_manual_queue_for_consult(participants, reason=dispatch_reason)
        else:
            result = yield from self._run_consultation_stream_parallel(base_model, base_tok, messages, user_text, participants, route_trace)
            return result
        consult_notes: List[Dict[str, Any]] = []
        fallback_reason = ""
        for expert in participants:
            name = str(expert.get("name") or expert.get("domain") or "expert")
            yield {"event": "status", "text": f"正在征询专家 {name}..."}
            yield {"event": "trace", "stage": "consult", "text": f"会诊流程: 正在征询 {name}。"}
            model = None
            tok = None
            consult_messages = None
            try:
                consult_messages = self._build_expert_consult_messages(messages, expert, user_text, participants)
                model, tok = self._load_expert(expert, probe_messages=consult_messages)
                note = ""
                if self._show_expert_logs():
                    yield {"event": "expert_log_begin", "expert": name, "domain": str(expert.get("domain") or ""), "mode": "consult", "text": f"{name} 正在公开整理会诊意见。"}
                    try:
                        for piece in self._generate_expert_stream(expert, model, tok, consult_messages, label=f"consult:{name}", overrides=self._consult_note_overrides()):
                            note += piece
                            yield {"event": "expert_log_delta", "expert": name, "domain": str(expert.get("domain") or ""), "mode": "consult", "text": piece}
                    except Exception as inner_e:
                        if _is_oom_error(inner_e) and not note and self._enter_expert_queue_mode(str(inner_e), reserve_name=name):
                            yield {"event": "trace", "stage": "expert_queue", "text": f"检测到专家显存不足，已切换到单专家预留显存排队模式，并重试 {name} 的会诊意见。"}
                            for piece in self._generate_expert_stream(expert, model, tok, consult_messages, label=f"consult:{name}", overrides=self._consult_note_overrides()):
                                note += piece
                                yield {"event": "expert_log_delta", "expert": name, "domain": str(expert.get("domain") or ""), "mode": "consult", "text": piece}
                        else:
                            raise inner_e
                    yield {"event": "expert_log_done", "expert": name, "domain": str(expert.get("domain") or ""), "mode": "consult", "text": note}
                else:
                    note = self._generate_expert_sync(expert, model, tok, consult_messages, label=f"consult:{name}", overrides=self._consult_note_overrides())
                consult_notes.append({"name": name, "domain": str(expert.get("domain") or ""), "status": "ok", "note": note, "visible": True})
                route_trace.append(f"会诊流程: {name} 已提交意见。")
                yield {"event": "meeting", "text": f"{name} 已提交会诊意见。"}
                yield {"event": "trace", "stage": "consult", "text": f"会诊流程: {name} 已提交意见。"}
            except Exception as e:
                msg = str(e)
                if _is_gpu_generation_error(e):
                    self._mark_expert_failed(name, msg)
                consult_notes.append({"name": name, "domain": str(expert.get("domain") or ""), "status": "error", "error": msg})
                route_trace.append(f"会诊流程: {name} 参与失败，已跳过。原因: {msg[:160]}")
                yield {"event": "trace", "stage": "consult", "text": f"会诊流程: {name} 参与失败，已跳过。原因: {msg[:160]}"}
            finally:
                if dispatch_mode == "manual_queue":
                    try:
                        del model
                    except Exception:
                        pass
                    try:
                        del tok
                    except Exception:
                        pass
                    try:
                        del consult_messages
                    except Exception:
                        pass
                    gc.collect()
                    try:
                        import torch
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()
                    except Exception:
                        pass
                    self._release_queue_expert_between_turns(name)
                    route_trace.append(f"会诊流程: 已释放 {name} 的显存占用，准备下一位专家。")
                    yield {"event": "trace", "stage": "consult", "text": f"会诊流程: 已释放 {name} 的显存占用，准备下一位专家。"}
        ok_notes = [x for x in consult_notes if x.get("status") == "ok"]
        if not ok_notes:
            yield {"event": "trace", "stage": "consult", "text": "会诊流程: 所有专家意见均失败，已回退主模型直接作答。"}
            full_text = ""
            for piece in self._generate_stream(base_model, base_tok, self._merge_messages(messages, None, user_text), label="base:consult-empty"):
                full_text += piece
                yield {"event": "delta", "text": piece, "route": "base:consult-empty"}
            return full_text, "base:consult-empty", 0.0, consult_notes, False, fallback_reason
        yield {"event": "status", "text": "专家意见已收集，正在综合会诊结果..."}
        yield {"event": "meeting", "text": "专家意见已收集，主持模型开始整理共识与分歧。"}
        synth_messages = self._build_synthesis_messages(messages, user_text, participants, consult_notes)
        try:
            full_text = ""
            yield {"event": "synthesis", "text": "主持模型正在综合各专家的公开意见。"}
            for piece in self._generate_stream(base_model, base_tok, synth_messages, label="consult:synth", overrides=self._consult_synth_overrides()):
                full_text += piece
                yield {"event": "delta", "text": piece, "route": "consult"}
            route_name = "consult:" + "+".join(str(x.get("name") or x.get("domain") or "expert") for x in participants)
            route_score = max(float(x.get("route_score") or 0.0) for x in participants)
            route_trace.append("会诊流程: 主持模型已完成综合。")
            for item in participants:
                self._maybe_release_expert_after_reply(str(item.get("name") or item.get("domain") or "expert"))
            return full_text, route_name, route_score, consult_notes, False, fallback_reason
        except Exception as e:
            fallback_reason = str(e)
            if _is_gpu_generation_error(e):
                yield {"event": "status", "text": "综合阶段 GPU 出错，正在回退 CPU 安全模式..."}
                answer, route_name, route_score = self._safe_cpu_fallback(e, messages, user_text)
                route_trace.append("会诊流程: 综合阶段 GPU 失败，已回退 CPU 主模型完成回答。")
                return answer, route_name, route_score, consult_notes, True, fallback_reason
            raise

    def _route_trace(self, query: str, route: Optional[Dict[str, Any]], route_name: str, route_score: float, *, selected: bool, fallback_reason: str = "", used_cpu: bool = False, knowledge_hits: int = 0, override_note: str = "", sticky_note: str = "") -> List[str]:
        traces: List[str] = []
        short_q = (query or "").strip().replace("\n", " ")
        if short_q:
            traces.append(f"问题摘要: {short_q[:120]}")
        traces.append(f"后端模式: {self._backend_mode()} · 专家开关={'开启' if bool(self._settings.get('enable_experts', True)) else '关闭'}")
        traces.append(f"知识检索: 命中 {int(knowledge_hits or 0)} 条可用参考（共享 / 主模型 / 当前专家范围内）。")
        if override_note:
            traces.append(f"人工指定: {override_note}")
        if sticky_note:
            traces.append(f"会话粘滞: {sticky_note}")
        queue_hint = self._queue_retry_hint()
        if queue_hint:
            traces.append(queue_hint)
        if route is None:
            traces.append("路由判断: 未命中专家，直接使用主模型。")
        else:
            kws = ", ".join([str(x) for x in (route.get("keywords") or [])[:6] if str(x).strip()])
            domain = str(route.get("domain") or "通用")
            traces.append(f"路由判断: 命中候选专家 {route_name} · 域={domain} · 分数={route_score:.2f}")
            if kws:
                traces.append(f"命中关键词参考: {kws}")
            if selected:
                traces.append(f"执行策略: 已启用专家 {route_name} 参与回答。")
            else:
                traces.append("执行策略: 本轮未实际启用专家，改由主模型完成回答。")
        if fallback_reason:
            traces.append(f"回退原因: {fallback_reason}")
        traces.append("设备策略: CPU 回答。" if used_cpu else "设备策略: 按当前后端模式生成。")
        return traces

    def _consult_note_overrides(self) -> Dict[str, Any]:
        temp = max(0.0, min(float(self._settings.get("consult_note_temperature") or 0.2), 2.0))
        return {
            "max_new_tokens": int(self._settings.get("consult_note_max_new_tokens") or 256),
            "do_sample": temp > 1e-5,
            "temperature": max(temp, 1e-5),
            "top_p": 0.95 if temp > 1e-5 else 1.0,
            "repetition_penalty": 1.0,
        }

    def _consult_synth_overrides(self) -> Dict[str, Any]:
        return {
            "max_new_tokens": int(self._settings.get("consult_synth_max_new_tokens") or 768),
            "do_sample": False,
            "temperature": 1.0,
            "top_p": 1.0,
            "repetition_penalty": 1.0,
        }

    def _generation_kwargs(self, tok, overrides: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        pad_id = getattr(tok, "pad_token_id", None) or getattr(tok, "eos_token_id", None)
        kwargs = {
            "max_new_tokens": int(self._settings.get("max_new_tokens", 512) or 512),
            "do_sample": float(self._settings.get("temperature", 0.7) or 0.7) > 1e-5,
            "temperature": max(float(self._settings.get("temperature", 0.7) or 0.7), 1e-5),
            "top_p": float(self._settings.get("top_p", 0.9) or 0.9),
            "repetition_penalty": float(self._settings.get("repeat_penalty", 1.1) or 1.1),
            "pad_token_id": pad_id,
            "renormalize_logits": True,
            "remove_invalid_values": True,
        }
        if overrides:
            kwargs.update({k: v for k, v in overrides.items() if v is not None})
        return kwargs

    def _generate(self, model, tok, messages: List[Dict[str, str]], label: str = "model", overrides: Optional[Dict[str, Any]] = None, input_options: Optional[Dict[str, Any]] = None) -> str:
        import torch
        input_options = dict(input_options or {})
        if not str(input_options.get("template_mode") or "").strip():
            gate_mode = str(self._settings.get("gate_chat_template_mode") or "auto").strip().lower()
            if gate_mode:
                input_options["template_mode"] = gate_mode
        inputs = self._prepare_inputs(model, tok, messages, label, template_mode=input_options.get("template_mode"))
        with torch.no_grad():
            output = model.generate(**inputs, **self._generation_kwargs(tok, overrides))
        new_tokens = output[0][inputs["input_ids"].shape[-1]:]
        text = tok.decode(new_tokens, skip_special_tokens=True).strip()
        if not _looks_garbled_text(text):
            return text
        _runtime_log(f"检测到疑似异常输出，改用稳定参数重试: {label} :: {repr(text[:80])}")
        retry_overrides = dict(overrides or {})
        retry_overrides.update({
            "do_sample": False,
            "temperature": 1.0,
            "top_p": 1.0,
            "repetition_penalty": 1.0,
            "max_new_tokens": min(int((overrides or {}).get("max_new_tokens") or self._settings.get("max_new_tokens", 512) or 512), 256),
        })
        retry_kwargs = self._generation_kwargs(tok, retry_overrides)
        with torch.no_grad():
            output = model.generate(**inputs, **retry_kwargs)
        new_tokens = output[0][inputs["input_ids"].shape[-1]:]
        text = tok.decode(new_tokens, skip_special_tokens=True).strip()
        if _looks_garbled_text(text):
            raise RuntimeError(f"DEGENERATE_OUTPUT::{label}::{text!r}")
        return text

    def _generate_expert_sync(self, expert: Dict[str, Any], model, tok, messages: List[Dict[str, str]], label: str, overrides: Optional[Dict[str, Any]] = None) -> str:
        name = str(expert.get("name") or expert.get("domain") or "expert")
        local_tok = tok
        input_options = self._expert_input_override(name)
        if not str(input_options.get("template_mode") or "").strip():
            input_options["template_mode"] = str(self._settings.get("expert_chat_template_mode") or "auto_fallback").strip().lower() or "auto_fallback"
        tried_queue = False
        tried_runtime_fallback = False
        while True:
            try:
                return self._generate(model, local_tok, messages, label=label, overrides=overrides, input_options=input_options)
            except Exception as e:
                if (not tried_runtime_fallback) and _is_expert_prompt_compat_error(e):
                    try:
                        new_tok, new_override = self._try_expert_runtime_fallback(expert, model, local_tok, messages, label, current_override=input_options)
                        changed = (new_tok is not local_tok) or (dict(new_override or {}) != dict(input_options or {}))
                        if changed:
                            local_tok = new_tok
                            input_options = dict(new_override or {})
                            tried_runtime_fallback = True
                            continue
                    except Exception:
                        pass
                if _is_oom_error(e) and not tried_queue and self._enter_expert_queue_mode(str(e), reserve_name=name):
                    tried_queue = True
                    continue
                raise

    def _generate_expert_stream(self, expert: Dict[str, Any], model, tok, messages: List[Dict[str, str]], label: str, overrides: Optional[Dict[str, Any]] = None) -> Generator[str, None, None]:
        name = str(expert.get("name") or expert.get("domain") or "expert")
        local_tok = tok
        input_options = self._expert_input_override(name)
        if not str(input_options.get("template_mode") or "").strip():
            input_options["template_mode"] = str(self._settings.get("expert_chat_template_mode") or "auto_fallback").strip().lower() or "auto_fallback"
        tried_queue = False
        tried_runtime_fallback = False
        while True:
            try:
                for piece in self._generate_stream(model, local_tok, messages, label=label, overrides=overrides, input_options=input_options):
                    yield piece
                return
            except Exception as e:
                if (not tried_runtime_fallback) and _is_expert_prompt_compat_error(e):
                    try:
                        new_tok, new_override = self._try_expert_runtime_fallback(expert, model, local_tok, messages, label, current_override=input_options)
                        changed = (new_tok is not local_tok) or (dict(new_override or {}) != dict(input_options or {}))
                        if changed:
                            local_tok = new_tok
                            input_options = dict(new_override or {})
                            tried_runtime_fallback = True
                            continue
                    except Exception:
                        pass
                if _is_oom_error(e) and not tried_queue and self._enter_expert_queue_mode(str(e), reserve_name=name):
                    tried_queue = True
                    continue
                raise

    def _generate_stream(self, model, tok, messages: List[Dict[str, str]], label: str = "model", overrides: Optional[Dict[str, Any]] = None, input_options: Optional[Dict[str, Any]] = None) -> Generator[str, None, None]:
        import torch
        from transformers import TextIteratorStreamer
        input_options = dict(input_options or {})
        if not str(input_options.get("template_mode") or "").strip():
            gate_mode = str(self._settings.get("gate_chat_template_mode") or "auto").strip().lower()
            if gate_mode:
                input_options["template_mode"] = gate_mode
        inputs = self._prepare_inputs(model, tok, messages, label, template_mode=input_options.get("template_mode"))
        streamer = TextIteratorStreamer(tok, skip_prompt=True, skip_special_tokens=True)
        error_box: Dict[str, Exception] = {}
        kwargs = dict(inputs)
        kwargs.update(self._generation_kwargs(tok, overrides))
        kwargs["streamer"] = streamer

        def _worker():
            try:
                with torch.no_grad():
                    model.generate(**kwargs)
            except Exception as e:
                error_box["error"] = e
                try:
                    streamer.end()
                except Exception:
                    pass

        th = threading.Thread(target=_worker, daemon=True)
        th.start()
        for chunk in streamer:
            if chunk:
                yield chunk
        th.join(timeout=0.2)
        if "error" in error_box:
            raise error_box["error"]

    def _safe_cpu_fallback(self, reason: Exception, messages: List[Dict[str, str]], user_text: str) -> Tuple[str, str, float]:
        self._mark_gpu_failed(str(reason))
        if not bool(self._settings.get("cpu_fallback_on_error", True)):
            raise reason
        cpu_model, cpu_tok = self._load_base_cpu()
        answer = self._generate(cpu_model, cpu_tok, self._merge_messages(messages, None, user_text), label="base-cpu")
        return answer, "base:cpu-fallback", 0.0

    def chat(self, messages: List[Dict[str, str]], model_name: Optional[str] = None, forced_route: Optional[str] = None, conversation_id: Optional[str] = None) -> Dict[str, Any]:
        messages = self._sanitize_messages(messages)
        if not messages:
            messages = [{"role": "user", "content": "你好"}]
        self._request_count += 1
        user_text = "\n".join(str(m.get("content", "")) for m in messages if isinstance(m, dict) and m.get("role") == "user").strip()
        with self._lock:
            base_model, base_tok = self._load_base()
            force_mode, forced_expert, override_note, force_consult = self._resolve_forced_route(forced_route)
            ranked = self._route_candidates(user_text, conversation_id=conversation_id)
            if force_mode == "expert":
                route = forced_expert
            elif force_mode == "base":
                route = None
            else:
                route = self.route(user_text, conversation_id=conversation_id)
            route_name, route_score = ("base:forced", 0.0) if force_mode == "base" else ("base", 0.0)
            sticky_state = self._sticky_state(conversation_id)
            sticky_note = ""
            if sticky_state and force_mode == "auto":
                sticky_note = f"沿用最近专家 {sticky_state.get('name')} · 剩余 {int(sticky_state.get('turns_left') or 0)} 轮"
            if self._is_short_base_query(user_text, conversation_id=conversation_id):
                sticky_note = sticky_note or "短问候/短确认优先交给主模型，避免无效切换。"
            used_cpu = False
            fallback_reason = ""
            knowledge_hits = len(self._retrieve_knowledge(user_text, route))
            base_trace = self._route_trace(user_text, route, route_name, route_score, selected=False, fallback_reason="", used_cpu=False, knowledge_hits=knowledge_hits, override_note=override_note, sticky_note=sticky_note)
            participants, consult_notes0 = self._pick_consult_experts(user_text, route, ranked, force_mode, force_consult=force_consult)
            route_trace = list(base_trace)
            route_trace.extend(consult_notes0)
            if force_mode != "base" and len(participants) > 1:
                answer, route_name, route_score, consultation, used_cpu, fallback_reason = self._run_consultation_sync(base_model, base_tok, messages, user_text, participants, route_trace)
                self._last_route = route_name
                self._remember_route(conversation_id, participants[0] if participants else None)
                self._consume_route_memory(conversation_id, bool(participants))
                if fallback_reason:
                    route_trace.append(f"会诊补充: {fallback_reason[:200]}")
                return {
                    "model": model_name or self.package_name,
                    "answer": answer,
                    "route": route_name,
                    "route_score": route_score,
                    "route_trace": route_trace,
                    "knowledge_hits": knowledge_hits,
                    "consultation": {
                        "mode": "meeting",
                        "participants": [str(x.get("name") or x.get("domain") or "expert") for x in participants],
                        "details": consultation,
                    },
                    "gpu_status": self.get_runtime_status(),
                }
            chosen_model, chosen_tok, chosen_expert = base_model, base_tok, None
            expert_worklog = ""
            if route is not None:
                route_name = str(route.get("name") or route.get("domain") or "expert")
                route_score = float(route.get("route_score") or 0.0)
                chosen_expert = route
                try:
                    chosen_model, chosen_tok = self._load_expert(route, probe_messages=self._merge_messages(messages, route, user_text))
                except Exception as e:
                    fallback_reason = str(e)
                    _runtime_log(f"专家加载失败，回退主模型: {route_name} :: {e}")
                    route_name, route_score, chosen_expert = (("base:forced-fallback", 0.0, None) if force_mode == "expert" else ("base:fallback-load", 0.0, None))
            merged_messages = self._merge_messages(messages, chosen_expert, user_text)
            if chosen_expert is not None and self._show_expert_logs():
                try:
                    expert_worklog = self._generate_expert_sync(chosen_expert, chosen_model, chosen_tok, self._build_expert_worklog_messages(messages, chosen_expert, user_text), label=f"worklog:{route_name}", overrides=self._expert_worklog_overrides())
                except Exception as e:
                    route_trace_hint = f"透明日志: {route_name} 公开工作日志生成失败，已直接继续正式回答。原因: {str(e)[:160]}"
                    expert_worklog = ""
                else:
                    route_trace_hint = f"透明日志: {route_name} 已生成公开工作日志。"
            else:
                route_trace_hint = ""
            try:
                answer = self._generate_expert_sync(chosen_expert, chosen_model, chosen_tok, merged_messages, label=route_name) if chosen_expert is not None else self._generate(chosen_model, chosen_tok, merged_messages, label=route_name)
            except Exception as e:
                bad_output = "degenerate_output::" in str(e).lower()
                if _is_gpu_generation_error(e):
                    fallback_reason = str(e)
                    if chosen_expert is not None and route_name not in ("base", "base:fallback-load"):
                        self._mark_expert_failed(route_name, str(e))
                        try:
                            base_model2, base_tok2 = self._load_base()
                            answer = self._generate(base_model2, base_tok2, self._merge_messages(messages, None, user_text), label="base:gpu-retry")
                            route_name, route_score, chosen_expert = "base:gpu-retry", 0.0, None
                        except Exception as e2:
                            answer, route_name, route_score = self._safe_cpu_fallback(e2, messages, user_text)
                            used_cpu = True
                            fallback_reason = str(e2)
                    else:
                        answer, route_name, route_score = self._safe_cpu_fallback(e, messages, user_text)
                        used_cpu = True
                elif bad_output:
                    fallback_reason = str(e)
                    _runtime_log(f"输出疑似乱码，回退主模型: {route_name} :: {e}")
                    try:
                        base_model2, base_tok2 = self._load_base()
                        answer = self._generate(base_model2, base_tok2, self._merge_messages(messages, None, user_text), label="base:bad-output-retry")
                        route_name, route_score, chosen_expert = "base:bad-output-retry", 0.0, None
                    except Exception as e2:
                        answer, route_name, route_score = self._safe_cpu_fallback(e2, messages, user_text)
                        used_cpu = True
                        fallback_reason = str(e2)
                else:
                    self._last_error = str(e)
                    raise
            if chosen_expert is not None:
                self._maybe_release_expert_after_reply(str(chosen_expert.get("name") or route_name))
            self._last_route = route_name
            route_trace = self._route_trace(user_text, route, route_name, route_score, selected=chosen_expert is not None, fallback_reason=fallback_reason, used_cpu=used_cpu, knowledge_hits=knowledge_hits, override_note=override_note, sticky_note=sticky_note)
            route_trace.extend(consult_notes0)
            if route_trace_hint:
                route_trace.append(route_trace_hint)
            if len(participants) > 1:
                self._remember_route(conversation_id, participants[0])
                self._consume_route_memory(conversation_id, True)
            else:
                self._remember_route(conversation_id, chosen_expert)
                self._consume_route_memory(conversation_id, chosen_expert is not None)
            return {
                "model": model_name or self.package_name,
                "answer": answer,
                "route": route_name,
                "route_score": route_score,
                "route_trace": route_trace,
                "knowledge_hits": knowledge_hits,
                "expert_worklog": expert_worklog,
                "gpu_status": self.get_runtime_status(),
            }

    def stream_chat(self, messages: List[Dict[str, str]], model_name: Optional[str] = None, forced_route: Optional[str] = None, conversation_id: Optional[str] = None) -> Generator[Dict[str, Any], None, None]:
        messages = self._sanitize_messages(messages)
        if not messages:
            messages = [{"role": "user", "content": "你好"}]
        self._request_count += 1
        user_text = "\n".join(str(m.get("content", "")) for m in messages if isinstance(m, dict) and m.get("role") == "user").strip()
        with self._lock:
            yield {"event": "status", "text": "正在加载主模型..."}
            base_model, base_tok = self._load_base()
            gpu_profile = self._current_profile()
            yield {"event": "trace", "stage": "backend", "text": f"当前后端模式 {self._backend_mode()}，实际生成设备={'GPU' if gpu_profile['cuda'] else 'CPU'}。"}
            yield {"event": "status", "text": "正在分析问题并选择专家..."}
            force_mode, forced_expert, override_note, force_consult = self._resolve_forced_route(forced_route)
            ranked = self._route_candidates(user_text, conversation_id=conversation_id)
            if force_mode == "expert":
                route = forced_expert
            elif force_mode == "base":
                route = None
            else:
                route = self.route(user_text, conversation_id=conversation_id)
            knowledge_hits = len(self._retrieve_knowledge(user_text, route))
            yield {"event": "trace", "stage": "knowledge", "text": f"知识库检索命中 {knowledge_hits} 条参考。"}
            route_name, route_score = ("base:forced", 0.0) if force_mode == "base" else ("base", 0.0)
            sticky_state = self._sticky_state(conversation_id)
            sticky_note = ""
            if sticky_state and force_mode == "auto":
                sticky_note = f"沿用最近专家 {sticky_state.get('name')} · 剩余 {int(sticky_state.get('turns_left') or 0)} 轮"
            if self._is_short_base_query(user_text, conversation_id=conversation_id):
                sticky_note = sticky_note or "短问候/短确认优先交给主模型，避免无效切换。"
            route_trace = self._route_trace(user_text, route, route_name, route_score, selected=False, fallback_reason="", used_cpu=not gpu_profile["cuda"], knowledge_hits=knowledge_hits, override_note=override_note, sticky_note=sticky_note)
            participants, consult_notes0 = self._pick_consult_experts(user_text, route, ranked, force_mode, force_consult=force_consult)
            route_trace.extend(consult_notes0)
            for line in consult_notes0:
                yield {"event": "trace", "stage": "consult_gate", "text": line}
            if force_mode != "base" and len(participants) > 1:
                roster = " / ".join(str(x.get("name") or x.get("domain") or "expert") for x in participants)
                yield {"event": "trace", "stage": "consult_gate", "text": f"已进入多专家会诊模式，参会专家：{roster}"}
                yield {"event": "meta", "model": model_name or self.package_name, "route": "consult", "route_score": max(float(x.get("route_score") or 0.0) for x in participants), "route_trace": route_trace, "knowledge_hits": knowledge_hits, "gpu": self.get_runtime_status()}
                full_text, route_name, route_score, consultation, used_cpu, fallback_reason = yield from self._run_consultation_stream(base_model, base_tok, messages, user_text, participants, route_trace)
                if fallback_reason:
                    route_trace.append(f"会诊补充: {fallback_reason[:200]}")
                self._last_route = route_name
                self._remember_route(conversation_id, participants[0] if participants else None)
                self._consume_route_memory(conversation_id, bool(participants))
                yield {
                    "event": "done",
                    "model": model_name or self.package_name,
                    "answer": full_text,
                    "route": route_name,
                    "route_score": route_score,
                    "route_trace": route_trace,
                    "consultation": {
                        "mode": "meeting",
                        "participants": [str(x.get("name") or x.get("domain") or "expert") for x in participants],
                        "details": consultation,
                    },
                    "gpu": self.get_runtime_status(),
                }
                return
            chosen_model, chosen_tok, chosen_expert = base_model, base_tok, None
            fallback_reason = ""
            if force_mode == "base":
                yield {"event": "trace", "stage": "route", "text": "已手动指定：本轮只使用主模型/门控模型回答。"}
            elif route is not None:
                route_name = str(route.get("name") or route.get("domain") or "expert")
                route_score = float(route.get("route_score") or 0.0)
                target_backend = self._expert_backend_mode(route)
                route_msg = f"已手动指定专家 {route_name} 回答。" if force_mode == "expert" else f"命中专家候选 {route_name}，分数 {route_score:.2f}。"
                if target_backend == "cpu" and not gpu_profile["cuda"]:
                    route_msg += " 当前 GPU 不可用，本轮尝试以 CPU 方式加载该专家。"
                elif target_backend == "gpu":
                    route_msg += " 本轮优先尝试 GPU 专家路径。"
                yield {"event": "trace", "stage": "route", "text": route_msg}
                chosen_expert = route
                try:
                    yield {"event": "status", "text": (f"正在为专家 {route_name} 预留 GPU 显存并排队加载..." if self._expert_queue_mode else f"正在加载专家 {route_name}...")}
                    chosen_model, chosen_tok = self._load_expert(route, probe_messages=self._merge_messages(messages, route, user_text))
                    _expert_mode_tmp, _expert_profile_tmp = self._expert_backend_profile(route, allow_probe=False)
                    actual_backend = "GPU" if _expert_mode_tmp == "gpu" and _expert_profile_tmp["cuda"] else "CPU"
                    yield {"event": "trace", "stage": "expert", "text": f"专家 {route_name} 已加载，将以{actual_backend}参与本轮回答。"}
                except Exception as e:
                    fallback_reason = str(e)
                    _runtime_log(f"专家加载失败，回退主模型: {route_name} :: {e}")
                    yield {"event": "trace", "stage": "expert_fallback", "text": f"专家 {route_name} 加载失败，已跳过专家并继续使用主模型。原因: {e}"}
                    route_name, route_score, chosen_expert = (("base:forced-fallback", 0.0, None) if force_mode == "expert" else ("base:fallback-load", 0.0, None))
            else:
                yield {"event": "trace", "stage": "route", "text": "未命中专家，直接使用主模型回答。"}
            route_trace = self._route_trace(user_text, route, route_name, route_score, selected=chosen_expert is not None, fallback_reason=fallback_reason, used_cpu=not gpu_profile["cuda"], knowledge_hits=knowledge_hits, override_note=override_note, sticky_note=sticky_note)
            route_trace.extend(consult_notes0)
            yield {"event": "meta", "model": model_name or self.package_name, "route": route_name, "route_score": route_score, "route_trace": route_trace, "knowledge_hits": knowledge_hits, "gpu": self.get_runtime_status()}
            merged_messages = self._merge_messages(messages, chosen_expert, user_text)
            full_text = ""
            expert_worklog = ""
            if chosen_expert is not None and self._show_expert_logs():
                expert_name = str(chosen_expert.get("name") or chosen_expert.get("domain") or route_name or "专家")
                try:
                    yield {"event": "expert_log_begin", "expert": expert_name, "domain": str(chosen_expert.get("domain") or ""), "mode": "single", "text": f"{expert_name} 正在公开整理思路。"}
                    try:
                        for piece in self._generate_expert_stream(chosen_expert, chosen_model, chosen_tok, self._build_expert_worklog_messages(messages, chosen_expert, user_text), label=f"worklog:{route_name}", overrides=self._expert_worklog_overrides()):
                            expert_worklog += piece
                            yield {"event": "expert_log_delta", "expert": expert_name, "domain": str(chosen_expert.get("domain") or ""), "mode": "single", "text": piece}
                    except Exception as inner_e:
                        if _is_oom_error(inner_e) and not expert_worklog and self._enter_expert_queue_mode(str(inner_e), reserve_name=expert_name):
                            yield {"event": "trace", "stage": "expert_queue", "text": f"检测到专家显存不足，已切换到单专家预留显存排队模式，并重试 {expert_name} 的公开日志。"}
                            for piece in self._generate_expert_stream(chosen_expert, chosen_model, chosen_tok, self._build_expert_worklog_messages(messages, chosen_expert, user_text), label=f"worklog:{route_name}", overrides=self._expert_worklog_overrides()):
                                expert_worklog += piece
                                yield {"event": "expert_log_delta", "expert": expert_name, "domain": str(chosen_expert.get("domain") or ""), "mode": "single", "text": piece}
                        else:
                            raise inner_e
                    yield {"event": "expert_log_done", "expert": expert_name, "domain": str(chosen_expert.get("domain") or ""), "mode": "single", "text": expert_worklog}
                    yield {"event": "trace", "stage": "worklog", "text": f"透明日志: {expert_name} 已输出公开工作日志。"}
                except Exception as e:
                    yield {"event": "trace", "stage": "worklog", "text": f"透明日志: {expert_name} 工作日志生成失败，已直接继续正式回答。原因: {str(e)[:160]}"}
            try:
                yield {"event": "status", "text": "正在生成回复..."}
                try:
                    for piece in self._generate_expert_stream(chosen_expert, chosen_model, chosen_tok, merged_messages, label=route_name):
                        full_text += piece
                        yield {"event": "delta", "text": piece, "route": route_name}
                except Exception as inner_e:
                    if chosen_expert is not None and _is_oom_error(inner_e) and not full_text and self._enter_expert_queue_mode(str(inner_e), reserve_name=str(chosen_expert.get("name") or route_name)):
                        yield {"event": "trace", "stage": "expert_queue", "text": f"检测到专家显存不足，已切换到单专家预留显存排队模式，并重试 {route_name}。"}
                        for piece in self._generate_expert_stream(chosen_expert, chosen_model, chosen_tok, merged_messages, label=route_name):
                            full_text += piece
                            yield {"event": "delta", "text": piece, "route": route_name}
                    else:
                        raise inner_e
            except Exception as e:
                if _is_gpu_generation_error(e):
                    if chosen_expert is not None and route_name not in ("base", "base:fallback-load"):
                        yield {"event": "trace", "stage": "expert_retry", "text": f"专家 {route_name} 在 GPU 上推理失败，已临时停用并改由主模型 GPU 重试。"}
                        self._mark_expert_failed(route_name, str(e))
                        try:
                            base_model2, base_tok2 = self._load_base()
                            route_name, route_score, full_text, chosen_expert = "base:gpu-retry", 0.0, "", None
                            route_trace = self._route_trace(user_text, route, route_name, route_score, selected=False, fallback_reason=str(e), used_cpu=False, knowledge_hits=knowledge_hits, override_note=override_note)
                            route_trace.extend(consult_notes0)
                            for piece in self._generate_stream(base_model2, base_tok2, self._merge_messages(messages, None, user_text), label="base:gpu-retry"):
                                full_text += piece
                                yield {"event": "delta", "text": piece, "route": route_name}
                        except Exception as e2:
                            if not bool(self._settings.get("cpu_fallback_on_error", True)):
                                self._last_error = str(e2)
                                raise
                            yield {"event": "status", "text": "GPU 重试失败，已切到 CPU 安全模式继续回答..."}
                            yield {"event": "trace", "stage": "gpu_fallback", "text": f"GPU 主模型重试仍失败，已停用 GPU 并切换到 CPU。原因: {e2}"}
                            self._mark_gpu_failed(str(e2))
                            cpu_model, cpu_tok = self._load_base_cpu()
                            route_name, route_score, full_text = "base:cpu-fallback", 0.0, ""
                            route_trace = self._route_trace(user_text, route, route_name, route_score, selected=False, fallback_reason=str(e2), used_cpu=True, knowledge_hits=knowledge_hits, override_note=override_note)
                            route_trace.extend(consult_notes0)
                            for piece in self._generate_stream(cpu_model, cpu_tok, self._merge_messages(messages, None, user_text), label="base-cpu"):
                                full_text += piece
                                yield {"event": "delta", "text": piece, "route": route_name}
                    else:
                        if not bool(self._settings.get("cpu_fallback_on_error", True)):
                            self._last_error = str(e)
                            raise
                        yield {"event": "status", "text": "GPU 出错，已切到 CPU 安全模式继续回答..."}
                        yield {"event": "trace", "stage": "gpu_fallback", "text": f"GPU 生成失败，已停用 GPU 并切换到 CPU。原因: {e}"}
                        self._mark_gpu_failed(str(e))
                        cpu_model, cpu_tok = self._load_base_cpu()
                        route_name, route_score, full_text = "base:cpu-fallback", 0.0, ""
                        route_trace = self._route_trace(user_text, route, route_name, route_score, selected=False, fallback_reason=str(e), used_cpu=True, knowledge_hits=knowledge_hits, override_note=override_note)
                        route_trace.extend(consult_notes0)
                        for piece in self._generate_stream(cpu_model, cpu_tok, self._merge_messages(messages, None, user_text), label="base-cpu"):
                            full_text += piece
                            yield {"event": "delta", "text": piece, "route": route_name}
                else:
                    self._last_error = str(e)
                    raise
            if _looks_garbled_text(full_text):
                reason = f"DEGENERATE_OUTPUT::{route_name}::{full_text!r}"
                _runtime_log(f"流式输出疑似乱码，改由主模型补救: {route_name} :: {full_text!r}")
                yield {"event": "trace", "stage": "output_retry", "text": "检测到专家输出疑似乱码，已改用主模型稳定重试，最终答案以 done 事件为准。"}
                try:
                    base_model2, base_tok2 = self._load_base()
                    full_text = self._generate(base_model2, base_tok2, self._merge_messages(messages, None, user_text), label="base:bad-output-retry")
                    route_name, route_score, chosen_expert = "base:bad-output-retry", 0.0, None
                    route_trace = self._route_trace(user_text, route, route_name, route_score, selected=False, fallback_reason=reason, used_cpu=not self._current_profile()["cuda"], knowledge_hits=knowledge_hits, override_note=override_note)
                    route_trace.extend(consult_notes0)
                except Exception as e2:
                    if bool(self._settings.get("cpu_fallback_on_error", True)):
                        self._mark_gpu_failed(str(e2))
                        cpu_model, cpu_tok = self._load_base_cpu()
                        full_text = self._generate(cpu_model, cpu_tok, self._merge_messages(messages, None, user_text), label="base-cpu-bad-output-retry")
                        route_name, route_score = "base:cpu-fallback", 0.0
                        route_trace = self._route_trace(user_text, route, route_name, route_score, selected=False, fallback_reason=str(e2), used_cpu=True, knowledge_hits=knowledge_hits, override_note=override_note)
                        route_trace.extend(consult_notes0)
            self._last_route = route_name
            yield {"event": "done", "model": model_name or self.package_name, "answer": full_text, "route": route_name, "route_score": route_score, "route_trace": route_trace, "expert_worklog": expert_worklog, "gpu": self.get_runtime_status()}



CORE = RuntimeCore(MANIFEST)


def _open_browser_later(url: str, delay: float = 0.8):
    def _worker():
        time.sleep(delay)
        try:
            webbrowser.open(url)
            _runtime_log(f"已尝试打开浏览器: {url}")
        except Exception as e:
            _runtime_log(f"自动打开浏览器失败，可手动访问: {url} :: {e}")
    threading.Thread(target=_worker, daemon=True).start()


def _simple_html() -> str:
    s = CORE.get_settings()
    host = s["host"]
    port = s["port"]
    package_js = json.dumps(CORE.package_name, ensure_ascii=False)
    settings_json = json.dumps(s, ensure_ascii=False)
    return f"""<!doctype html>
<html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'>
<title>POLARIS Runtime</title>
<style>
:root{{--bg:#0b1020;--panel:#111827;--line:#243041;--text:#e5e7eb;--muted:#93a3b8;--accent:#60a5fa;--ok:#34d399;--warn:#f59e0b;--bad:#f87171}}
*{{box-sizing:border-box}}
body{{font-family:Segoe UI,Arial,sans-serif;background:linear-gradient(180deg,#07101f,#0b1020);color:var(--text);margin:0}}
.wrap{{max-width:1240px;margin:0 auto;padding:22px}}
.grid{{display:grid;grid-template-columns:1.2fr 0.95fr;gap:16px;align-items:start}}
.card{{background:rgba(17,24,39,.96);border:1px solid var(--line);border-radius:18px;padding:18px;margin-bottom:16px;box-shadow:0 10px 30px rgba(0,0,0,.22)}}
.card h1,.card h2{{margin:0 0 10px 0}}
.muted{{color:var(--muted)}}
.statusline{{display:flex;gap:10px;flex-wrap:wrap;margin-top:8px}}
.badge{{padding:6px 10px;border-radius:999px;border:1px solid var(--line);background:#0b1327;font-size:13px}}
.badge.ok{{color:#d1fae5;border-color:#14532d;background:#052e1b}}
.badge.warn{{color:#fef3c7;border-color:#854d0e;background:#3b2500}}
.badge.bad{{color:#fee2e2;border-color:#7f1d1d;background:#330909}}
.table{{width:100%;border-collapse:collapse}}
.table th,.table td{{padding:10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;word-break:break-word}}
code,pre{{background:#020617;border:1px solid #1e293b;border-radius:12px;padding:12px;display:block;white-space:pre-wrap;word-break:break-word}}
textarea,input,select{{width:100%;padding:11px 12px;border-radius:12px;border:1px solid #334155;background:#071122;color:var(--text);font:inherit}}
textarea{{min-height:120px;resize:vertical}}
.label{{display:block;font-size:13px;color:var(--muted);margin:0 0 6px 2px}}
.row{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}
.row3{{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}}
.actions{{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}}
button{{padding:10px 14px;border-radius:12px;border:1px solid #2f3d55;background:#11203a;color:var(--text);cursor:pointer;font:inherit}}
button.primary{{background:#1d4ed8;border-color:#2563eb}}
button.warn{{background:#6b3f00;border-color:#b45309}}
button.good{{background:#14532d;border-color:#15803d}}
button:disabled{{opacity:.6;cursor:not-allowed}}
.chatbox{{min-height:360px;max-height:58vh;overflow:auto;padding:12px;border:1px solid var(--line);border-radius:14px;background:#081121}}
.msg{{padding:12px 14px;border-radius:14px;margin-bottom:10px;border:1px solid var(--line);white-space:pre-wrap;word-break:break-word}}
.msg.user{{background:#0b1730}}
.msg.assistant{{background:#101a2d}}
.msg.system{{background:#06223a}}
.msg .role{{font-size:12px;color:var(--muted);margin-bottom:6px}}
.msg .body{{line-height:1.6}}
.thought-wrap{{display:none;margin-top:12px;border-top:1px dashed #314055;padding-top:10px}}
.thought-wrap summary{{cursor:pointer;color:#cbd5e1;font-size:12px;user-select:none;outline:none}}
.thought-wrap[open] summary{{margin-bottom:8px}}
.thought-body{{font-size:12px;line-height:1.55;color:#cbd5e1;background:#0a1324;border:1px solid #233146;border-radius:10px;padding:10px;white-space:pre-wrap;word-break:break-word}}
.small{{font-size:12px}}
@media (max-width:980px){{.grid,.row,.row3{{grid-template-columns:1fr}} .wrap{{padding:14px}}}}
</style>
</head><body><div class='wrap'>
<div class='card'>
  <h1>POLARIS Runtime 实用版</h1>
  <div class='muted'>默认走流式请求。启动时不探测 GPU；只有在首次实际加载模型时才决定是否启用 GPU。</div>
  <div class='statusline'>
    <span id='backendBadge' class='badge'>后端模式读取中</span>
    <span id='probeBadge' class='badge'>GPU 未探测</span>
    <span id='loadBadge' class='badge'>模型未加载</span>
    <span id='routeBadge' class='badge'>最近路由: base</span>
    <span class='badge'>地址: http://{host}:{port}</span>
  </div>
</div>
<div class='grid'>
  <div>
    <div class='card'>
      <h2>聊天测试</h2>
      <div class='muted'>流式发送会边生成边刷新；如果当前浏览器或后端流式失败，会自动回退普通请求。</div>
      <div id='chatbox' class='chatbox' aria-live='polite'></div>
      <label class='label' for='sessionSystem'>本页会话系统提示词（仅本页测试使用）</label>
      <textarea id='sessionSystem' placeholder='可选：只作用于当前网页测试会话'></textarea>
      <label class='label' for='forced_route'>回答模式</label>
      <select id='forced_route'><option value='auto'>自动选择</option><option value='consult'>自动多专家会诊</option><option value='base'>仅门控/主模型回答</option></select>
      <label class='label' for='userInput'>输入内容</label>
      <textarea id='userInput' placeholder='输入你的问题…'></textarea>
      <div class='actions'>
        <button type='button' id='sendBtn' class='primary'>流式发送</button>
        <button type='button' id='sendJsonBtn'>普通发送</button>
        <button type='button' id='stopBtn' class='warn' disabled>停止生成</button>
        <button type='button' id='clearChatBtn'>清空聊天</button>
        <button type='button' id='refreshBtn'>刷新状态</button>
      </div>
      <div style='margin-top:8px'>
        <label><input id='keepHistory' type='checkbox' checked style='width:auto;margin-right:8px'>保留对话历史</label>
        <label style='margin-left:16px'><input id='autoScroll' type='checkbox' checked style='width:auto;margin-right:8px'>自动滚动</label>
      </div>
      <div id='chatHint' class='small muted' style='margin-top:10px'>当前模型: {CORE.package_name}</div>
      <label class='label' for='expertTrace' style='margin-top:12px'>专家模式过程 / 路由痕迹</label>
      <pre id='expertTrace' style='min-height:120px'></pre>
    </div>
    <div class='card'>
      <h2>当前状态</h2>
      <table class='table' id='statusTable'></table>
      <div class='actions'>
        <button id='clearCacheBtn' class='warn' type='button'>清缓存 / 卸载模型</button>
        <button id='recoverGpuBtn' class='good' type='button'>重置 GPU 状态</button>
      </div>
    </div>
    <div class='card'>
      <h2>可用接口</h2>
      <pre>GET  /health
GET  /v1/models
GET  /api/tags
GET  /api/settings
GET  /api/runtime/status
POST /api/settings
POST /api/runtime/clear
POST /api/runtime/recover_gpu
POST /api/chat/stream
POST /v1/chat/completions
POST /v1/responses
POST /api/chat
POST /api/generate</pre>
    </div>
  </div>
  <div>
    <div class='card'>
      <h2>运行设置</h2>
      <div class='row3'>
        <div><label class='label'>temperature</label><input id='temperature' type='number' step='0.05'></div>
        <div><label class='label'>top_p</label><input id='top_p' type='number' step='0.05'></div>
        <div><label class='label'>repeat_penalty</label><input id='repeat_penalty' type='number' step='0.05'></div>
      </div>
      <div class='row3' style='margin-top:12px'>
        <div><label class='label'>max_new_tokens</label><input id='max_new_tokens' type='number' step='1'></div>
        <div><label class='label'>activation_threshold</label><input id='activation_threshold' type='number' step='0.1'></div>
        <div><label class='label'>max_cached_experts</label><input id='max_cached_experts' type='number' step='1'></div>
        <div><label class='label'>expert_backend_mode</label><select id='expert_backend_mode'><option value='gpu'>gpu（强制优先使用GPU）</option><option value='auto'>auto（按专家类型自动选择）</option><option value='cpu'>cpu（专家固定CPU）</option></select></div>
        <div><label class='label'>expert_tokenizer_strategy</label><select id='expert_tokenizer_strategy'><option value='auto'>auto（完整专家优先自带 tokenizer）</option><option value='self'>self（总是优先专家自带 tokenizer）</option><option value='base'>base（完整专家优先基座 tokenizer）</option></select></div>
        <div><label class='label'>swarm_mode</label><select id='swarm_mode'><option value='single'>single（单专家/主模型）</option><option value='consult'>consult（按需会诊）</option><option value='consult_always'>consult_always（命中专家就会诊）</option></select></div>
        <div><label class='label'>consult_max_experts</label><input id='consult_max_experts' type='number' step='1'></div>
      </div>
      <div class='row3' style='margin-top:12px'>
        <div><label class='label'>consult_secondary_ratio</label><input id='consult_secondary_ratio' type='number' step='0.05'></div>
        <div><label class='label'>consult_note_max_new_tokens</label><input id='consult_note_max_new_tokens' type='number' step='1'></div>
        <div><label class='label'>consult_synth_max_new_tokens</label><input id='consult_synth_max_new_tokens' type='number' step='1'></div>
        <div><label class='label'>consult_note_temperature</label><input id='consult_note_temperature' type='number' step='0.05'></div>
      </div>
      <div class='row3' style='margin-top:12px'>
        <div><label class='label'>consult_dispatch_mode</label><select id='consult_dispatch_mode'><option value='auto'>auto（自动判断：GPU排队 / CPU同时讨论）</option><option value='manual_queue'>manual_queue（手动切换排队）</option><option value='parallel'>parallel（同时讨论）</option></select></div>
        <div><label class='label'>thinking_transparency</label><select id='thinking_transparency'><option value='structured'>structured（显示专家公开日志）</option><option value='off'>off（仅显示最终答案）</option></select></div>
        <div><label class='label'>expert_worklog_max_new_tokens</label><input id='expert_worklog_max_new_tokens' type='number' step='1'></div>
        <div><label class='label'>expert_worklog_temperature</label><input id='expert_worklog_temperature' type='number' step='0.05'></div>
      </div>
      <div class='row' style='margin-top:8px'>
        <label><input id='consult_parallel_allow_gpu' type='checkbox' style='width:auto;margin-right:8px'>允许在 GPU 下尝试同时讨论（风险较高）</label>
      </div>
      <div class='row' style='margin-top:12px'>
        <div>
          <label class='label'>门控/主模型加载模式</label>
          <select id='gate_backend_mode'>
            <option value='auto'>Auto（加载时探测 GPU，失败则回 CPU）</option>
            <option value='gpu'>GPU（加载时优先启用 GPU）</option>
            <option value='cpu'>CPU（完全不探测 GPU）</option>
          </select>
        </div>
        <div>
          <label class='label'>system_prompt</label>
          <textarea id='system_prompt' placeholder='可选：系统提示词' style='min-height:88px'></textarea>
        </div>
      </div>
      <div class='row' style='margin-top:8px'>
        <label><input id='enable_experts' type='checkbox' style='width:auto;margin-right:8px'>启用专家路由</label>
        <label><input id='use_4bit' type='checkbox' style='width:auto;margin-right:8px'>尝试 4bit</label>
      </div>
      <div class='row' style='margin-top:8px'>
        <label><input id='cpu_fallback_on_error' type='checkbox' style='width:auto;margin-right:8px'>GPU 出错自动回退 CPU</label>
        <label><input id='consult_force_forced_expert' type='checkbox' style='width:auto;margin-right:8px'>强制专家时允许辅专家会诊</label>
        <label><input id='auto_open_browser' type='checkbox' style='width:auto;margin-right:8px'>启动时自动打开浏览器</label>
      </div>
      <div class='actions'>
        <button type='button' id='saveSettingsBtn' class='primary'>保存设置</button>
      </div>
      <div id='settingsHint' class='small muted' style='margin-top:10px'>切换后端模式后会清缓存。下一次请求会按新模式重新加载模型。</div>
    </div>
    <div class='card'>
      <h2>联网与自动化</h2>
      <div class='row'>
        <label><input id='search_enabled' type='checkbox' style='width:auto;margin-right:8px'>启用联网搜索</label>
        <label><input id='allow_web_fetch' type='checkbox' style='width:auto;margin-right:8px'>启用网页抓取</label>
      </div>
      <div class='row' style='margin-top:8px'>
        <label><input id='automation_enabled' type='checkbox' style='width:auto;margin-right:8px'>启用自动化工具</label>
        <label><input id='allow_local_file_edit' type='checkbox' style='width:auto;margin-right:8px'>允许本地文件编辑</label>
      </div>
      <div class='row' style='margin-top:8px'>
        <label><input id='safe_edit_copy_only' type='checkbox' style='width:auto;margin-right:8px'>文件编辑默认生成副本</label>
        <div class='muted small'>搜索与自动化开关会直接写入运行配置。关闭后对应 API 会返回禁用状态。</div>
      </div>
      <div class='actions'>
        <button type='button' id='refreshToolsBtn'>刷新工具列表与日志</button>
      </div>
      <label class='label' for='toolsNote' style='margin-top:10px'>当前可用工具</label>
      <pre id='toolsNote' style='min-height:100px'></pre>
      <label class='label' for='toolingLog' style='margin-top:10px'>最近工具 / 搜索日志</label>
      <pre id='toolingLog' style='min-height:140px'></pre>
      <div id='toolsHint' class='small muted' style='margin-top:10px'>联网搜索与本地自动化可在这里统一开关，并查看最近执行记录。</div>
    </div>
    <div class='card'>
      <h2>接口示例</h2>
      <code id='openaiExample'></code>
      <div style='height:10px'></div>
      <code id='ollamaExample'></code>
      <div style='height:10px'></div>
      <pre id='runtimeNote'></pre>
    </div>
  </div>
</div>
<script>
const PACKAGE_NAME = {package_js};
const INIT_SETTINGS = {settings_json};
const UI_SESSION_ID = 'web-' + Date.now() + '-' + Math.random().toString(36).slice(2,10);
let busy = false;
let history = [];
let currentController = null;
function esc(s){{return String(s ?? '').replace(/[&<>"]/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}}[c]))}}
function setBadge(id, text, cls=''){{const el=document.getElementById(id); if(!el) return; el.className='badge'+(cls?(' '+cls):''); el.textContent=text;}}
function setHint(id, text, color=''){{const el=document.getElementById(id); if(!el) return; el.textContent=text; el.style.color=color||'';}}
function nl2br(text){{return esc(text).split(String.fromCharCode(10)).join('<br>');}}
function maybeScroll(){{const box=document.getElementById('chatbox'); if(document.getElementById('autoScroll').checked) box.scrollTop=box.scrollHeight;}}
function ensureThought(div){{if(!div || !div.classList.contains('assistant')) return null; let details=div.querySelector('.thought-wrap'); if(details) return details; details=document.createElement('details'); details.className='thought-wrap'; details.style.display='none'; details.innerHTML=`<summary>思考过程</summary><div class='thought-body'></div>`; div.appendChild(details); return details;}}
function _setThoughtText(div, text, appendMode=false){{const details=ensureThought(div); if(!details) return; const body=details.querySelector('.thought-body'); const prev=(body && body.dataset.raw)||''; const next=appendMode ? (prev ? (prev + String.fromCharCode(10) + String(text||'')) : String(text||'')) : String(text||''); if(body){{body.dataset.raw=next; body.innerHTML=nl2br(next);}} details.style.display = next ? 'block' : 'none'; if(next) details.open = true; maybeScroll();}}
const _thoughtState = new WeakMap();
function _getThoughtState(div){{if(!_thoughtState.has(div)) _thoughtState.set(div, {{trace:[], expertOrder:[], experts:{{}}, meeting:[], synthesis:[]}}); return _thoughtState.get(div);}}
function _renderThought(div){{const st=_getThoughtState(div); const blocks=[]; if(st.trace.length) blocks.push(st.trace.join(String.fromCharCode(10))); for(const name of st.expertOrder){{const content=String(st.experts[name]||'').trim(); if(content) blocks.push(`【${{name}}·公开日志】${{String.fromCharCode(10)}}${{content}}`);}} if(st.meeting.length) blocks.push(`【会诊纪要】${{String.fromCharCode(10)}}${{st.meeting.join(String.fromCharCode(10))}}`); if(st.synthesis.length) blocks.push(`【综合阶段】${{String.fromCharCode(10)}}${{st.synthesis.join(String.fromCharCode(10))}}`); _setThoughtText(div, blocks.join(String.fromCharCode(10)+String.fromCharCode(10)), false);}}
function appendMsg(role, text){{const box=document.getElementById('chatbox'); const div=document.createElement('div'); div.className='msg '+role; const roleText=(role==='user'?'用户':(role==='system'?'系统':'助手')); let extra=''; if(role==='assistant') extra=`<details class='thought-wrap' style='display:none'><summary>思考过程</summary><div class='thought-body' data-raw=''></div></details>`; div.innerHTML=`<div class='role'>${{roleText}}</div><div class='body'>${{nl2br(text)}}</div>${{extra}}`; box.appendChild(div); maybeScroll(); return div;}}
function updateMsg(div, text){{const body=div.querySelector('.body'); if(body) body.innerHTML=nl2br(text); maybeScroll();}}
function resetChatbox(){{document.getElementById('chatbox').innerHTML='';}}
function setTrace(lines, targetCard=null){{const arr=Array.isArray(lines)?lines.filter(Boolean).map(x=>String(x)): (String(lines||'')?[String(lines||'')]:[]); const raw=arr.join(String.fromCharCode(10)); const el=document.getElementById('expertTrace'); if(el) el.textContent=raw; if(targetCard){{const st=_getThoughtState(targetCard); st.trace=arr.slice(); _renderThought(targetCard);}}}}
function appendTrace(line, targetCard=null){{const text=String(line||''); if(!text) return; const el=document.getElementById('expertTrace'); if(el) el.textContent = (el.textContent ? (el.textContent + String.fromCharCode(10)) : '') + text; if(targetCard){{const st=_getThoughtState(targetCard); st.trace.push(text); _renderThought(targetCard);}}}}
function beginExpertLog(div, expert, intro=''){{if(!div) return; const st=_getThoughtState(div); const name=String(expert||'专家'); if(!st.expertOrder.includes(name)) st.expertOrder.push(name); if(st.experts[name]===undefined) st.experts[name]=''; if(intro) st.trace.push(String(intro)); _renderThought(div);}}
function appendExpertLog(div, expert, text){{if(!div) return; const st=_getThoughtState(div); const name=String(expert||'专家'); if(!st.expertOrder.includes(name)) st.expertOrder.push(name); st.experts[name]=(st.experts[name]||'') + String(text||''); _renderThought(div);}}
function finishExpertLog(div, expert, text=''){{if(!div) return; const st=_getThoughtState(div); const name=String(expert||'专家'); if(!st.expertOrder.includes(name)) st.expertOrder.push(name); if(text) st.experts[name]=String(text||''); _renderThought(div);}}
function appendMeeting(div, text){{if(!div || !text) return; const st=_getThoughtState(div); st.meeting.push(String(text)); _renderThought(div);}}
function appendSynthesis(div, text){{if(!div || !text) return; const st=_getThoughtState(div); st.synthesis.push(String(text)); _renderThought(div);}}
async function jget(url){{const r=await fetch(url); const j=await r.json(); if(!r.ok) throw new Error(j.error||('HTTP '+r.status)); return j;}}
async function jpost(url,payload){{const r=await fetch(url,{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(payload||{{}})}}); const j=await r.json(); if(!r.ok) throw new Error(j.error||('HTTP '+r.status)); return j;}}
function syncExamples(){{const origin=location.origin; document.getElementById('openaiExample').textContent = `OpenAI Base URL: ${{origin}}/v1\nModel: ${{PACKAGE_NAME}}\nPOST ${{origin}}/v1/chat/completions`; document.getElementById('ollamaExample').textContent = `Ollama Base URL: ${{origin}}\nModel: ${{PACKAGE_NAME}}\nPOST ${{origin}}/api/chat\nPOST ${{origin}}/api/chat/stream`;}}
function fillForcedRouteOptions(runtime, selected='auto'){{const sel=document.getElementById('forced_route'); if(!sel) return; const opts=[['auto','自动选择'],['base','仅门控/主模型回答'],['consult','强制会诊（自动选专家）']]; const names=((runtime&&runtime.expert_names)||[]).map(x=>String(x||'').trim()).filter(Boolean); for (const name of names) {{ opts.push([name, '指定专家：'+name]); opts.push(['consult:'+name, '强制会诊：'+name+' 为主专家']); }} sel.innerHTML = opts.map(([v,t])=>`<option value="${{esc(v)}}">${{esc(t)}}</option>`).join(''); const wanted=String(selected||'auto'); sel.value = opts.some(x=>x[0]===wanted) ? wanted : 'auto'; }}
function fillSettings(s){{for (const k of ['temperature','top_p','repeat_penalty','max_new_tokens','activation_threshold','max_cached_experts','system_prompt','gate_backend_mode','expert_backend_mode','expert_tokenizer_strategy','forced_route','swarm_mode','consult_max_experts','consult_secondary_ratio','consult_note_max_new_tokens','consult_synth_max_new_tokens','consult_note_temperature','consult_dispatch_mode','thinking_transparency','expert_worklog_max_new_tokens','expert_worklog_temperature']){{ const el=document.getElementById(k); if(el && s[k]!==undefined && s[k]!==null) el.value=s[k]; }} for (const k of ['enable_experts','use_4bit','cpu_fallback_on_error','auto_open_browser','consult_force_forced_expert','consult_parallel_allow_gpu','search_enabled','allow_web_fetch','automation_enabled','allow_local_file_edit','safe_edit_copy_only']){{ const el=document.getElementById(k); if(el) el.checked=!!s[k]; }} fillForcedRouteOptions((s.runtime_status)||{{}}, s.forced_route || 'auto'); }}
function renderStatus(runtime){{const rows = [ ['模型包', runtime.package_name || PACKAGE_NAME], ['主模型', runtime.base_model || '-'], ['门控/主模型模式', runtime.gate_backend_mode || runtime.backend_mode || 'auto'], ['专家模式', runtime.expert_backend_mode || 'auto'], ['会诊调度', runtime.consult_dispatch_mode || 'auto'], ['GPU 探测', runtime.gpu_probe_done ? '已探测' : '未探测（首次加载时进行）'], ['GPU 可用', runtime.gpu_probe_done ? String(runtime.gpu_available) : '尚未探测'], ['GPU 设备', runtime.gpu_device_name || '-'], ['GPU 启用', String(!!runtime.gpu_enabled)], ['GPU 停用原因', runtime.gpu_disabled_reason || '-'], ['基础模型已加载', String(!!(runtime.base_loaded || runtime.cpu_base_loaded))], ['最近路由', runtime.last_route || 'base'], ['请求数', String(runtime.request_count || 0)], ['最近错误', runtime.last_error || '-'] ]; document.getElementById('statusTable').innerHTML = rows.map(([k,v])=>`<tr><th>${{esc(k)}}</th><td>${{esc(v)}}</td></tr>`).join(''); const mode = runtime.gate_backend_mode || runtime.backend_mode || 'auto'; setBadge('backendBadge', '后端模式: '+mode, mode==='cpu' ? 'warn' : 'ok'); let probeText='GPU 未探测'; let probeCls='warn'; if(runtime.gpu_probe_done){{ probeText = runtime.gpu_available ? ('GPU 可用'+(runtime.gpu_device_name?(' · '+runtime.gpu_device_name):'')) : 'GPU 不可用'; probeCls = runtime.gpu_available ? 'ok' : 'bad'; }} setBadge('probeBadge', probeText, probeCls); const loaded = !!(runtime.base_loaded || runtime.cpu_base_loaded); setBadge('loadBadge', loaded ? '模型已加载' : '模型未加载', loaded ? 'ok' : 'warn'); setBadge('routeBadge', `最近路由: ${{runtime.last_route || 'base'}}`); fillForcedRouteOptions(runtime, (document.getElementById('forced_route')||{{value:'auto'}}).value); }}
async function refreshTooling(){{try{{const tools=await jget('/api/tools/list'); const logs=await jget('/api/logs/recent?kind=tooling&limit=30'); const toolLines=(tools.tools||[]).map(t=>`${{t.name}} · ${{t.description}}`).join(String.fromCharCode(10)); document.getElementById('toolsNote').textContent=toolLines || '[无可用工具]'; document.getElementById('toolingLog').textContent=((logs.logs||[]).map(x=>JSON.stringify(x,null,2)).join(String.fromCharCode(10)+String.fromCharCode(10))) || '[暂无日志]'; setHint('toolsHint', `已刷新工具与日志 · 工具数=${{(tools.tools||[]).length}}`, '#93a3b8');}}catch(e){{setHint('toolsHint','刷新工具与日志失败：'+e.message,'#fca5a5');}}}}
async function refreshAll(hint=''){{try{{const data=await jget('/api/settings'); fillSettings(data.settings||{{}}); renderStatus((data.settings||{{}}).runtime_status || data.runtime || {{}}); await refreshTooling(); if(hint) setHint('chatHint', hint, '#93a3b8');}}catch(e){{setHint('chatHint', '状态刷新失败: '+e.message, '#fca5a5');}}}}
function buildMessages(){{const text=(document.getElementById('userInput').value||'').trim(); const sessionSystem=(document.getElementById('sessionSystem').value||'').trim(); let msgs=document.getElementById('keepHistory').checked ? history.slice() : []; if(sessionSystem) msgs=[{{role:'system',content:sessionSystem}}].concat(msgs.filter(m=>m.role!=='system')); if(text) msgs.push({{role:'user',content:text}}); return msgs;}}
function setBusy(v){{busy=!!v; document.getElementById('sendBtn').disabled=!!v; document.getElementById('sendJsonBtn').disabled=!!v; document.getElementById('stopBtn').disabled=!v;}}
async function sendChatJson(){{if(busy) return; const input=document.getElementById('userInput'); const text=(input.value||'').trim(); if(!text) return; const msgs=buildMessages(); const forcedRoute=(document.getElementById('forced_route')?.value||'auto'); setBusy(true); appendMsg('user', text); const assistantBox=appendMsg('assistant',''); input.value=''; setTrace([]); setHint('chatHint','已发送普通请求，等待完整回复…','#93a3b8'); try{{const data=await jpost('/api/chat',{{model:PACKAGE_NAME,messages:msgs,forced_route:forcedRoute,conversation_id:UI_SESSION_ID}}); const answer=(data.message&&data.message.content)||data.response||''; updateMsg(assistantBox, answer || '[空回复]'); history=document.getElementById('keepHistory').checked ? msgs.concat([{{role:'assistant',content:answer}}]) : []; setTrace((data.forgex_route&&data.forgex_route.trace)||data.route_trace||[], assistantBox); document.getElementById('runtimeNote').textContent=JSON.stringify(data.forgex_route||data.route||data,null,2); setHint('chatHint', `完成 · 路由=${{(data.forgex_route&&data.forgex_route.expert)||data.route||'base'}}`, '#86efac'); await refreshAll();}}catch(e){{updateMsg(assistantBox,'请求失败：'+e.message); setHint('chatHint','请求失败：'+e.message,'#fca5a5'); await refreshAll();}}finally{{setBusy(false);}}}}
async function sendChatStream(){{
if(busy) return;
const input = document.getElementById('userInput');
const text = (input.value || '').trim();
if(!text) return;
const msgs = buildMessages();
const forcedRoute = (document.getElementById('forced_route')?.value || 'auto');
setBusy(true);
appendMsg('user', text);
const assistantBox = appendMsg('assistant', '');
input.value = '';
setHint('chatHint','已发送流式请求，正在等待首个片段…','#93a3b8');
setTrace([]);
currentController = new AbortController();
try{{
  const res = await fetch('/api/chat/stream', {{
    method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{model:PACKAGE_NAME,messages:msgs,forced_route:forcedRoute,conversation_id:UI_SESSION_ID}}),
    signal: currentController.signal
  }});
  if(!res.ok){{
    throw new Error(await res.text() || ('HTTP ' + res.status));
  }}
  if(!res.body || !res.body.getReader){{
    setHint('chatHint','当前浏览器不支持流式读取，自动回退普通请求。','#fcd34d');
    assistantBox.remove();
    currentController = null;
    setBusy(false);
    await sendChatJson();
    return;
  }}
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  const LF = String.fromCharCode(10);
  let buf = '';
  let full = '';
  let doneEvent = null;
  while(true){{
    const chunk = await reader.read();
    if(chunk.done) break;
    buf += decoder.decode(chunk.value, {{stream:true}});
    const parts = buf.split(LF + LF);
    buf = parts.pop() || '';
    for (const block of parts){{
      const lines = block.split(LF);
      for (const line of lines){{
        if(!line.startsWith('data: ')) continue;
        const payload = line.slice(6);
        if(payload === '[DONE]') continue;
        let evt = {{}};
        try {{ evt = JSON.parse(payload); }} catch(_e) {{ continue; }}
        if(evt.event === 'delta'){{
          full += evt.text || '';
          updateMsg(assistantBox, full || '[空回复]');
        }} else if(evt.event === 'status'){{
          document.getElementById('runtimeNote').textContent = evt.text || '';
          setHint('chatHint', evt.text || '服务端处理中…', '#93a3b8'); appendTrace('状态 · '+(evt.text || '服务端处理中…'), assistantBox);
        }} else if(evt.event === 'meta'){{
          if(Array.isArray(evt.route_trace)) setTrace(evt.route_trace, assistantBox);
          document.getElementById('runtimeNote').textContent = JSON.stringify(evt, null, 2);
        }} else if(evt.event === 'trace'){{
          appendTrace(evt.text || '', assistantBox);
        }} else if(evt.event === 'expert_log_begin'){{
          beginExpertLog(assistantBox, evt.expert || '专家', evt.text || '');
        }} else if(evt.event === 'expert_log_delta'){{
          appendExpertLog(assistantBox, evt.expert || '专家', evt.text || '');
        }} else if(evt.event === 'expert_log_done'){{
          finishExpertLog(assistantBox, evt.expert || '专家', evt.text || '');
        }} else if(evt.event === 'meeting'){{
          appendMeeting(assistantBox, evt.text || '');
        }} else if(evt.event === 'synthesis'){{
          appendSynthesis(assistantBox, evt.text || '');
        }} else if(evt.event === 'done'){{
          doneEvent = evt;
          if(Array.isArray(evt.route_trace)) setTrace(evt.route_trace, assistantBox);
          if(evt.answer && evt.answer.length >= full.length){{
            full = evt.answer;
            updateMsg(assistantBox, full);
          }}
          document.getElementById('runtimeNote').textContent = JSON.stringify(evt, null, 2);
        }} else if(evt.event === 'error'){{
          throw new Error(evt.error || 'stream error');
        }}
      }}
    }}
  }}
  history = document.getElementById('keepHistory').checked ? msgs.concat([{{role:'assistant',content:full}}]) : [];
  setHint('chatHint', `流式完成 · 路由=${{(doneEvent&&doneEvent.route)||'base'}}`, '#86efac');
  await refreshAll();
}} catch(e) {{
  if(e.name === 'AbortError'){{
    setHint('chatHint','已停止生成。','#fcd34d');
    if(!assistantBox.textContent.trim()) updateMsg(assistantBox, '[已停止]');
  }} else {{
    if(!assistantBox.textContent.trim()) updateMsg(assistantBox, '流式请求失败：' + e.message);
    setHint('chatHint','流式请求失败：' + e.message,'#fca5a5');
    document.getElementById('runtimeNote').textContent = String(e.message || e);
  }}
}} finally {{
  currentController = null;
  setBusy(false);
}}
}}
async function saveSettings(){{const payload={{}}; for (const k of ['temperature','top_p','repeat_penalty','max_new_tokens','activation_threshold','max_cached_experts','system_prompt','gate_backend_mode','expert_backend_mode','expert_tokenizer_strategy','forced_route','swarm_mode','consult_max_experts','consult_secondary_ratio','consult_note_max_new_tokens','consult_synth_max_new_tokens','consult_note_temperature','consult_dispatch_mode','thinking_transparency','expert_worklog_max_new_tokens','expert_worklog_temperature']){{const el=document.getElementById(k); if(el) payload[k]=el.value;}} for (const k of ['enable_experts','use_4bit','cpu_fallback_on_error','auto_open_browser','consult_force_forced_expert','consult_parallel_allow_gpu','search_enabled','allow_web_fetch','automation_enabled','allow_local_file_edit','safe_edit_copy_only']){{const el=document.getElementById(k); if(el) payload[k]=el.checked;}} try{{const data=await jpost('/api/settings', payload); fillSettings((data.settings||{{}})); renderStatus(((data.settings||{{}}).runtime_status)||{{}}); await refreshTooling(); document.getElementById('runtimeNote').textContent=JSON.stringify(data,null,2); setHint('settingsHint','设置已保存。联网与自动化开关已同步写入 runtime_settings.json。', '#86efac');}}catch(e){{setHint('settingsHint','保存失败：'+e.message, '#fca5a5');}}}}
async function clearCaches(){{try{{const data=await jpost('/api/runtime/clear',{{}}); renderStatus(data.runtime||{{}}); document.getElementById('runtimeNote').textContent=JSON.stringify(data,null,2); setHint('chatHint','缓存已清空，下一次请求会重新加载模型。','#fcd34d');}}catch(e){{setHint('chatHint','清缓存失败：'+e.message,'#fca5a5');}}}}
async function recoverGpu(){{try{{const data=await jpost('/api/runtime/recover_gpu',{{}}); renderStatus(data.runtime||{{}}); document.getElementById('runtimeNote').textContent=JSON.stringify(data,null,2); setHint('chatHint','已重置 GPU 状态。下次加载时会重新探测。','#86efac');}}catch(e){{setHint('chatHint','重置 GPU 失败：'+e.message,'#fca5a5');}}}}
function bindUi(){{ const byId=(id)=>document.getElementById(id); byId('sendBtn')?.addEventListener('click', sendChatStream); byId('sendJsonBtn')?.addEventListener('click', sendChatJson); byId('stopBtn')?.addEventListener('click', ()=>{{ if(currentController) currentController.abort(); }}); byId('userInput')?.addEventListener('keydown', (e)=>{{if(e.key==='Enter' && !e.shiftKey){{e.preventDefault(); sendChatStream();}}}}); byId('clearChatBtn')?.addEventListener('click', ()=>{{history=[]; resetChatbox(); setHint('chatHint','聊天已清空。','#93a3b8');}}); byId('refreshBtn')?.addEventListener('click', ()=>refreshAll('状态已刷新。')); byId('saveSettingsBtn')?.addEventListener('click', saveSettings); byId('refreshToolsBtn')?.addEventListener('click', refreshTooling); byId('clearCacheBtn')?.addEventListener('click', clearCaches); byId('recoverGpuBtn')?.addEventListener('click', recoverGpu); syncExamples(); fillSettings(INIT_SETTINGS); renderStatus((INIT_SETTINGS.runtime_status)||{{}}); refreshTooling(); appendMsg('assistant','运行时已启动。默认使用流式发送；首次提问时才会加载模型，并在那一刻决定是否启用 GPU。若命中专家，界面会实时显示路由、专家公开日志与会诊纪要。'); setTrace(['等待提问后开始路由分析。']); }}
if(document.readyState === 'loading'){{ document.addEventListener('DOMContentLoaded', bindUi); }} else {{ bindUi(); }}
</script>
</div></body></html>"""



class Handler(BaseHTTPRequestHandler):
    server_version = "POLARISRuntime/mini"

    def _start_sse(self, code: int = 200):
        self.send_response(code)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def _write_sse(self, payload: Dict[str, Any]):
        if payload is None:
            payload = {"event": "trace", "stage": "stream_guard", "text": "ignored null event"}
        elif not isinstance(payload, dict):
            payload = {"event": "trace", "stage": "stream_guard", "text": str(payload)}
        chunk = ("data: " + json.dumps(payload, ensure_ascii=False) + "\n\n").encode("utf-8")
        self.wfile.write(chunk)
        self.wfile.flush()

    def log_message(self, format: str, *args):
        _runtime_log("HTTP " + (format % args))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self):
        path = _normalize_path(self.path)
        if path in ("/", "/index.html", "/ui"):
            return _text_response(self, 200, _simple_html())
        if path == "/health":
            return _json_response(self, 200, {"ok": True, "package_name": CORE.package_name, "runtime": CORE.get_runtime_status()})
        if path == "/v1/models":
            return _json_response(self, 200, {"object": "list", "data": [{"id": CORE.package_name, "object": "model", "owned_by": "local"}]})
        if path == "/api/tags":
            return _json_response(self, 200, {"models": [{"name": CORE.package_name, "model": CORE.package_name}]})
        if path == "/api/settings":
            return _json_response(self, 200, {"ok": True, "settings": CORE.get_settings()})
        if path == "/api/runtime/status":
            return _json_response(self, 200, {"ok": True, "runtime": CORE.get_runtime_status()})
        if path == "/api/tools/list":
            return _json_response(self, 200, {"ok": True, "tools": _tool_catalog(), "automation": _automation_cfg(), "search": _search_cfg()})
        if path == "/api/logs/recent":
            qs = parse_qs(urlparse(self.path).query)
            limit = int((qs.get("limit") or ["30"])[0] or 30)
            kind = str((qs.get("kind") or ["tooling"])[0] or "tooling").strip().lower()
            root = PACKAGE_DIR / str(_automation_cfg().get("logs_root") or "automation/logs")
            filename = "tooling.jsonl" if kind == "tooling" else f"{kind}.jsonl"
            return _json_response(self, 200, {"ok": True, "kind": kind, "logs": _read_recent_jsonl(root / filename, limit=limit)})
        return _json_response(self, 404, {"error": "not_found", "supported": ["/", "/health", "/v1/models", "/api/tags", "/api/settings", "/api/runtime/status", "/api/tools/list", "/api/logs/recent", "/api/chat/stream", "/v1/chat/completions", "/v1/responses", "/api/chat", "/api/generate", "/api/tools/run"]})

    def _handle_chat_like(self, payload: Dict[str, Any], style: str):
        messages = payload.get("messages") or []
        if not messages and payload.get("input"):
            inp = payload.get("input")
            if isinstance(inp, str):
                messages = [{"role": "user", "content": inp}]
            elif isinstance(inp, list):
                for item in inp:
                    if isinstance(item, dict) and item.get("content"):
                        messages.append({"role": item.get("role", "user"), "content": item.get("content")})
        if isinstance(payload.get("prompt"), str) and not messages:
            messages = [{"role": "user", "content": payload.get("prompt")}] 
        if not isinstance(messages, list):
            messages = [{"role": "user", "content": str(messages)}]
        normalized: List[Dict[str, str]] = []
        for m in messages:
            if isinstance(m, dict):
                content = m.get("content")
                if isinstance(content, list):
                    parts = []
                    for part in content:
                        if isinstance(part, dict) and part.get("type") == "text":
                            parts.append(str(part.get("text") or ""))
                    content = "\n".join([p for p in parts if p])
                normalized.append({"role": str(m.get("role") or "user"), "content": str(content or "")})
        result = CORE.chat(normalized, model_name=payload.get("model") or CORE.package_name, forced_route=self._extract_forced_route(payload), conversation_id=self._extract_conversation_id(payload))
        answer = result["answer"]
        if style == "openai":
            return _json_response(self, 200, {
                "id": f"chatcmpl-{int(time.time()*1000)}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": result["model"],
                "choices": [{"index": 0, "message": {"role": "assistant", "content": answer}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
                "route": result.get("route"),
                "route_score": result.get("route_score"),
                "knowledge_hits": result.get("knowledge_hits"),
                "forgex_route": {"expert": result.get("route"), "score": result.get("route_score"), "trace": result.get("route_trace") or []},
            })
        if style == "responses":
            return _json_response(self, 200, {
                "id": f"resp-{int(time.time()*1000)}",
                "object": "response",
                "created_at": int(time.time()),
                "model": result["model"],
                "output": [{"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": answer}]}],
                "status": "completed",
                "route": result.get("route"),
                "route_score": result.get("route_score"),
                "forgex_route": {"expert": result.get("route"), "score": result.get("route_score"), "trace": result.get("route_trace") or []},
            })
        if style == "ollama_chat":
            return _json_response(self, 200, {
                "model": result["model"],
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "message": {"role": "assistant", "content": answer},
                "done": True,
                "route": result.get("route"),
                "forgex_route": {"expert": result.get("route"), "score": result.get("route_score"), "trace": result.get("route_trace") or []},
            })
        return _json_response(self, 200, {
            "model": result["model"],
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "response": answer,
            "done": True,
            "route": result.get("route"),
            "forgex_route": {"expert": result.get("route"), "score": result.get("route_score"), "trace": result.get("route_trace") or []},
        })

    def _extract_forced_route(self, payload: Dict[str, Any]) -> Optional[str]:
        if not isinstance(payload, dict):
            return None
        for key in ("forced_route", "force_expert", "expert_override", "route_override", "force_model"):
            val = payload.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        return None

    def _extract_conversation_id(self, payload: Dict[str, Any]) -> Optional[str]:
        if not isinstance(payload, dict):
            return None
        for key in ("conversation_id", "session_id", "chat_id", "thread_id"):
            val = payload.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()[:128]
        return None

    def _normalize_messages(self, payload: Dict[str, Any]) -> List[Dict[str, str]]:
        messages = payload.get("messages") or []
        if isinstance(payload.get("input"), str) and not messages:
            messages = [{"role": "user", "content": payload.get("input")}]
        if isinstance(payload.get("prompt"), str) and not messages:
            messages = [{"role": "user", "content": payload.get("prompt")}]
        if not isinstance(messages, list):
            messages = [{"role": "user", "content": str(messages)}]
        normalized: List[Dict[str, str]] = []
        for m in messages:
            if isinstance(m, dict):
                content = m.get("content")
                if isinstance(content, list):
                    parts = []
                    for part in content:
                        if isinstance(part, dict) and part.get("type") == "text":
                            parts.append(str(part.get("text") or ""))
                    content = "\n".join([p for p in parts if p])
                normalized.append({"role": str(m.get("role") or "user"), "content": str(content or "")})
        return normalized

    def _stream_cpu_recover(self, messages: List[Dict[str, str]], model_name: str, *, gui_style: bool, original_error: Exception, stream_id: str = ""):
        try:
            CORE._mark_gpu_failed(str(original_error))
        except Exception:
            pass
        try:
            messages = CORE._sanitize_messages(messages)
            user_text = "\n".join(str(m.get("content", "")) for m in messages if isinstance(m, dict) and m.get("role") == "user").strip()
            cpu_model, cpu_tok = CORE._load_base_cpu()
            merged = CORE._merge_messages(messages or [], None, user_text)
            answer = CORE._generate(cpu_model, cpu_tok, merged, label="base-cpu-recover")
            route = "base:cpu-fallback"
            route_score = 0.0
            trace = CORE._route_trace(user_text, None, route, route_score, selected=False, fallback_reason=_friendly_gpu_error(original_error), used_cpu=True, knowledge_hits=len(CORE._retrieve_knowledge(user_text, None)))
            if gui_style:
                self._write_sse({"event": "status", "text": "流式阶段 GPU 出错，已切到 CPU 安全模式补发完整回复..."})
                self._write_sse({"event": "trace", "stage": "gpu_recover", "text": _friendly_gpu_error(original_error)})
                self._write_sse({"event": "meta", "model": model_name, "route": route, "route_score": route_score, "route_trace": trace, "gpu": CORE.get_runtime_status()})
                if answer:
                    self._write_sse({"event": "delta", "text": answer, "route": route})
                self._write_sse({"event": "done", "model": model_name, "answer": answer, "route": route, "route_score": route_score, "route_trace": trace, "gpu": CORE.get_runtime_status()})
            else:
                if answer:
                    self._write_sse({"id": stream_id, "object": "chat.completion.chunk", "created": int(time.time()), "model": model_name, "choices": [{"index": 0, "delta": {"content": answer}, "finish_reason": None}]})
                self._write_sse({"id": stream_id, "object": "chat.completion.chunk", "created": int(time.time()), "model": model_name, "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}], "_forgex_route": {"expert": route, "score": route_score, "trace": trace}})
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
            return True
        except Exception as recover_exc:
            CORE._last_error = f"stream_recover_failed::{recover_exc}"
            return False

    def _stream_openai_chat(self, payload: Dict[str, Any]):
        messages = self._normalize_messages(payload)
        model_name = payload.get("model") or CORE.package_name
        stream_id = f"chatcmpl-{int(time.time()*1000)}"
        self._start_sse(200)
        try:
            for evt in CORE.stream_chat(messages, model_name=model_name, forced_route=self._extract_forced_route(payload), conversation_id=self._extract_conversation_id(payload)):
                if evt is None:
                    continue
                if not isinstance(evt, dict):
                    evt = {"event": "trace", "stage": "stream_guard", "text": str(evt)}
                etype = str(evt.get("event") or "")
                if etype == "delta":
                    self._write_sse({"id": stream_id, "object": "chat.completion.chunk", "created": int(time.time()), "model": model_name, "choices": [{"index": 0, "delta": {"content": evt.get("text", "")}, "finish_reason": None}]})
                elif etype == "done":
                    self._write_sse({"id": stream_id, "object": "chat.completion.chunk", "created": int(time.time()), "model": model_name, "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}], "_forgex_route": {"expert": evt.get("route"), "score": evt.get("route_score", 0.0), "trace": evt.get("route_trace") or []}})
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        except Exception as e:
            if _is_gpu_generation_error(e) and self._stream_cpu_recover(messages, model_name, gui_style=False, original_error=e, stream_id=stream_id):
                return
            self._write_sse({"event": "error", "error": str(e)})

    def _stream_gui_chat(self, payload: Dict[str, Any]):
        messages = self._normalize_messages(payload)
        model_name = payload.get("model") or CORE.package_name
        self._start_sse(200)
        try:
            self._write_sse({"event": "status", "text": "请求已收到，正在准备模型与上下文..."})
            for evt in CORE.stream_chat(messages, model_name=model_name, forced_route=self._extract_forced_route(payload), conversation_id=self._extract_conversation_id(payload)):
                if evt is None:
                    continue
                if not isinstance(evt, dict):
                    evt = {"event": "trace", "stage": "stream_guard", "text": str(evt)}
                self._write_sse(evt)
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        except Exception as e:
            if _is_gpu_generation_error(e) and self._stream_cpu_recover(messages, model_name, gui_style=True, original_error=e):
                return
            self._write_sse({"event": "error", "error": str(e), "traceback": traceback.format_exc(limit=4)})

    def do_POST(self):
        path = _normalize_path(self.path)
        payload = _read_json_body(self)
        try:
            if path == "/api/settings":
                return _json_response(self, 200, CORE.update_settings(payload or {}))
            if path == "/api/runtime/clear":
                return _json_response(self, 200, {"ok": True, "runtime": CORE.clear_caches()})
            if path == "/api/runtime/recover_gpu":
                return _json_response(self, 200, {"ok": True, "runtime": CORE.recover_gpu()})
            if path == "/api/tools/run":
                return _json_response(self, 200, _run_automation_tool(payload or {}))
            if path == "/api/chat/stream":
                return self._stream_gui_chat(payload)
            if path == "/v1/chat/completions":
                if bool(payload.get("stream")):
                    return self._stream_openai_chat(payload)
                return self._handle_chat_like(payload, "openai")
            if path == "/v1/responses":
                return self._handle_chat_like(payload, "responses")
            if path == "/api/chat":
                if bool(payload.get("stream")):
                    return self._stream_gui_chat(payload)
                return self._handle_chat_like(payload, "ollama_chat")
            if path == "/api/generate":
                return self._handle_chat_like(payload, "ollama_generate")
            return _json_response(self, 404, {"error": "not_found", "supported": ["/api/settings", "/api/runtime/clear", "/api/runtime/recover_gpu", "/api/tools/run", "/api/chat/stream", "/v1/chat/completions", "/v1/responses", "/api/chat", "/api/generate"]})
        except Exception as e:
            if _is_gpu_generation_error(e):
                try:
                    CORE._mark_gpu_failed(str(e))
                except Exception:
                    pass
            CORE._last_error = str(e)
            tb = traceback.format_exc()
            code = 500
            return _json_response(self, code, {
                "error": str(e),
                "traceback": tb,
                "hint": _friendly_gpu_error(e) if _is_gpu_generation_error(e) else "前后端接口已统一；若仍失败，优先检查模型目录、tokenizer、当前 Python 环境及 GPU 驱动。",
            })



def main():
    parser = argparse.ArgumentParser(description="POLARIS Runtime 极简版")
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    args = parser.parse_args()
    settings = CORE.get_settings()
    host = args.host or settings.get("host") or "127.0.0.1"
    port = int(args.port or settings.get("port") or 8714)
    server = ThreadingHTTPServer((host, port), Handler)
    _runtime_log(f"POLARIS Runtime 极简版已启动: http://{host}:{port}")
    _runtime_log("当前状态是待机，不是卡死；请在浏览器打开上面的地址，或让其他软件请求 API。")
    _runtime_log("无自动预热，无 GPU 轮询；首次请求时才会加载模型。")
    _runtime_log("按 Ctrl+C 可退出。")
    if bool(settings.get("auto_open_browser", True)):
        _open_browser_later(f"http://{host}:{port}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _runtime_log("收到停止信号，正在退出…")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
