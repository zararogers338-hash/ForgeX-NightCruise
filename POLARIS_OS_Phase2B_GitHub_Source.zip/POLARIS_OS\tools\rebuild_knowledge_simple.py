from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

SCOPES = {
    "common": ROOT / "knowledge" / "common" / "files",
    "general": ROOT / "knowledge" / "general" / "files",
    "academic": ROOT / "knowledge" / "experts" / "academic" / "files",
    "legal": ROOT / "knowledge" / "experts" / "legal" / "files",
    "medical": ROOT / "knowledge" / "experts" / "medical" / "files",
    "coding": ROOT / "knowledge" / "experts" / "coding" / "files",
}

OUT = {
    "common": ROOT / "knowledge" / "common" / "index.json",
    "general": ROOT / "knowledge" / "general" / "index.json",
    "academic": ROOT / "knowledge" / "experts" / "academic" / "index.json",
    "legal": ROOT / "knowledge" / "experts" / "legal" / "index.json",
    "medical": ROOT / "knowledge" / "experts" / "medical" / "index.json",
    "coding": ROOT / "knowledge" / "experts" / "coding" / "index.json",
}

TEXT_EXTS = {".txt", ".md", ".markdown", ".csv", ".json", ".jsonl"}

def read_text(path: Path) -> str:
    ext = path.suffix.lower()
    if ext not in TEXT_EXTS:
        return ""
    try:
        if ext == ".json":
            data = json.loads(path.read_text(encoding="utf-8"))
            return json.dumps(data, ensure_ascii=False, indent=2)
        if ext == ".jsonl":
            rows = []
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception:
                    rows.append(line)
            return json.dumps(rows, ensure_ascii=False, indent=2)
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""

def chunk_text(text: str, size: int = 800, overlap: int = 80):
    text = str(text or "").strip()
    if not text:
        return []
    out = []
    i = 0
    n = len(text)
    while i < n:
        j = min(n, i + size)
        if j < n:
            cut = text.rfind("\n\n", i, j)
            if cut > i + size // 3:
                j = cut
        out.append(text[i:j].strip())
        if j >= n:
            break
        i = max(j - overlap, i + 1)
    return [x for x in out if x]

def rebuild_scope(name: str, src_dir: Path, out_file: Path):
    entries = []
    if src_dir.exists():
        for f in sorted(src_dir.rglob("*")):
            if not f.is_file():
                continue
            raw = read_text(f)
            for idx, chunk in enumerate(chunk_text(raw)):
                entries.append({
                    "doc": str(f.relative_to(src_dir)).replace("\\", "/"),
                    "chunk_idx": idx,
                    "scope": name,
                    "text": chunk,
                })
    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text(json.dumps(entries, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[ok] {name}: {len(entries)} chunks -> {out_file}")

def main():
    for name, src in SCOPES.items():
        rebuild_scope(name, src, OUT[name])

if __name__ == "__main__":
    main()
