# GitHub Upload Checklist

Before pushing:

- Confirm `.venv/` is not included.
- Confirm `data/datasets/`, `data/loras/`, `data/models_cache/`, and `data/logs/` only contain `.gitkeep`.
- Confirm no `*.safetensors`, `*.gguf`, `*.bin`, `*.pt`, `*.pth`, `*.ckpt`, or large `*.jsonl` files are staged.
- Choose a real license and replace `LICENSE.md` if this will be public.
- Run:

```powershell
python -m py_compile main.py core\trainer.py core\utils.py core\smart_params.py
python smoke_test.py
```

Suggested first commit:

```powershell
git init
git add .
git commit -m "Initial POLARIS OS source release"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
git push -u origin main
```
