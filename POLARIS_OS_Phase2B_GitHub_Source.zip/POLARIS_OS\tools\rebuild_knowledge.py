from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List

PACKAGE_DIR = Path(__file__).resolve().parents[1]
KNOWLEDGE_DIR = PACKAGE_DIR / "knowledge"

TEXT_KEYS = ["text", "content", "answer", "output", "assistant", "response", "completion", "body"]


def load_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_ws(text: str) -> str:
    text = text.replace("\r", "\n")
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def iter_texts_from_obj(obj: Any) -> Iterable[str]:
    if obj is None:
        return
    if isinstance(obj, str):
        t = normalize_ws(obj)
        if t:
            yield t
        return
    if isinstance(obj, dict):
        for key in TEXT_KEYS:
            value = obj.get(key)
            if isinstance(value, str) and value.strip():
                yield normalize_ws(value)
                return
        msgs = obj.get("messages") or obj.get("conversation") or obj.get("conversations")
        if isinstance(msgs, list):
            parts = []
            for m in msgs:
                if not isinstance(m, dict):
                    continue
                role = str(m.get("role") or m.get("from") or "").lower()
                content = m.get("content") or m.get("value") or m.get("text")
                if isinstance(content, str) and content.strip() and role != "system":
                    parts.append(f"{role or 'entry'}: {normalize_ws(content)}")
            if parts:
                yield "\n".join(parts)
                return
        for v in obj.values():
            yield from iter_texts_from_obj(v)
        return
    if isinstance(obj, list):
        for item in obj:
            yield from iter_texts_from_obj(item)
        return


def read_source(path: Path) -> List[str]:
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md", ".markdown"}:
        return [normalize_ws(path.read_text(encoding="utf-8", errors="ignore"))]
    if suffix == ".json":
        data = load_json(path, None)
        return [t for t in iter_texts_from_obj(data) if t]
    if suffix == ".jsonl":
        out = []
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                out.extend([t for t in iter_texts_from_obj(json.loads(line)) if t])
            except Exception:
                continue
        return out
    if suffix == ".csv":
        out = []
        with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                out.extend([t for t in iter_texts_from_obj(row) if t])
        return out
    return []


def chunk_text(text: str, chunk_size: int = 700, overlap: int = 100) -> List[str]:
    text = normalize_ws(text)
    if not text:
        return []
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    step = max(1, chunk_size - overlap)
    while start < len(text):
        end = min(len(text), start + chunk_size)
        chunks.append(text[start:end].strip())
        if end >= len(text):
            break
        start += step
    return [c for c in chunks if c]


def build_index(scope_dir: Path) -> List[Dict[str, Any]]:
    src_dir = scope_dir / "sources"
    entries = []
    for file in sorted(src_dir.rglob("*")):
        if not file.is_file():
            continue
        texts = read_source(file)
        chunk_idx = 0
        for text in texts:
            for chunk in chunk_text(text):
                entries.append({
                    "doc": file.name,
                    "chunk_idx": chunk_idx,
                    "text": chunk,
                })
                chunk_idx += 1
    write_json(scope_dir / "knowledge_index.json", entries)
    return entries


def main():
    summary = {}
    # shared + base
    for scope in [KNOWLEDGE_DIR / "shared", KNOWLEDGE_DIR / "base"]:
        summary[str(scope.relative_to(PACKAGE_DIR))] = len(build_index(scope))
    experts_dir = KNOWLEDGE_DIR / "experts"
    for scope in sorted(experts_dir.iterdir() if experts_dir.exists() else []):
        if scope.is_dir():
            summary[str(scope.relative_to(PACKAGE_DIR))] = len(build_index(scope))
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
